
-- Updated_at trigger function
CREATE OR REPLACE FUNCTION public.set_updated_at() RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Academic Years
CREATE TABLE public.academic_years (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  is_active BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.academic_years TO anon, authenticated;
GRANT ALL ON public.academic_years TO service_role;
ALTER TABLE public.academic_years ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read academic_years" ON public.academic_years FOR SELECT USING (true);
CREATE POLICY "public write academic_years" ON public.academic_years FOR ALL USING (true) WITH CHECK (true);
CREATE TRIGGER trg_academic_years_updated BEFORE UPDATE ON public.academic_years FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Classes
CREATE TABLE public.classes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  grade_level TEXT,
  homeroom_teacher TEXT,
  academic_year_id UUID REFERENCES public.academic_years(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.classes TO anon, authenticated;
GRANT ALL ON public.classes TO service_role;
ALTER TABLE public.classes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read classes" ON public.classes FOR SELECT USING (true);
CREATE POLICY "public write classes" ON public.classes FOR ALL USING (true) WITH CHECK (true);
CREATE INDEX idx_classes_year ON public.classes(academic_year_id);
CREATE TRIGGER trg_classes_updated BEFORE UPDATE ON public.classes FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Extracurriculars
CREATE TABLE public.extracurriculars (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.extracurriculars TO anon, authenticated;
GRANT ALL ON public.extracurriculars TO service_role;
ALTER TABLE public.extracurriculars ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read extracurriculars" ON public.extracurriculars FOR SELECT USING (true);
CREATE POLICY "public write extracurriculars" ON public.extracurriculars FOR ALL USING (true) WITH CHECK (true);
CREATE TRIGGER trg_extracurriculars_updated BEFORE UPDATE ON public.extracurriculars FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Students
CREATE TABLE public.students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  -- Identity
  photo_url TEXT,
  nis TEXT,
  nisn TEXT,
  foundation_number TEXT,
  full_name TEXT NOT NULL,
  nickname TEXT,
  gender TEXT CHECK (gender IN ('Laki-laki','Perempuan')),
  place_of_birth TEXT,
  date_of_birth DATE,
  religion TEXT,
  nationality TEXT DEFAULT 'Indonesia',
  child_status TEXT,
  birth_order INT,
  siblings_count INT,
  daily_language TEXT,
  blood_type TEXT,
  height_cm INT,
  weight_kg INT,
  -- Boarding
  is_boarding BOOLEAN NOT NULL DEFAULT false,
  -- Parents
  father_name TEXT, father_nik TEXT, father_occupation TEXT, father_education TEXT, father_phone TEXT,
  mother_name TEXT, mother_nik TEXT, mother_occupation TEXT, mother_education TEXT, mother_phone TEXT,
  guardian_name TEXT, guardian_relationship TEXT, guardian_occupation TEXT, guardian_phone TEXT,
  -- Address
  nik TEXT, family_card_number TEXT, address TEXT, rt TEXT, rw TEXT,
  village TEXT, district TEXT, regency TEXT, province TEXT, postal_code TEXT,
  transportation TEXT, distance_from_school TEXT,
  -- Academic
  previous_school TEXT, entry_year TEXT, entry_date DATE, admission_type TEXT,
  entry_class TEXT, status TEXT NOT NULL DEFAULT 'Aktif' CHECK (status IN ('Aktif','Pindah','Lulus','Keluar','Alumni')),
  graduation_year TEXT, exit_date DATE, exit_reason TEXT, diploma_number TEXT,
  current_class_id UUID REFERENCES public.classes(id) ON DELETE SET NULL,
  academic_year_id UUID REFERENCES public.academic_years(id) ON DELETE SET NULL,
  -- Health
  medical_history TEXT, allergies TEXT, disabilities TEXT, immunization TEXT, health_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.students TO anon, authenticated;
GRANT ALL ON public.students TO service_role;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read students" ON public.students FOR SELECT USING (true);
CREATE POLICY "public write students" ON public.students FOR ALL USING (true) WITH CHECK (true);
CREATE INDEX idx_students_status ON public.students(status);
CREATE INDEX idx_students_gender ON public.students(gender);
CREATE INDEX idx_students_boarding ON public.students(is_boarding);
CREATE INDEX idx_students_class ON public.students(current_class_id);
CREATE INDEX idx_students_year ON public.students(academic_year_id);
CREATE INDEX idx_students_name ON public.students(full_name);
CREATE TRIGGER trg_students_updated BEFORE UPDATE ON public.students FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Student <-> Extracurriculars
CREATE TABLE public.student_extracurriculars (
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  extracurricular_id UUID NOT NULL REFERENCES public.extracurriculars(id) ON DELETE CASCADE,
  PRIMARY KEY (student_id, extracurricular_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.student_extracurriculars TO anon, authenticated;
GRANT ALL ON public.student_extracurriculars TO service_role;
ALTER TABLE public.student_extracurriculars ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read se" ON public.student_extracurriculars FOR SELECT USING (true);
CREATE POLICY "public write se" ON public.student_extracurriculars FOR ALL USING (true) WITH CHECK (true);

-- Student documents
CREATE TABLE public.student_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  doc_type TEXT NOT NULL,
  file_url TEXT NOT NULL,
  file_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.student_documents TO anon, authenticated;
GRANT ALL ON public.student_documents TO service_role;
ALTER TABLE public.student_documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read sd" ON public.student_documents FOR SELECT USING (true);
CREATE POLICY "public write sd" ON public.student_documents FOR ALL USING (true) WITH CHECK (true);
CREATE INDEX idx_sd_student ON public.student_documents(student_id);

-- School profile (singleton)
CREATE TABLE public.school_profile (
  id INT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  school_name TEXT,
  logo_url TEXT,
  principal_name TEXT,
  current_academic_year TEXT,
  address TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.school_profile TO anon, authenticated;
GRANT ALL ON public.school_profile TO service_role;
ALTER TABLE public.school_profile ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read sp" ON public.school_profile FOR SELECT USING (true);
CREATE POLICY "public write sp" ON public.school_profile FOR ALL USING (true) WITH CHECK (true);
CREATE TRIGGER trg_sp_updated BEFORE UPDATE ON public.school_profile FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Seed default extracurriculars
INSERT INTO public.extracurriculars (name) VALUES
('Pramuka'),('Paskibra'),('PMR'),('Futsal'),('Sepak Bola'),('Voli'),('Basket'),
('Bulu Tangkis'),('Pencak Silat'),('Karate'),('Tahfidz'),('Hadroh'),('Qiroah'),
('Kaligrafi'),('English Club'),('Robotik'),('Jurnalistik'),('Multimedia'),
('Science Club'),('OSIS');

-- Seed school profile + sample academic year
INSERT INTO public.school_profile (id, school_name, principal_name, current_academic_year)
VALUES (1, 'Sekolah Saya', 'Nama Kepala Sekolah', '2024/2025');

INSERT INTO public.academic_years (name, is_active) VALUES
('2023/2024', false), ('2024/2025', true);
