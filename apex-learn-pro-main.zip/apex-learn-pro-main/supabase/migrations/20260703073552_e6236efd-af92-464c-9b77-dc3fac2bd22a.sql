
-- Grades table
CREATE TABLE public.grades (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  academic_year_id uuid REFERENCES public.academic_years(id) ON DELETE SET NULL,
  class_id uuid REFERENCES public.classes(id) ON DELETE SET NULL,
  semester smallint NOT NULL CHECK (semester BETWEEN 1 AND 6),
  subject_id uuid NOT NULL REFERENCES public.subjects(id) ON DELETE CASCADE,
  knowledge_score numeric(5,2),
  skills_score numeric(5,2),
  final_score numeric(5,2),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (student_id, academic_year_id, semester, subject_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.grades TO anon, authenticated;
GRANT ALL ON public.grades TO service_role;
ALTER TABLE public.grades ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read grades" ON public.grades FOR SELECT USING (true);
CREATE POLICY "public write grades" ON public.grades FOR ALL USING (true) WITH CHECK (true);
CREATE INDEX idx_grades_student ON public.grades(student_id);
CREATE INDEX idx_grades_class_sem ON public.grades(class_id, semester);
CREATE TRIGGER set_grades_updated BEFORE UPDATE ON public.grades FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Teacher documents
CREATE TABLE public.teacher_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id uuid NOT NULL REFERENCES public.teachers(id) ON DELETE CASCADE,
  doc_type text NOT NULL,
  file_url text NOT NULL,
  file_name text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.teacher_documents TO anon, authenticated;
GRANT ALL ON public.teacher_documents TO service_role;
ALTER TABLE public.teacher_documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read td" ON public.teacher_documents FOR SELECT USING (true);
CREATE POLICY "public write td" ON public.teacher_documents FOR ALL USING (true) WITH CHECK (true);
CREATE INDEX idx_td_teacher ON public.teacher_documents(teacher_id);
