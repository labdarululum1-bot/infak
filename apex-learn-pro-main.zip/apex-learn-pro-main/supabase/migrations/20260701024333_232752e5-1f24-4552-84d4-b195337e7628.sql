
-- Teachers: new fields
ALTER TABLE public.teachers
  ADD COLUMN IF NOT EXISTS nik text,
  ADD COLUMN IF NOT EXISTS university text,
  ADD COLUMN IF NOT EXISTS major text;

-- Subjects master
CREATE TABLE IF NOT EXISTS public.subjects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  code text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.subjects TO anon, authenticated;
GRANT ALL ON public.subjects TO service_role;
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "public rw subjects" ON public.subjects;
CREATE POLICY "public rw subjects" ON public.subjects FOR ALL USING (true) WITH CHECK (true);

-- Teacher-Subject link
CREATE TABLE IF NOT EXISTS public.teacher_subjects (
  teacher_id uuid NOT NULL REFERENCES public.teachers(id) ON DELETE CASCADE,
  subject_id uuid NOT NULL REFERENCES public.subjects(id) ON DELETE CASCADE,
  PRIMARY KEY (teacher_id, subject_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.teacher_subjects TO anon, authenticated;
GRANT ALL ON public.teacher_subjects TO service_role;
ALTER TABLE public.teacher_subjects ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "public rw teacher_subjects" ON public.teacher_subjects;
CREATE POLICY "public rw teacher_subjects" ON public.teacher_subjects FOR ALL USING (true) WITH CHECK (true);

-- Parent occupations master
CREATE TABLE IF NOT EXISTS public.occupations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.occupations TO anon, authenticated;
GRANT ALL ON public.occupations TO service_role;
ALTER TABLE public.occupations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "public rw occupations" ON public.occupations;
CREATE POLICY "public rw occupations" ON public.occupations FOR ALL USING (true) WITH CHECK (true);

INSERT INTO public.occupations (name) VALUES
  ('Petani'),('Pedagang'),('Wiraswasta'),('PNS'),('TNI/Polri'),
  ('Guru/Dosen'),('Karyawan Swasta'),('Buruh'),('Nelayan'),
  ('Sopir'),('Ibu Rumah Tangga'),('Lainnya')
ON CONFLICT (name) DO NOTHING;

-- School profile: active academic year FK
ALTER TABLE public.school_profile
  ADD COLUMN IF NOT EXISTS active_academic_year_id uuid REFERENCES public.academic_years(id) ON DELETE SET NULL;

-- Updated at triggers
DROP TRIGGER IF EXISTS trg_subjects_uat ON public.subjects;
CREATE TRIGGER trg_subjects_uat BEFORE UPDATE ON public.subjects
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_occupations_uat ON public.occupations;
CREATE TRIGGER trg_occupations_uat BEFORE UPDATE ON public.occupations
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
