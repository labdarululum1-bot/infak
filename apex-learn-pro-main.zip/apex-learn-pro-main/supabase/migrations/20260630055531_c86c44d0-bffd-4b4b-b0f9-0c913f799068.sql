
-- Drop obsolete student columns
ALTER TABLE public.students
  DROP COLUMN IF EXISTS entry_year,
  DROP COLUMN IF EXISTS entry_class,
  DROP COLUMN IF EXISTS graduation_year,
  DROP COLUMN IF EXISTS diploma_number,
  DROP COLUMN IF EXISTS academic_year_id;

-- Add new student columns
ALTER TABLE public.students
  ADD COLUMN IF NOT EXISTS mobile_phone text,
  ADD COLUMN IF NOT EXISTS master_book_number text,
  ADD COLUMN IF NOT EXISTS attendance_number integer,
  ADD COLUMN IF NOT EXISTS father_income text,
  ADD COLUMN IF NOT EXISTS mother_income text,
  ADD COLUMN IF NOT EXISTS guardian_income text;

CREATE UNIQUE INDEX IF NOT EXISTS students_master_book_unique
  ON public.students(master_book_number) WHERE master_book_number IS NOT NULL;

ALTER TABLE public.students DROP CONSTRAINT IF EXISTS students_mobile_phone_format;
ALTER TABLE public.students
  ADD CONSTRAINT students_mobile_phone_format
  CHECK (mobile_phone IS NULL OR mobile_phone ~ '^[0-9]{10,15}$');

ALTER TABLE public.students DROP CONSTRAINT IF EXISTS students_family_card_format;
ALTER TABLE public.students
  ADD CONSTRAINT students_family_card_format
  CHECK (family_card_number IS NULL OR family_card_number ~ '^[0-9]{16}$');

-- Class history
CREATE TABLE IF NOT EXISTS public.student_class_histories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  class_id uuid NOT NULL REFERENCES public.classes(id) ON DELETE RESTRICT,
  academic_year_id uuid NOT NULL REFERENCES public.academic_years(id) ON DELETE RESTRICT,
  start_date date NOT NULL DEFAULT CURRENT_DATE,
  end_date date,
  is_active boolean NOT NULL DEFAULT true,
  note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.student_class_histories TO anon, authenticated;
GRANT ALL ON public.student_class_histories TO service_role;
ALTER TABLE public.student_class_histories ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon all class histories" ON public.student_class_histories;
CREATE POLICY "anon all class histories" ON public.student_class_histories FOR ALL USING (true) WITH CHECK (true);
CREATE INDEX IF NOT EXISTS idx_class_hist_student ON public.student_class_histories(student_id);
CREATE INDEX IF NOT EXISTS idx_class_hist_active ON public.student_class_histories(student_id, is_active);
CREATE INDEX IF NOT EXISTS idx_class_hist_class ON public.student_class_histories(class_id, is_active);
CREATE TRIGGER set_class_histories_updated BEFORE UPDATE ON public.student_class_histories
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Teachers
CREATE TABLE IF NOT EXISTS public.teachers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nip text,
  nuptk text,
  full_name text NOT NULL,
  gender text CHECK (gender IN ('Laki-laki','Perempuan')),
  place_of_birth text,
  date_of_birth date,
  religion text,
  phone text,
  email text,
  address text,
  position text,
  employment_status text,
  education text,
  photo_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.teachers TO anon, authenticated;
GRANT ALL ON public.teachers TO service_role;
ALTER TABLE public.teachers ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon all teachers" ON public.teachers;
CREATE POLICY "anon all teachers" ON public.teachers FOR ALL USING (true) WITH CHECK (true);
CREATE TRIGGER set_teachers_updated BEFORE UPDATE ON public.teachers
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Add school profile extra fields
ALTER TABLE public.school_profile
  ADD COLUMN IF NOT EXISTS foundation_name text,
  ADD COLUMN IF NOT EXISTS phone text,
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS website text,
  ADD COLUMN IF NOT EXISTS npsn text,
  ADD COLUMN IF NOT EXISTS nss text,
  ADD COLUMN IF NOT EXISTS accreditation text;

-- Refresh PostgREST schema cache
NOTIFY pgrst, 'reload schema';
