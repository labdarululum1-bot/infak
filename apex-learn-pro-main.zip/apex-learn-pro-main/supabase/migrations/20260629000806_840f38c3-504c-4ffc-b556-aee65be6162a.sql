
-- 1. Drop unused columns
ALTER TABLE public.students
  DROP COLUMN IF EXISTS nickname,
  DROP COLUMN IF EXISTS daily_language,
  DROP COLUMN IF EXISTS blood_type,
  DROP COLUMN IF EXISTS height_cm,
  DROP COLUMN IF EXISTS weight_kg,
  DROP COLUMN IF EXISTS foundation_number;

-- 2. Migrate existing status values to the new two-value scheme
UPDATE public.students SET status = 'Lulus' WHERE status IN ('Alumni', 'Lulus');
UPDATE public.students SET status = 'Aktif' WHERE status NOT IN ('Lulus');

-- 3. Replace status check constraint
ALTER TABLE public.students DROP CONSTRAINT IF EXISTS students_status_check;
ALTER TABLE public.students ADD CONSTRAINT students_status_check CHECK (status IN ('Aktif', 'Lulus'));

-- 4. NIK constraints: exactly 16 digits when present, and unique
ALTER TABLE public.students DROP CONSTRAINT IF EXISTS students_nik_format;
ALTER TABLE public.students ADD CONSTRAINT students_nik_format CHECK (nik IS NULL OR nik ~ '^[0-9]{16}$');
CREATE UNIQUE INDEX IF NOT EXISTS students_nik_unique ON public.students (nik) WHERE nik IS NOT NULL;

-- 5. Backup history table
CREATE TABLE public.database_backups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  file_path TEXT NOT NULL,
  file_size_bytes BIGINT NOT NULL,
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.database_backups TO anon, authenticated;
GRANT ALL ON public.database_backups TO service_role;
ALTER TABLE public.database_backups ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read backups" ON public.database_backups FOR SELECT USING (true);
CREATE POLICY "public write backups" ON public.database_backups FOR ALL USING (true) WITH CHECK (true);
