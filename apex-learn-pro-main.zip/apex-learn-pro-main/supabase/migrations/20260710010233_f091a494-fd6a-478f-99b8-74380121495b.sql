-- Updated_at trigger function
CREATE OR REPLACE FUNCTION public.set_updated_at() RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TABLE public.academic_years (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  is_active BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.academic_years TO anon, authenticated;
GRANT ALL ON public.academic_years TO service_role;
ALTER TABLE public.academic_years ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read academic_years" ON public.academic_years FOR SELECT USING (true);
CREATE POLICY "public write academic_years" ON public.academic_years FOR ALL USING (true) WITH CHECK (true);
CREATE TRIGGER trg_academic_years_updated BEFORE UPDATE ON public.academic_years FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.classes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  grade_level TEXT,
  homeroom_teacher TEXT,
  academic_year_id UUID REFERENCES public.academic_years(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.classes TO anon, authenticated;
GRANT ALL ON public.classes TO service_role;
ALTER TABLE public.classes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read classes" ON public.classes FOR SELECT USING (true);
CREATE POLICY "public write classes" ON public.classes FOR ALL USING (true) WITH CHECK (true);
CREATE INDEX idx_classes_year ON public.classes(academic_year_id);
CREATE TRIGGER trg_classes_updated BEFORE UPDATE ON public.classes FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.extracurriculars (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.extracurriculars TO anon, authenticated;
GRANT ALL ON public.extracurriculars TO service_role;
ALTER TABLE public.extracurriculars ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read extracurriculars" ON public.extracurriculars FOR SELECT USING (true);
CREATE POLICY "public write extracurriculars" ON public.extracurriculars FOR ALL USING (true) WITH CHECK (true);
CREATE TRIGGER trg_extracurriculars_updated BEFORE UPDATE ON public.extracurriculars FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  photo_url TEXT,
  nis TEXT,
  nisn TEXT,
  full_name TEXT NOT NULL,
  gender TEXT CHECK (gender IN ('Laki-laki','Perempuan')),
  place_of_birth TEXT,
  date_of_birth DATE,
  religion TEXT,
  nationality TEXT DEFAULT 'Indonesia',
  child_status TEXT,
  birth_order INT,
  siblings_count INT,
  is_boarding BOOLEAN NOT NULL DEFAULT false,
  father_name TEXT, father_nik TEXT, father_occupation TEXT, father_education TEXT, father_phone TEXT, father_income TEXT,
  mother_name TEXT, mother_nik TEXT, mother_occupation TEXT, mother_education TEXT, mother_phone TEXT, mother_income TEXT,
  guardian_name TEXT, guardian_relationship TEXT, guardian_occupation TEXT, guardian_phone TEXT, guardian_income TEXT,
  nik TEXT, family_card_number TEXT, address TEXT, rt TEXT, rw TEXT,
  village TEXT, district TEXT, regency TEXT, province TEXT, postal_code TEXT,
  transportation TEXT, distance_from_school TEXT, mobile_phone TEXT,
  master_book_number TEXT, attendance_number INTEGER,
  previous_school TEXT, entry_date DATE, admission_type TEXT,
  status TEXT NOT NULL DEFAULT 'Aktif' CHECK (status IN ('Aktif','Lulus')),
  exit_date DATE, exit_reason TEXT,
  current_class_id UUID REFERENCES public.classes(id) ON DELETE SET NULL,
  medical_history TEXT, allergies TEXT, disabilities TEXT, immunization TEXT, health_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT students_nik_format CHECK (nik IS NULL OR nik ~ '^[0-9]{16}$'),
  CONSTRAINT students_mobile_phone_format CHECK (mobile_phone IS NULL OR mobile_phone ~ '^[0-9]{10,15}$'),
  CONSTRAINT students_family_card_format CHECK (family_card_number IS NULL OR family_card_number ~ '^[0-9]{16}$')
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.students TO anon, authenticated;
GRANT ALL ON public.students TO service_role;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read students" ON public.students FOR SELECT USING (true);
CREATE POLICY "public write students" ON public.students FOR ALL USING (true) WITH CHECK (true);
CREATE INDEX idx_students_status ON public.students(status);
CREATE INDEX idx_students_gender ON public.students(gender);
CREATE INDEX idx_students_boarding ON public.students(is_boarding);
CREATE INDEX idx_students_class ON public.students(current_class_id);
CREATE INDEX idx_students_name ON public.students(full_name);
CREATE UNIQUE INDEX students_nik_unique ON public.students (nik) WHERE nik IS NOT NULL;
CREATE UNIQUE INDEX students_master_book_unique ON public.students(master_book_number) WHERE master_book_number IS NOT NULL;
CREATE TRIGGER trg_students_updated BEFORE UPDATE ON public.students FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.student_extracurriculars (
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  extracurricular_id UUID NOT NULL REFERENCES public.extracurriculars(id) ON DELETE CASCADE,
  PRIMARY KEY (student_id, extracurricular_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.student_extracurriculars TO anon, authenticated;
GRANT ALL ON public.student_extracurriculars TO service_role;
ALTER TABLE public.student_extracurriculars ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read se" ON public.student_extracurriculars FOR SELECT USING (true);
CREATE POLICY "public write se" ON public.student_extracurriculars FOR ALL USING (true) WITH CHECK (true);

CREATE TABLE public.student_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  doc_type TEXT NOT NULL,
  file_url TEXT NOT NULL,
  file_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.student_documents TO anon, authenticated;
GRANT ALL ON public.student_documents TO service_role;
ALTER TABLE public.student_documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read sd" ON public.student_documents FOR SELECT USING (true);
CREATE POLICY "public write sd" ON public.student_documents FOR ALL USING (true) WITH CHECK (true);
CREATE INDEX idx_sd_student ON public.student_documents(student_id);

CREATE TABLE public.school_profile (
  id INT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  school_name TEXT,
  logo_url TEXT,
  principal_name TEXT,
  current_academic_year TEXT,
  address TEXT,
  foundation_name TEXT,
  phone TEXT,
  email TEXT,
  website TEXT,
  npsn TEXT,
  nss TEXT,
  accreditation TEXT,
  active_academic_year_id UUID REFERENCES public.academic_years(id) ON DELETE SET NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.school_profile TO anon, authenticated;
GRANT ALL ON public.school_profile TO service_role;
ALTER TABLE public.school_profile ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read sp" ON public.school_profile FOR SELECT USING (true);
CREATE POLICY "public write sp" ON public.school_profile FOR ALL USING (true) WITH CHECK (true);
CREATE TRIGGER trg_sp_updated BEFORE UPDATE ON public.school_profile FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.database_backups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  file_path TEXT NOT NULL,
  file_size_bytes BIGINT NOT NULL,
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.database_backups TO anon, authenticated;
GRANT ALL ON public.database_backups TO service_role;
ALTER TABLE public.database_backups ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read backups" ON public.database_backups FOR SELECT USING (true);
CREATE POLICY "public write backups" ON public.database_backups FOR ALL USING (true) WITH CHECK (true);

CREATE TABLE public.student_class_histories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  class_id uuid NOT NULL REFERENCES public.classes(id) ON DELETE RESTRICT,
  academic_year_id uuid NOT NULL REFERENCES public.academic_years(id) ON DELETE RESTRICT,
  start_date date NOT NULL DEFAULT CURRENT_DATE,
  end_date date,
  is_active boolean NOT NULL DEFAULT true,
  note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.student_class_histories TO anon, authenticated;
GRANT ALL ON public.student_class_histories TO service_role;
ALTER TABLE public.student_class_histories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "anon all class histories" ON public.student_class_histories FOR ALL USING (true) WITH CHECK (true);
CREATE INDEX idx_class_hist_student ON public.student_class_histories(student_id);
CREATE INDEX idx_class_hist_active ON public.student_class_histories(student_id, is_active);
CREATE INDEX idx_class_hist_class ON public.student_class_histories(class_id, is_active);
CREATE TRIGGER set_class_histories_updated BEFORE UPDATE ON public.student_class_histories FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.teachers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nip text,
  nuptk text,
  nik text,
  full_name text NOT NULL,
  gender text CHECK (gender IN ('Laki-laki','Perempuan')),
  place_of_birth text,
  date_of_birth date,
  religion text,
  phone text,
  email text,
  address text,
  position text,
  employment_status text,
  education text,
  university text,
  major text,
  photo_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.teachers TO anon, authenticated;
GRANT ALL ON public.teachers TO service_role;
ALTER TABLE public.teachers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "anon all teachers" ON public.teachers FOR ALL USING (true) WITH CHECK (true);
CREATE TRIGGER set_teachers_updated BEFORE UPDATE ON public.teachers FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.subjects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  code text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.subjects TO anon, authenticated;
GRANT ALL ON public.subjects TO service_role;
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public rw subjects" ON public.subjects FOR ALL USING (true) WITH CHECK (true);
CREATE TRIGGER trg_subjects_uat BEFORE UPDATE ON public.subjects FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.teacher_subjects (
  teacher_id uuid NOT NULL REFERENCES public.teachers(id) ON DELETE CASCADE,
  subject_id uuid NOT NULL REFERENCES public.subjects(id) ON DELETE CASCADE,
  PRIMARY KEY (teacher_id, subject_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.teacher_subjects TO anon, authenticated;
GRANT ALL ON public.teacher_subjects TO service_role;
ALTER TABLE public.teacher_subjects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public rw teacher_subjects" ON public.teacher_subjects FOR ALL USING (true) WITH CHECK (true);

CREATE TABLE public.teacher_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id uuid NOT NULL REFERENCES public.teachers(id) ON DELETE CASCADE,
  doc_type text NOT NULL,
  file_url text NOT NULL,
  file_name text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.teacher_documents TO anon, authenticated;
GRANT ALL ON public.teacher_documents TO service_role;
ALTER TABLE public.teacher_documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read td" ON public.teacher_documents FOR SELECT USING (true);
CREATE POLICY "public write td" ON public.teacher_documents FOR ALL USING (true) WITH CHECK (true);
CREATE INDEX idx_td_teacher ON public.teacher_documents(teacher_id);

CREATE TABLE public.occupations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.occupations TO anon, authenticated;
GRANT ALL ON public.occupations TO service_role;
ALTER TABLE public.occupations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public rw occupations" ON public.occupations FOR ALL USING (true) WITH CHECK (true);
CREATE TRIGGER trg_occupations_uat BEFORE UPDATE ON public.occupations FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.grades (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  academic_year_id uuid REFERENCES public.academic_years(id) ON DELETE SET NULL,
  class_id uuid REFERENCES public.classes(id) ON DELETE SET NULL,
  semester smallint NOT NULL CHECK (semester BETWEEN 1 AND 6),
  subject_id uuid NOT NULL REFERENCES public.subjects(id) ON DELETE CASCADE,
  knowledge_score numeric(5,2),
  skills_score numeric(5,2),
  final_score numeric(5,2),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (student_id, academic_year_id, semester, subject_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.grades TO anon, authenticated;
GRANT ALL ON public.grades TO service_role;
ALTER TABLE public.grades ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read grades" ON public.grades FOR SELECT USING (true);
CREATE POLICY "public write grades" ON public.grades FOR ALL USING (true) WITH CHECK (true);
CREATE INDEX idx_grades_student ON public.grades(student_id);
CREATE INDEX idx_grades_class_sem ON public.grades(class_id, semester);
CREATE TRIGGER set_grades_updated BEFORE UPDATE ON public.grades FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE POLICY "anon read student-files" ON storage.objects FOR SELECT TO anon, authenticated USING (bucket_id = 'student-files');
CREATE POLICY "anon write student-files" ON storage.objects FOR INSERT TO anon, authenticated WITH CHECK (bucket_id = 'student-files');
CREATE POLICY "anon update student-files" ON storage.objects FOR UPDATE TO anon, authenticated USING (bucket_id = 'student-files');
CREATE POLICY "anon delete student-files" ON storage.objects FOR DELETE TO anon, authenticated USING (bucket_id = 'student-files');

INSERT INTO public.extracurriculars (name) VALUES
('Pramuka'),('Paskibra'),('PMR'),('Futsal'),('Sepak Bola'),('Voli'),('Basket'),
('Bulu Tangkis'),('Pencak Silat'),('Karate'),('Tahfidz'),('Hadroh'),('Qiroah'),
('Kaligrafi'),('English Club'),('Robotik'),('Jurnalistik'),('Multimedia'),
('Science Club'),('OSIS');

INSERT INTO public.school_profile (id, school_name, principal_name, current_academic_year)
VALUES (1, 'Sekolah Saya', 'Nama Kepala Sekolah', '2024/2025');

INSERT INTO public.academic_years (name, is_active) VALUES
('2023/2024', false), ('2024/2025', true);

INSERT INTO public.occupations (name) VALUES
  ('Petani'),('Pedagang'),('Wiraswasta'),('PNS'),('TNI/Polri'),
  ('Guru/Dosen'),('Karyawan Swasta'),('Buruh'),('Nelayan'),
  ('Sopir'),('Ibu Rumah Tangga'),('Lainnya');

INSERT INTO public.subjects (name) VALUES
  ('Al Quran Hadits'),('Aqidah Akhlak'),('Fiqih'),('SKI'),('Bahasa Arab'),
  ('Pendidikan Pancasila'),('Bahasa Indonesia'),('Bahasa Inggris'),
  ('Matematika'),('IPA'),('IPS'),('Seni Budaya'),('PJOK'),('Prakarya'),('TIK')
ON CONFLICT (name) DO NOTHING;

NOTIFY pgrst, 'reload schema';