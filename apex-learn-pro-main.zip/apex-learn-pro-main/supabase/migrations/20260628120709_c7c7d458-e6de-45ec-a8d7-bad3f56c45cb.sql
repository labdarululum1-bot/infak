
CREATE POLICY "anon read student-files" ON storage.objects FOR SELECT TO anon, authenticated USING (bucket_id = 'student-files');
CREATE POLICY "anon write student-files" ON storage.objects FOR INSERT TO anon, authenticated WITH CHECK (bucket_id = 'student-files');
CREATE POLICY "anon update student-files" ON storage.objects FOR UPDATE TO anon, authenticated USING (bucket_id = 'student-files');
CREATE POLICY "anon delete student-files" ON storage.objects FOR DELETE TO anon, authenticated USING (bucket_id = 'student-files');
