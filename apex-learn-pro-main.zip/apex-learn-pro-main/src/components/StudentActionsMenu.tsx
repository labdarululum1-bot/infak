import { Link, useNavigate } from "@tanstack/react-router";
import { Eye, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useQueryClient } from "@tanstack/react-query";

export function StudentActionsMenu({ student }: { student: any }) {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const s = student;

  async function doDelete() {
    const { error } = await supabase.from("students").delete().eq("id", s.id);
    if (error) return toast.error("Gagal menghapus: " + error.message);
    toast.success("Siswa berhasil dihapus");
    qc.invalidateQueries({ queryKey: ["students"] });
  }

  return (
    <TooltipProvider delayDuration={200}>
      <div className="inline-flex items-center gap-1">
        <Tooltip>
          <TooltipTrigger asChild>
            <Button asChild variant="ghost" size="icon" className="rounded-full transition-transform hover:scale-110 hover:bg-primary-soft hover:text-primary">
              <Link to="/siswa/$id/profil" params={{ id: s.id }} aria-label="Lihat Profil">
                <Eye className="h-4 w-4" />
              </Link>
            </Button>
          </TooltipTrigger>
          <TooltipContent>Lihat Profil</TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full transition-transform hover:scale-110 hover:bg-primary-soft hover:text-primary"
              onClick={() => navigate({ to: "/siswa/$id/edit", params: { id: s.id } })}
              aria-label="Ubah Siswa"
            >
              <Pencil className="h-4 w-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>Ubah Siswa</TooltipContent>
        </Tooltip>

        <AlertDialog>
          <Tooltip>
            <TooltipTrigger asChild>
              <AlertDialogTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full text-destructive transition-transform hover:scale-110 hover:bg-destructive/10 hover:text-destructive"
                  aria-label="Hapus Siswa"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </AlertDialogTrigger>
            </TooltipTrigger>
            <TooltipContent>Hapus Siswa</TooltipContent>
          </Tooltip>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Hapus siswa?</AlertDialogTitle>
              <AlertDialogDescription>
                Tindakan ini akan menghapus data <b>{s.full_name}</b> beserta dokumen dan riwayat terkait. Tidak dapat dibatalkan.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Batal</AlertDialogCancel>
              <AlertDialogAction onClick={doDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                Ya, hapus
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </TooltipProvider>
  );
}
