import { useState, useEffect, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { Save, X, Upload, FileText, Image as ImageIcon, ExternalLink, Check } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import {
  fetchClasses, fetchExtracurriculars, fetchActiveAcademicYear,
  fetchStudentExtracurriculars, uploadStudentFile, signedUrl, type Student,
} from "@/lib/db";
import {
  INCOME_OPTIONS, EDUCATION_OPTIONS, ADMISSION_TYPE_OPTIONS,
  NATIONALITY_OPTIONS, RELIGION_OPTIONS, CHILD_STATUS_OPTIONS,
} from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";

type Doc = { id: string; doc_type: string; file_url: string; file_name: string | null };

const DOC_TYPES = ["Foto Siswa", "Kartu Keluarga", "Akta Kelahiran", "Ijazah", "Surat Pindah Sekolah", "KIP / PKH", "KTP Orang Tua", "Lainnya"];

function Section({ title, description, children }: { title: string; description?: string; children: ReactNode }) {
  return (
    <Card className="rounded-2xl border border-border p-5 shadow-soft">
      <div className="mb-4">
        <h3 className="font-display text-base font-semibold">{title}</h3>
        {description && <p className="mt-0.5 text-xs text-muted-foreground">{description}</p>}
      </div>
      <div className="grid gap-4 md:grid-cols-2">{children}</div>
    </Card>
  );
}

function Field({ label, children, full, hint }: { label: string; children: ReactNode; full?: boolean; hint?: string }) {
  return (
    <div className={full ? "md:col-span-2" : ""}>
      <Label className="mb-1.5 block text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</Label>
      {children}
      {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

export type StudentFormResult = {
  data: Partial<Student>;
  eskuls: string[];
  classAssignment?: { classId: string; academicYearId: string };
};

export function StudentForm({
  initial, onSubmit, onCancel, studentId,
}: {
  initial?: Partial<Student>;
  onSubmit: (result: StudentFormResult) => Promise<string | void>;
  onCancel: () => void;
  studentId?: string;
}) {
  const [data, setData] = useState<Partial<Student>>(initial ?? { status: "Aktif", is_boarding: false, nationality: "WNI" });
  const [eskuls, setEskuls] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const [docs, setDocs] = useState<Doc[]>([]);
  const [docPreviews, setDocPreviews] = useState<Record<string, string>>({});
  const [classId, setClassId] = useState<string>(initial?.current_class_id ?? "");
  const [academicYearId, setAcademicYearId] = useState<string>("");

  const { data: classes = [] } = useQuery({ queryKey: ["classes"], queryFn: fetchClasses });
  const { data: activeYear } = useQuery({ queryKey: ["active-academic-year"], queryFn: fetchActiveAcademicYear });
  const { data: allEskuls = [] } = useQuery({ queryKey: ["extracurriculars"], queryFn: fetchExtracurriculars });

  // Sync academic year from active year setting (unless overridden by existing history)
  useEffect(() => {
    if (activeYear && !academicYearId) setAcademicYearId((activeYear as any).id);
  }, [activeYear, academicYearId]);

  // Load active class history (gives us the academic year for the active assignment)
  useEffect(() => {
    if (!studentId) return;
    fetchStudentExtracurriculars(studentId).then(setEskuls).catch(() => {});
    supabase.from("student_documents").select("*").eq("student_id", studentId).then(({ data }) => {
      setDocs((data ?? []) as Doc[]);
    });
    supabase
      .from("student_class_histories")
      .select("class_id, academic_year_id")
      .eq("student_id", studentId)
      .eq("is_active", true)
      .maybeSingle()
      .then(({ data }) => {
        if (data) {
          setClassId(data.class_id);
          setAcademicYearId(data.academic_year_id);
        }
      });
  }, [studentId]);

  useEffect(() => {
    (async () => {
      const out: Record<string, string> = {};
      for (const d of docs) {
        try { out[d.id] = await signedUrl(d.file_url); } catch { /* skip */ }
      }
      setDocPreviews(out);
    })();
  }, [docs]);

  function up<K extends keyof Student>(k: K, v: Student[K] | null) {
    setData((d) => ({ ...d, [k]: v }));
  }

  async function handlePhotoUpload(file: File) {
    const tempId = studentId ?? "temp-" + Date.now();
    const path = await uploadStudentFile(tempId, file, "photo");
    up("photo_url", path);
    toast.success("Foto berhasil diunggah");
  }

  async function handleDocUpload(file: File, docType: string) {
    if (!studentId) return toast.error("Simpan siswa terlebih dahulu");
    const path = await uploadStudentFile(studentId, file, docType.replace(/\s+/g, "-").toLowerCase());
    const { data: ins, error } = await supabase.from("student_documents")
      .insert({ student_id: studentId, doc_type: docType, file_url: path, file_name: file.name })
      .select().single();
    if (error) return toast.error("Gagal unggah: " + error.message);
    setDocs((d) => [...d, ins as Doc]);
    toast.success("Dokumen berhasil diunggah");
  }

  async function deleteDoc(id: string) {
    await supabase.from("student_documents").delete().eq("id", id);
    setDocs((d) => d.filter((x) => x.id !== id));
  }

  function validate(): string | null {
    if (!data.full_name?.trim()) return "Nama lengkap wajib diisi";
    if (data.nik && !/^[0-9]{16}$/.test(data.nik)) return "NIK harus terdiri dari tepat 16 digit angka";
    if (data.family_card_number && !/^[0-9]{16}$/.test(data.family_card_number))
      return "No. Kartu Keluarga harus 16 digit angka";
    if (data.mobile_phone && !/^[0-9]{10,15}$/.test(data.mobile_phone))
      return "No. HP siswa harus 10–15 digit angka";
    if (classId && !academicYearId)
      return "Tahun Ajaran Aktif belum diatur. Silakan atur di menu Pengaturan.";
    return null;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const err = validate();
    if (err) return toast.error(err);
    setSaving(true);
    try {
      await onSubmit({
        data,
        eskuls,
        classAssignment: classId && academicYearId ? { classId, academicYearId } : undefined,
      });
    } catch (err: any) {
      const msg = err?.message ?? "error";
      if (msg.includes("students_nik_unique") || (msg.includes("duplicate key") && msg.includes("nik")))
        toast.error("NIK sudah digunakan oleh siswa lain");
      else if (msg.includes("students_master_book_unique"))
        toast.error("No. Buku Induk sudah digunakan oleh siswa lain");
      else if (msg.includes("students_mobile_phone_format"))
        toast.error("Format No. HP tidak valid");
      else if (msg.includes("students_family_card_format"))
        toast.error("Format No. KK tidak valid");
      else toast.error("Gagal menyimpan: " + msg);
    } finally {
      setSaving(false);
    }
  }

  const onlyDigits = (s: string) => s.replace(/\D/g, "");

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Tabs defaultValue="identity" className="w-full">
        <TabsList className="grid w-full grid-cols-3 md:w-auto md:inline-flex">
          <TabsTrigger value="identity">Identitas</TabsTrigger>
          <TabsTrigger value="family">Keluarga</TabsTrigger>
          <TabsTrigger value="academic">Akademik</TabsTrigger>
          <TabsTrigger value="health">Kesehatan</TabsTrigger>
          <TabsTrigger value="extras">Ekstrakurikuler</TabsTrigger>
          <TabsTrigger value="documents">Dokumen</TabsTrigger>
        </TabsList>

        <TabsContent value="identity" className="mt-4 space-y-4">
          <Section title="Identitas Siswa">
            <Field label="Foto Siswa" full>
              <div className="flex items-center gap-4">
                <div className="grid h-20 w-20 shrink-0 place-items-center overflow-hidden rounded-2xl bg-muted">
                  {data.photo_url ? <PhotoPreview path={data.photo_url} /> : <ImageIcon className="h-6 w-6 text-muted-foreground" />}
                </div>
                <label className="cursor-pointer">
                  <input type="file" accept="image/*" className="hidden" onChange={(e) => {
                    const f = e.target.files?.[0]; if (f) handlePhotoUpload(f);
                  }} />
                  <Button type="button" variant="outline" size="sm" asChild><span><Upload className="mr-2 h-4 w-4" /> Unggah Foto</span></Button>
                </label>
              </div>
            </Field>
            <Field label="NIS"><Input value={data.nis ?? ""} onChange={(e) => up("nis", e.target.value)} /></Field>
            <Field label="NISN"><Input value={data.nisn ?? ""} onChange={(e) => up("nisn", e.target.value)} /></Field>
            <Field label="NIK" hint="16 digit angka, unik per siswa." full>
              <Input inputMode="numeric" maxLength={16} value={data.nik ?? ""}
                onChange={(e) => up("nik", onlyDigits(e.target.value) || null)} placeholder="16 digit NIK" />
            </Field>
            <Field label="Nama Lengkap *" full><Input required value={data.full_name ?? ""} onChange={(e) => up("full_name", e.target.value)} /></Field>
            <Field label="Jenis Kelamin">
              <Select value={data.gender ?? ""} onValueChange={(v) => up("gender", v)}>
                <SelectTrigger><SelectValue placeholder="Pilih" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Laki-laki">Laki-laki</SelectItem>
                  <SelectItem value="Perempuan">Perempuan</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <Field label="Agama">
              <Select value={data.religion ?? ""} onValueChange={(v) => up("religion", v)}>
                <SelectTrigger><SelectValue placeholder="Pilih" /></SelectTrigger>
                <SelectContent>
                  {RELIGION_OPTIONS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Tempat Lahir"><Input value={data.place_of_birth ?? ""} onChange={(e) => up("place_of_birth", e.target.value)} /></Field>
            <Field label="Tanggal Lahir"><Input type="date" value={data.date_of_birth ?? ""} onChange={(e) => up("date_of_birth", e.target.value)} /></Field>
            <Field label="Kewarganegaraan">
              <Select value={data.nationality ?? "WNI"} onValueChange={(v) => up("nationality", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {NATIONALITY_OPTIONS.map((n) => <SelectItem key={n} value={n}>{n}</SelectItem>)}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Status Anak">
              <Select value={data.child_status ?? ""} onValueChange={(v) => up("child_status", v)}>
                <SelectTrigger><SelectValue placeholder="Pilih" /></SelectTrigger>
                <SelectContent>
                  {CHILD_STATUS_OPTIONS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Anak ke-"><Input type="number" value={data.birth_order ?? ""} onChange={(e) => up("birth_order", e.target.value ? Number(e.target.value) : null)} /></Field>
            <Field label="Jumlah Saudara"><Input type="number" value={data.siblings_count ?? ""} onChange={(e) => up("siblings_count", e.target.value ? Number(e.target.value) : null)} /></Field>
            <Field label="No. HP Siswa" hint="10–15 digit angka.">
              <Input inputMode="numeric" maxLength={15} value={data.mobile_phone ?? ""}
                onChange={(e) => up("mobile_phone", onlyDigits(e.target.value) || null)} />
            </Field>
            <Field label="Status Tinggal">
              <div className="flex items-center gap-3 rounded-xl border border-border bg-muted/30 p-3">
                <Switch checked={!!data.is_boarding} onCheckedChange={(v) => up("is_boarding", v)} />
                <div>
                  <div className="text-sm font-medium">Siswa Pesantren / Asrama</div>
                  <div className="text-xs text-muted-foreground">Aktifkan jika siswa tinggal di pesantren / asrama sekolah.</div>
                </div>
              </div>
            </Field>
          </Section>
        </TabsContent>

        <TabsContent value="family" className="mt-4 space-y-4">
          <Section title="Data Ayah">
            <Field label="Nama Ayah"><Input value={data.father_name ?? ""} onChange={(e) => up("father_name", e.target.value)} /></Field>
            <Field label="NIK Ayah"><Input value={data.father_nik ?? ""} onChange={(e) => up("father_nik", e.target.value)} /></Field>
            <Field label="Pekerjaan"><Input value={data.father_occupation ?? ""} onChange={(e) => up("father_occupation", e.target.value)} /></Field>
            <Field label="Pendidikan Terakhir">
              <Select value={data.father_education ?? ""} onValueChange={(v) => up("father_education", v)}>
                <SelectTrigger><SelectValue placeholder="Pilih" /></SelectTrigger>
                <SelectContent>{EDUCATION_OPTIONS.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="Penghasilan / Bulan">
              <Select value={data.father_income ?? ""} onValueChange={(v) => up("father_income", v)}>
                <SelectTrigger><SelectValue placeholder="Pilih" /></SelectTrigger>
                <SelectContent>{INCOME_OPTIONS.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="No. HP" full><Input value={data.father_phone ?? ""} onChange={(e) => up("father_phone", e.target.value)} /></Field>
          </Section>
          <Section title="Data Ibu">
            <Field label="Nama Ibu"><Input value={data.mother_name ?? ""} onChange={(e) => up("mother_name", e.target.value)} /></Field>
            <Field label="NIK Ibu"><Input value={data.mother_nik ?? ""} onChange={(e) => up("mother_nik", e.target.value)} /></Field>
            <Field label="Pekerjaan"><Input value={data.mother_occupation ?? ""} onChange={(e) => up("mother_occupation", e.target.value)} /></Field>
            <Field label="Pendidikan Terakhir">
              <Select value={data.mother_education ?? ""} onValueChange={(v) => up("mother_education", v)}>
                <SelectTrigger><SelectValue placeholder="Pilih" /></SelectTrigger>
                <SelectContent>{EDUCATION_OPTIONS.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="Penghasilan / Bulan">
              <Select value={data.mother_income ?? ""} onValueChange={(v) => up("mother_income", v)}>
                <SelectTrigger><SelectValue placeholder="Pilih" /></SelectTrigger>
                <SelectContent>{INCOME_OPTIONS.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="No. HP" full><Input value={data.mother_phone ?? ""} onChange={(e) => up("mother_phone", e.target.value)} /></Field>
          </Section>
          <Section title="Data Wali">
            <Field label="Nama Wali"><Input value={data.guardian_name ?? ""} onChange={(e) => up("guardian_name", e.target.value)} /></Field>
            <Field label="Hubungan"><Input value={data.guardian_relationship ?? ""} onChange={(e) => up("guardian_relationship", e.target.value)} /></Field>
            <Field label="Pekerjaan"><Input value={data.guardian_occupation ?? ""} onChange={(e) => up("guardian_occupation", e.target.value)} /></Field>
            <Field label="Penghasilan / Bulan">
              <Select value={data.guardian_income ?? ""} onValueChange={(v) => up("guardian_income", v)}>
                <SelectTrigger><SelectValue placeholder="Pilih" /></SelectTrigger>
                <SelectContent>{INCOME_OPTIONS.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="No. HP"><Input value={data.guardian_phone ?? ""} onChange={(e) => up("guardian_phone", e.target.value)} /></Field>
          </Section>
          <Section title="Alamat">
            <Field label="No. Kartu Keluarga" hint="16 digit angka.">
              <Input inputMode="numeric" maxLength={16} value={data.family_card_number ?? ""}
                onChange={(e) => up("family_card_number", onlyDigits(e.target.value) || null)} />
            </Field>
            <Field label="Alamat" full><Textarea rows={2} value={data.address ?? ""} onChange={(e) => up("address", e.target.value)} /></Field>
            <Field label="RT"><Input value={data.rt ?? ""} onChange={(e) => up("rt", e.target.value)} /></Field>
            <Field label="RW"><Input value={data.rw ?? ""} onChange={(e) => up("rw", e.target.value)} /></Field>
            <Field label="Desa / Kelurahan"><Input value={data.village ?? ""} onChange={(e) => up("village", e.target.value)} /></Field>
            <Field label="Kecamatan"><Input value={data.district ?? ""} onChange={(e) => up("district", e.target.value)} /></Field>
            <Field label="Kabupaten / Kota"><Input value={data.regency ?? ""} onChange={(e) => up("regency", e.target.value)} /></Field>
            <Field label="Provinsi"><Input value={data.province ?? ""} onChange={(e) => up("province", e.target.value)} /></Field>
            <Field label="Kode Pos"><Input value={data.postal_code ?? ""} onChange={(e) => up("postal_code", e.target.value)} /></Field>
            <Field label="Transportasi"><Input value={data.transportation ?? ""} onChange={(e) => up("transportation", e.target.value)} placeholder="Jalan Kaki / Sepeda / Motor" /></Field>
            <Field label="Jarak ke Sekolah"><Input value={data.distance_from_school ?? ""} onChange={(e) => up("distance_from_school", e.target.value)} placeholder="contoh: 2 km" /></Field>
          </Section>
        </TabsContent>

        <TabsContent value="academic" className="mt-4 space-y-4">
          <Section title="Data Akademik" description="Kelas dan tahun ajaran disimpan dalam Riwayat Kelas. Penempatan baru otomatis menutup riwayat sebelumnya.">
            <Field label="Sekolah Asal"><Input value={data.previous_school ?? ""} onChange={(e) => up("previous_school", e.target.value)} /></Field>
            <Field label="Tanggal Masuk"><Input type="date" value={data.entry_date ?? ""} onChange={(e) => up("entry_date", e.target.value)} /></Field>
            <Field label="Jenis Pendaftaran">
              <Select value={data.admission_type ?? ""} onValueChange={(v) => up("admission_type", v)}>
                <SelectTrigger><SelectValue placeholder="Pilih" /></SelectTrigger>
                <SelectContent>
                  {ADMISSION_TYPE_OPTIONS.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Kelas" full>
              <Select value={classId} onValueChange={setClassId}>
                <SelectTrigger><SelectValue placeholder="Pilih kelas" /></SelectTrigger>
                <SelectContent>
                  {classes.map((c: any) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
              <p className="mt-1 text-xs text-muted-foreground">
                Tahun ajaran otomatis mengikuti Tahun Ajaran Aktif: <b>{(activeYear as any)?.name ?? "Belum diatur di Pengaturan"}</b>.
              </p>
            </Field>
          </Section>
        </TabsContent>

        <TabsContent value="health" className="mt-4 space-y-4">
          <Section title="Data Kesehatan">
            <Field label="Riwayat Penyakit" full><Textarea rows={2} value={data.medical_history ?? ""} onChange={(e) => up("medical_history", e.target.value)} /></Field>
            <Field label="Alergi" full><Textarea rows={2} value={data.allergies ?? ""} onChange={(e) => up("allergies", e.target.value)} /></Field>
            <Field label="Disabilitas" full><Textarea rows={2} value={data.disabilities ?? ""} onChange={(e) => up("disabilities", e.target.value)} /></Field>
            <Field label="Imunisasi" full><Textarea rows={2} value={data.immunization ?? ""} onChange={(e) => up("immunization", e.target.value)} /></Field>
            <Field label="Catatan Kesehatan" full><Textarea rows={3} value={data.health_notes ?? ""} onChange={(e) => up("health_notes", e.target.value)} /></Field>
          </Section>
        </TabsContent>

        <TabsContent value="extras" className="mt-4">
          <Card className="rounded-2xl border border-border p-5 shadow-soft">
            <h3 className="mb-3 font-display text-base font-semibold">Ekstrakurikuler</h3>
            <p className="mb-4 text-xs text-muted-foreground">Pilih satu atau lebih ekstrakurikuler yang diikuti siswa.</p>
            <div className="grid grid-cols-2 gap-2 md:grid-cols-3 lg:grid-cols-4">
              {allEskuls.map((e) => {
                const checked = eskuls.includes(e.id);
                return (
                  <label key={e.id} className={`flex cursor-pointer items-center gap-2 rounded-xl border p-3 transition-colors ${checked ? "border-primary bg-primary-soft" : "border-border hover:bg-muted/50"}`}>
                    <Checkbox checked={checked} onCheckedChange={(v) => {
                      setEskuls((arr) => v ? [...arr, e.id] : arr.filter((x) => x !== e.id));
                    }} />
                    <span className="text-sm">{e.name}</span>
                  </label>
                );
              })}
            </div>
            {eskuls.length > 0 && (
              <div className="mt-4 flex flex-wrap gap-1.5">
                {eskuls.map((id) => {
                  const e = allEskuls.find((x) => x.id === id);
                  return e ? <Badge key={id} className="bg-primary-soft text-primary border-transparent">{e.name}</Badge> : null;
                })}
              </div>
            )}
          </Card>
        </TabsContent>

        <TabsContent value="documents" className="mt-4">
          <Card className="rounded-2xl border border-border p-5 shadow-soft">
            <h3 className="mb-1 font-display text-base font-semibold">Dokumen Siswa</h3>
            <p className="mb-4 text-xs text-muted-foreground">Unggah akta, kartu keluarga, ijazah, dan dokumen lain.</p>
            {!studentId && <p className="rounded-xl bg-warning/10 p-3 text-sm text-warning-foreground">Simpan data siswa terlebih dahulu sebelum mengunggah dokumen.</p>}
            {studentId && (
              <>
                <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
                  {DOC_TYPES.map((t) => (
                    <label key={t} className="cursor-pointer rounded-xl border border-dashed border-border p-4 text-center hover:bg-muted/30">
                      <input type="file" className="hidden" accept="image/*,application/pdf" onChange={(e) => {
                        const f = e.target.files?.[0]; if (f) handleDocUpload(f, t);
                      }} />
                      <Upload className="mx-auto h-5 w-5 text-muted-foreground" />
                      <div className="mt-2 text-sm font-medium">{t}</div>
                      <div className="text-xs text-muted-foreground">Klik untuk unggah</div>
                    </label>
                  ))}
                </div>
                {docs.length > 0 && (
                  <div className="mt-5">
                    <div className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">Dokumen Terunggah</div>
                    <div className="grid gap-2 md:grid-cols-2">
                      {docs.map((d) => (
                        <div key={d.id} className="flex items-center gap-3 rounded-xl border border-border p-3">
                          <FileText className="h-5 w-5 shrink-0 text-primary" />
                          <div className="min-w-0 flex-1">
                            <div className="truncate text-sm font-medium">{d.doc_type}</div>
                            <div className="truncate text-xs text-muted-foreground">{d.file_name}</div>
                          </div>
                          {docPreviews[d.id] && (
                            <Button variant="ghost" size="icon" asChild>
                              <a href={docPreviews[d.id]} target="_blank" rel="noreferrer"><ExternalLink className="h-4 w-4" /></a>
                            </Button>
                          )}
                          <Button variant="ghost" size="icon" className="text-destructive" onClick={() => deleteDoc(d.id)}>
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </Card>
        </TabsContent>
      </Tabs>

      <div className="sticky bottom-4 z-10 flex items-center justify-end gap-2 rounded-2xl border border-border bg-card/95 p-3 shadow-card backdrop-blur">
        <Button type="button" variant="outline" onClick={onCancel}><X className="mr-2 h-4 w-4" /> Batal</Button>
        <Button type="submit" disabled={saving}>
          {saving ? <>Menyimpan…</> : <><Save className="mr-2 h-4 w-4" /> Simpan</>}
        </Button>
      </div>
    </form>
  );
}

function PhotoPreview({ path }: { path: string }) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => { signedUrl(path).then(setUrl).catch(() => setUrl(null)); }, [path]);
  return url ? <img src={url} alt="Foto siswa" className="h-full w-full object-cover" /> : <Check className="h-5 w-5 text-success" />;
}
