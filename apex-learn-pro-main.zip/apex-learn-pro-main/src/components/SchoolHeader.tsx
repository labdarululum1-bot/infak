import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { fetchSchoolProfile, signedUrl } from "@/lib/db";

/**
 * Official school header (Kop Sekolah) used at the top of the Student Profile,
 * the printable profile and any grade printout. Data comes from School Settings.
 */
export function SchoolHeader({ subtitle }: { subtitle?: string }) {
  const { data: school } = useQuery({ queryKey: ["school-profile"], queryFn: fetchSchoolProfile });
  const [logo, setLogo] = useState<string | null>(null);

  useEffect(() => {
    const p = (school as any)?.logo_url;
    if (p) signedUrl(p).then(setLogo).catch(() => setLogo(null));
    else setLogo(null);
  }, [school]);

  if (!school) return null;
  const s: any = school;
  const contactBits = [
    s.address,
    s.phone ? `Telp. ${s.phone}` : null,
    s.email,
    s.website,
  ].filter(Boolean);
  const idBits = [
    s.npsn ? `NPSN: ${s.npsn}` : null,
    s.nss ? `NSM/NSS: ${s.nss}` : null,
  ].filter(Boolean);

  return (
    <div className="school-header rounded-2xl border border-border bg-card p-5 shadow-soft print:rounded-none print:border-0 print:p-3 print:shadow-none">
      <div className="flex items-center gap-4">
        <div className="grid h-20 w-20 shrink-0 place-items-center overflow-hidden rounded-xl bg-muted print:h-16 print:w-16">
          {logo ? (
            <img src={logo} alt="Logo sekolah" className="h-full w-full object-contain" />
          ) : (
            <span className="text-[10px] text-muted-foreground">LOGO</span>
          )}
        </div>
        <div className="min-w-0 flex-1 text-center">
          {s.foundation_name && (
            <div className="text-sm font-semibold uppercase tracking-wide">
              {s.foundation_name}
            </div>
          )}
          <div className="font-display text-xl font-bold uppercase leading-tight">
            {s.school_name ?? "Nama Sekolah"}
          </div>
          {contactBits.length > 0 && (
            <div className="mt-1 text-xs text-muted-foreground">
              {contactBits.join(" · ")}
            </div>
          )}
          {idBits.length > 0 && (
            <div className="text-xs text-muted-foreground">{idBits.join(" · ")}</div>
          )}
        </div>
        <div className="hidden h-20 w-20 shrink-0 md:block print:hidden" aria-hidden />
      </div>
      <div className="mt-3 border-t-2 border-foreground/80" />
      {subtitle && (
        <div className="mt-3 text-center font-display text-base font-semibold">{subtitle}</div>
      )}
    </div>
  );
}
