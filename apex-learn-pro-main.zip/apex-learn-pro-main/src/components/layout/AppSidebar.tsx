import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard, Users, GraduationCap, UserCheck, FileBarChart,
  Settings, GraduationCap as SchoolIcon, Database as DatabaseIcon, UserSquare, Library, ClipboardList,
} from "lucide-react";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel,
  SidebarHeader, SidebarMenu, SidebarMenuButton, SidebarMenuItem, useSidebar,
} from "@/components/ui/sidebar";

const mainItems = [
  { title: "Dashboard", url: "/", icon: LayoutDashboard },
  { title: "Siswa", url: "/siswa", icon: Users },
  { title: "Alumni", url: "/alumni", icon: UserCheck },
  { title: "Kelas", url: "/kelas", icon: GraduationCap },
  { title: "Guru", url: "/guru", icon: UserSquare },
  { title: "Nilai", url: "/nilai", icon: ClipboardList },
];

const toolItems = [
  { title: "Master Data", url: "/master", icon: Library },
  { title: "Laporan", url: "/laporan", icon: FileBarChart },
  { title: "Database", url: "/database", icon: DatabaseIcon },
  { title: "Pengaturan", url: "/pengaturan", icon: Settings },
];

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const isActive = (url: string) => (url === "/" ? pathname === "/" : pathname.startsWith(url));

  return (
    <Sidebar
      collapsible="icon"
      className="border-none bg-transparent [&>[data-sidebar=sidebar]]:!bg-transparent"
    >
      {/* Floating rounded panel */}
      <div className="m-3 flex h-[calc(100svh-1.5rem)] flex-col overflow-hidden rounded-2xl bg-sidebar text-sidebar-foreground shadow-float ring-1 ring-white/5">
        <SidebarHeader className="border-b border-sidebar-border/60 !bg-transparent">
          <div className="flex items-center gap-3 px-1 py-2">
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-primary to-[oklch(0.65_0.22_262)] text-primary-foreground shadow-glow">
              <SchoolIcon className="h-5 w-5" />
            </div>
            {!collapsed && (
              <div className="min-w-0">
                <div className="truncate font-display text-sm font-bold leading-tight text-white">Buku Induk</div>
                <div className="truncate text-[11px] font-medium uppercase tracking-wider text-sidebar-foreground/60">
                  School Management
                </div>
              </div>
            )}
          </div>
        </SidebarHeader>

        <SidebarContent className="!bg-transparent px-1 py-2 [&::-webkit-scrollbar]:w-0">
          <SidebarGroup>
            {!collapsed && (
              <SidebarGroupLabel className="px-3 text-[10px] font-semibold uppercase tracking-[0.14em] text-sidebar-foreground/45">
                Overview
              </SidebarGroupLabel>
            )}
            <SidebarGroupContent>
              <SidebarMenu className="gap-1">
                {mainItems.map((item) => {
                  const active = isActive(item.url);
                  return (
                    <SidebarMenuItem key={item.url}>
                      <SidebarMenuButton
                        asChild
                        isActive={active}
                        tooltip={item.title}
                        className="group/item relative h-10 rounded-lg px-3 font-medium text-sidebar-foreground/80 transition hover:bg-white/[0.06] hover:text-white data-[active=true]:bg-primary data-[active=true]:text-primary-foreground data-[active=true]:shadow-glow"
                      >
                        <Link to={item.url} className="flex items-center gap-3">
                          <item.icon className="h-[18px] w-[18px] shrink-0" />
                          <span className="truncate">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>

          <SidebarGroup className="mt-4">
            {!collapsed && (
              <SidebarGroupLabel className="px-3 text-[10px] font-semibold uppercase tracking-[0.14em] text-sidebar-foreground/45">
                System
              </SidebarGroupLabel>
            )}
            <SidebarGroupContent>
              <SidebarMenu className="gap-1">
                {toolItems.map((item) => {
                  const active = isActive(item.url);
                  return (
                    <SidebarMenuItem key={item.url}>
                      <SidebarMenuButton
                        asChild
                        isActive={active}
                        tooltip={item.title}
                        className="h-10 rounded-lg px-3 font-medium text-sidebar-foreground/80 transition hover:bg-white/[0.06] hover:text-white data-[active=true]:bg-primary data-[active=true]:text-primary-foreground data-[active=true]:shadow-glow"
                      >
                        <Link to={item.url} className="flex items-center gap-3">
                          <item.icon className="h-[18px] w-[18px] shrink-0" />
                          <span className="truncate">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>

        {/* Footer card */}
        {!collapsed && (
          <div className="mt-auto p-3">
            <div className="rounded-xl border border-white/5 bg-white/[0.04] p-3">
              <div className="flex items-center gap-2 text-[11px] font-medium text-sidebar-foreground/60">
                <span className="inline-flex h-1.5 w-1.5 rounded-full bg-success animate-pulse" />
                System online
              </div>
              <div className="mt-1 text-xs text-sidebar-foreground/50">v1.0 · Enterprise Edition</div>
            </div>
          </div>
        )}
      </div>
    </Sidebar>
  );
}
