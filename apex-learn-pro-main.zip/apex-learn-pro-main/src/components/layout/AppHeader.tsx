import { useState, useEffect, useRef } from "react";
import { Moon, Sun, Search, Command, Bell, ChevronRight, Home } from "lucide-react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { SidebarTrigger } from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import {
  CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList,
} from "@/components/ui/command";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";

const routeLabels: Record<string, string> = {
  "": "Dashboard",
  siswa: "Siswa",
  guru: "Guru",
  alumni: "Alumni",
  kelas: "Kelas",
  nilai: "Nilai",
  laporan: "Laporan",
  master: "Master Data",
  database: "Database",
  pengaturan: "Pengaturan",
  profil: "Profil",
  edit: "Edit",
  tambah: "Tambah",
};

function Breadcrumbs() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const parts = pathname.split("/").filter(Boolean);
  return (
    <nav className="hidden items-center gap-1.5 text-sm md:flex">
      <Link to="/" className="flex items-center gap-1 text-muted-foreground transition hover:text-foreground">
        <Home className="h-3.5 w-3.5" />
      </Link>
      {parts.length === 0 && (
        <>
          <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/50" />
          <span className="font-medium text-foreground">Dashboard</span>
        </>
      )}
      {parts.map((p, i) => {
        const isLast = i === parts.length - 1;
        const label = routeLabels[p] ?? (p.length > 12 ? p.slice(0, 8) + "…" : p);
        return (
          <span key={i} className="flex items-center gap-1.5">
            <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/50" />
            <span className={isLast ? "font-medium text-foreground" : "text-muted-foreground"}>{label}</span>
          </span>
        );
      })}
    </nav>
  );
}

export function AppHeader() {
  const [dark, setDark] = useState(false);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const navigate = useNavigate();
  const debounceRef = useRef<any>(null);
  const [debounced, setDebounced] = useState("");

  useEffect(() => {
    const stored = localStorage.getItem("theme");
    const prefer = stored === "dark" || (!stored && window.matchMedia("(prefers-color-scheme: dark)").matches);
    setDark(prefer);
    document.documentElement.classList.toggle("dark", prefer);
  }, []);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen((o) => !o);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => setDebounced(query.trim()), 180);
  }, [query]);

  const { data: results = [] } = useQuery({
    queryKey: ["global-search", debounced],
    enabled: debounced.length >= 2,
    queryFn: async () => {
      const term = `%${debounced}%`;
      const cols = "id,full_name,nis,nisn,nik,master_book_number,family_card_number,mobile_phone,father_name,mother_name,status";
      const orParts = [
        `full_name.ilike.${term}`, `nis.ilike.${term}`, `nisn.ilike.${term}`,
        `nik.ilike.${term}`, `master_book_number.ilike.${term}`,
        `family_card_number.ilike.${term}`, `mobile_phone.ilike.${term}`,
        `father_name.ilike.${term}`, `mother_name.ilike.${term}`,
      ].join(",");
      const { data } = await supabase.from("students").select(cols).or(orParts).limit(20);
      return data ?? [];
    },
  });

  const toggle = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("theme", next ? "dark" : "light");
  };

  function openStudent(id: string) {
    setOpen(false);
    navigate({ to: "/siswa/$id/profil", params: { id } });
  }

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-border/70 glass px-4 sm:px-6">
      <SidebarTrigger className="h-9 w-9 rounded-lg hover:bg-muted" />
      <div className="hidden h-6 w-px bg-border md:block" />
      <Breadcrumbs />

      {/* Search */}
      <button
        onClick={() => setOpen(true)}
        className="ml-auto flex h-9 w-full max-w-sm items-center gap-2 rounded-lg border border-border bg-background/60 px-3 text-sm text-muted-foreground shadow-sm transition hover:border-primary/30 hover:bg-background hover:shadow-glow/20 md:ml-6"
      >
        <Search className="h-4 w-4" />
        <span className="flex-1 truncate text-left">Cari siswa, NIS, NIK…</span>
        <kbd className="hidden items-center gap-0.5 rounded border border-border bg-muted px-1.5 py-0.5 text-[10px] font-semibold sm:inline-flex">
          <Command className="h-3 w-3" />K
        </kbd>
      </button>

      <div className="ml-auto flex items-center gap-1 md:ml-2">
        <Button variant="ghost" size="icon" className="relative h-9 w-9 rounded-lg" aria-label="Notifikasi">
          <Bell className="h-[18px] w-[18px]" />
          <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-destructive ring-2 ring-background" />
        </Button>
        <Button variant="ghost" size="icon" className="h-9 w-9 rounded-lg" onClick={toggle} aria-label="Toggle tema">
          {dark ? <Sun className="h-[18px] w-[18px]" /> : <Moon className="h-[18px] w-[18px]" />}
        </Button>

        <div className="mx-1 h-6 w-px bg-border" />

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-2 rounded-lg p-1 pr-2 transition hover:bg-muted">
              <div className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-primary to-[oklch(0.65_0.22_262)] text-xs font-bold text-primary-foreground">
                AD
              </div>
              <div className="hidden text-left sm:block">
                <div className="text-xs font-semibold leading-tight">Administrator</div>
                <div className="text-[10px] text-muted-foreground">admin@sekolah.id</div>
              </div>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>Akun Saya</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link to="/pengaturan">Pengaturan</Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link to="/database">Database</Link>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <CommandDialog open={open} onOpenChange={setOpen}>
        <CommandInput placeholder="Cari nama, NIS, NISN, NIK, no. KK, no. HP, nama orang tua…" value={query} onValueChange={setQuery} />
        <CommandList>
          {debounced.length < 2 ? (
            <CommandEmpty>Ketik minimal 2 karakter untuk mencari…</CommandEmpty>
          ) : results.length === 0 ? (
            <CommandEmpty>Tidak ada hasil.</CommandEmpty>
          ) : (
            <CommandGroup heading="Siswa">
              {results.map((s: any) => (
                <CommandItem key={s.id} value={`${s.full_name} ${s.nis ?? ""} ${s.nisn ?? ""} ${s.nik ?? ""}`} onSelect={() => openStudent(s.id)}>
                  <div className="flex w-full items-center justify-between gap-3">
                    <div className="min-w-0">
                      <div className="truncate font-medium">{s.full_name}</div>
                      <div className="truncate text-xs text-muted-foreground tabular-nums">
                        {s.master_book_number ? `No.Induk ${s.master_book_number} · ` : ""}NIS {s.nis ?? "—"} · NISN {s.nisn ?? "—"}
                      </div>
                    </div>
                    <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] ${s.status === "Lulus" ? "bg-muted text-muted-foreground" : "bg-primary-soft text-primary"}`}>
                      {s.status}
                    </span>
                  </div>
                </CommandItem>
              ))}
            </CommandGroup>
          )}
        </CommandList>
      </CommandDialog>
    </header>
  );
}
