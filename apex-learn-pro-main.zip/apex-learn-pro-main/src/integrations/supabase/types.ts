export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      academic_years: {
        Row: {
          created_at: string
          id: string
          is_active: boolean
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      classes: {
        Row: {
          academic_year_id: string | null
          created_at: string
          grade_level: string | null
          homeroom_teacher: string | null
          id: string
          name: string
          updated_at: string
        }
        Insert: {
          academic_year_id?: string | null
          created_at?: string
          grade_level?: string | null
          homeroom_teacher?: string | null
          id?: string
          name: string
          updated_at?: string
        }
        Update: {
          academic_year_id?: string | null
          created_at?: string
          grade_level?: string | null
          homeroom_teacher?: string | null
          id?: string
          name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "classes_academic_year_id_fkey"
            columns: ["academic_year_id"]
            isOneToOne: false
            referencedRelation: "academic_years"
            referencedColumns: ["id"]
          },
        ]
      }
      database_backups: {
        Row: {
          created_at: string
          file_path: string
          file_size_bytes: number
          id: string
          note: string | null
        }
        Insert: {
          created_at?: string
          file_path: string
          file_size_bytes: number
          id?: string
          note?: string | null
        }
        Update: {
          created_at?: string
          file_path?: string
          file_size_bytes?: number
          id?: string
          note?: string | null
        }
        Relationships: []
      }
      extracurriculars: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      grades: {
        Row: {
          academic_year_id: string | null
          class_id: string | null
          created_at: string
          final_score: number | null
          id: string
          knowledge_score: number | null
          semester: number
          skills_score: number | null
          student_id: string
          subject_id: string
          updated_at: string
        }
        Insert: {
          academic_year_id?: string | null
          class_id?: string | null
          created_at?: string
          final_score?: number | null
          id?: string
          knowledge_score?: number | null
          semester: number
          skills_score?: number | null
          student_id: string
          subject_id: string
          updated_at?: string
        }
        Update: {
          academic_year_id?: string | null
          class_id?: string | null
          created_at?: string
          final_score?: number | null
          id?: string
          knowledge_score?: number | null
          semester?: number
          skills_score?: number | null
          student_id?: string
          subject_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "grades_academic_year_id_fkey"
            columns: ["academic_year_id"]
            isOneToOne: false
            referencedRelation: "academic_years"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "grades_class_id_fkey"
            columns: ["class_id"]
            isOneToOne: false
            referencedRelation: "classes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "grades_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "grades_subject_id_fkey"
            columns: ["subject_id"]
            isOneToOne: false
            referencedRelation: "subjects"
            referencedColumns: ["id"]
          },
        ]
      }
      occupations: {
        Row: {
          created_at: string
          id: string
          is_active: boolean
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      school_profile: {
        Row: {
          accreditation: string | null
          active_academic_year_id: string | null
          address: string | null
          current_academic_year: string | null
          email: string | null
          foundation_name: string | null
          id: number
          logo_url: string | null
          npsn: string | null
          nss: string | null
          phone: string | null
          principal_name: string | null
          school_name: string | null
          updated_at: string
          website: string | null
        }
        Insert: {
          accreditation?: string | null
          active_academic_year_id?: string | null
          address?: string | null
          current_academic_year?: string | null
          email?: string | null
          foundation_name?: string | null
          id?: number
          logo_url?: string | null
          npsn?: string | null
          nss?: string | null
          phone?: string | null
          principal_name?: string | null
          school_name?: string | null
          updated_at?: string
          website?: string | null
        }
        Update: {
          accreditation?: string | null
          active_academic_year_id?: string | null
          address?: string | null
          current_academic_year?: string | null
          email?: string | null
          foundation_name?: string | null
          id?: number
          logo_url?: string | null
          npsn?: string | null
          nss?: string | null
          phone?: string | null
          principal_name?: string | null
          school_name?: string | null
          updated_at?: string
          website?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "school_profile_active_academic_year_id_fkey"
            columns: ["active_academic_year_id"]
            isOneToOne: false
            referencedRelation: "academic_years"
            referencedColumns: ["id"]
          },
        ]
      }
      student_class_histories: {
        Row: {
          academic_year_id: string
          class_id: string
          created_at: string
          end_date: string | null
          id: string
          is_active: boolean
          note: string | null
          start_date: string
          student_id: string
          updated_at: string
        }
        Insert: {
          academic_year_id: string
          class_id: string
          created_at?: string
          end_date?: string | null
          id?: string
          is_active?: boolean
          note?: string | null
          start_date?: string
          student_id: string
          updated_at?: string
        }
        Update: {
          academic_year_id?: string
          class_id?: string
          created_at?: string
          end_date?: string | null
          id?: string
          is_active?: boolean
          note?: string | null
          start_date?: string
          student_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "student_class_histories_academic_year_id_fkey"
            columns: ["academic_year_id"]
            isOneToOne: false
            referencedRelation: "academic_years"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "student_class_histories_class_id_fkey"
            columns: ["class_id"]
            isOneToOne: false
            referencedRelation: "classes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "student_class_histories_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      student_documents: {
        Row: {
          created_at: string
          doc_type: string
          file_name: string | null
          file_url: string
          id: string
          student_id: string
        }
        Insert: {
          created_at?: string
          doc_type: string
          file_name?: string | null
          file_url: string
          id?: string
          student_id: string
        }
        Update: {
          created_at?: string
          doc_type?: string
          file_name?: string | null
          file_url?: string
          id?: string
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "student_documents_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      student_extracurriculars: {
        Row: {
          extracurricular_id: string
          student_id: string
        }
        Insert: {
          extracurricular_id: string
          student_id: string
        }
        Update: {
          extracurricular_id?: string
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "student_extracurriculars_extracurricular_id_fkey"
            columns: ["extracurricular_id"]
            isOneToOne: false
            referencedRelation: "extracurriculars"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "student_extracurriculars_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      students: {
        Row: {
          address: string | null
          admission_type: string | null
          allergies: string | null
          attendance_number: number | null
          birth_order: number | null
          child_status: string | null
          created_at: string
          current_class_id: string | null
          date_of_birth: string | null
          disabilities: string | null
          distance_from_school: string | null
          district: string | null
          entry_date: string | null
          exit_date: string | null
          exit_reason: string | null
          family_card_number: string | null
          father_education: string | null
          father_income: string | null
          father_name: string | null
          father_nik: string | null
          father_occupation: string | null
          father_phone: string | null
          full_name: string
          gender: string | null
          guardian_income: string | null
          guardian_name: string | null
          guardian_occupation: string | null
          guardian_phone: string | null
          guardian_relationship: string | null
          health_notes: string | null
          id: string
          immunization: string | null
          is_boarding: boolean
          master_book_number: string | null
          medical_history: string | null
          mobile_phone: string | null
          mother_education: string | null
          mother_income: string | null
          mother_name: string | null
          mother_nik: string | null
          mother_occupation: string | null
          mother_phone: string | null
          nationality: string | null
          nik: string | null
          nis: string | null
          nisn: string | null
          photo_url: string | null
          place_of_birth: string | null
          postal_code: string | null
          previous_school: string | null
          province: string | null
          regency: string | null
          religion: string | null
          rt: string | null
          rw: string | null
          siblings_count: number | null
          status: string
          transportation: string | null
          updated_at: string
          village: string | null
        }
        Insert: {
          address?: string | null
          admission_type?: string | null
          allergies?: string | null
          attendance_number?: number | null
          birth_order?: number | null
          child_status?: string | null
          created_at?: string
          current_class_id?: string | null
          date_of_birth?: string | null
          disabilities?: string | null
          distance_from_school?: string | null
          district?: string | null
          entry_date?: string | null
          exit_date?: string | null
          exit_reason?: string | null
          family_card_number?: string | null
          father_education?: string | null
          father_income?: string | null
          father_name?: string | null
          father_nik?: string | null
          father_occupation?: string | null
          father_phone?: string | null
          full_name: string
          gender?: string | null
          guardian_income?: string | null
          guardian_name?: string | null
          guardian_occupation?: string | null
          guardian_phone?: string | null
          guardian_relationship?: string | null
          health_notes?: string | null
          id?: string
          immunization?: string | null
          is_boarding?: boolean
          master_book_number?: string | null
          medical_history?: string | null
          mobile_phone?: string | null
          mother_education?: string | null
          mother_income?: string | null
          mother_name?: string | null
          mother_nik?: string | null
          mother_occupation?: string | null
          mother_phone?: string | null
          nationality?: string | null
          nik?: string | null
          nis?: string | null
          nisn?: string | null
          photo_url?: string | null
          place_of_birth?: string | null
          postal_code?: string | null
          previous_school?: string | null
          province?: string | null
          regency?: string | null
          religion?: string | null
          rt?: string | null
          rw?: string | null
          siblings_count?: number | null
          status?: string
          transportation?: string | null
          updated_at?: string
          village?: string | null
        }
        Update: {
          address?: string | null
          admission_type?: string | null
          allergies?: string | null
          attendance_number?: number | null
          birth_order?: number | null
          child_status?: string | null
          created_at?: string
          current_class_id?: string | null
          date_of_birth?: string | null
          disabilities?: string | null
          distance_from_school?: string | null
          district?: string | null
          entry_date?: string | null
          exit_date?: string | null
          exit_reason?: string | null
          family_card_number?: string | null
          father_education?: string | null
          father_income?: string | null
          father_name?: string | null
          father_nik?: string | null
          father_occupation?: string | null
          father_phone?: string | null
          full_name?: string
          gender?: string | null
          guardian_income?: string | null
          guardian_name?: string | null
          guardian_occupation?: string | null
          guardian_phone?: string | null
          guardian_relationship?: string | null
          health_notes?: string | null
          id?: string
          immunization?: string | null
          is_boarding?: boolean
          master_book_number?: string | null
          medical_history?: string | null
          mobile_phone?: string | null
          mother_education?: string | null
          mother_income?: string | null
          mother_name?: string | null
          mother_nik?: string | null
          mother_occupation?: string | null
          mother_phone?: string | null
          nationality?: string | null
          nik?: string | null
          nis?: string | null
          nisn?: string | null
          photo_url?: string | null
          place_of_birth?: string | null
          postal_code?: string | null
          previous_school?: string | null
          province?: string | null
          regency?: string | null
          religion?: string | null
          rt?: string | null
          rw?: string | null
          siblings_count?: number | null
          status?: string
          transportation?: string | null
          updated_at?: string
          village?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "students_current_class_id_fkey"
            columns: ["current_class_id"]
            isOneToOne: false
            referencedRelation: "classes"
            referencedColumns: ["id"]
          },
        ]
      }
      subjects: {
        Row: {
          code: string | null
          created_at: string
          id: string
          is_active: boolean
          name: string
          updated_at: string
        }
        Insert: {
          code?: string | null
          created_at?: string
          id?: string
          is_active?: boolean
          name: string
          updated_at?: string
        }
        Update: {
          code?: string | null
          created_at?: string
          id?: string
          is_active?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      teacher_documents: {
        Row: {
          created_at: string
          doc_type: string
          file_name: string | null
          file_url: string
          id: string
          teacher_id: string
        }
        Insert: {
          created_at?: string
          doc_type: string
          file_name?: string | null
          file_url: string
          id?: string
          teacher_id: string
        }
        Update: {
          created_at?: string
          doc_type?: string
          file_name?: string | null
          file_url?: string
          id?: string
          teacher_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "teacher_documents_teacher_id_fkey"
            columns: ["teacher_id"]
            isOneToOne: false
            referencedRelation: "teachers"
            referencedColumns: ["id"]
          },
        ]
      }
      teacher_subjects: {
        Row: {
          subject_id: string
          teacher_id: string
        }
        Insert: {
          subject_id: string
          teacher_id: string
        }
        Update: {
          subject_id?: string
          teacher_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "teacher_subjects_subject_id_fkey"
            columns: ["subject_id"]
            isOneToOne: false
            referencedRelation: "subjects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "teacher_subjects_teacher_id_fkey"
            columns: ["teacher_id"]
            isOneToOne: false
            referencedRelation: "teachers"
            referencedColumns: ["id"]
          },
        ]
      }
      teachers: {
        Row: {
          address: string | null
          created_at: string
          date_of_birth: string | null
          education: string | null
          email: string | null
          employment_status: string | null
          full_name: string
          gender: string | null
          id: string
          major: string | null
          nik: string | null
          nip: string | null
          nuptk: string | null
          phone: string | null
          photo_url: string | null
          place_of_birth: string | null
          position: string | null
          religion: string | null
          university: string | null
          updated_at: string
        }
        Insert: {
          address?: string | null
          created_at?: string
          date_of_birth?: string | null
          education?: string | null
          email?: string | null
          employment_status?: string | null
          full_name: string
          gender?: string | null
          id?: string
          major?: string | null
          nik?: string | null
          nip?: string | null
          nuptk?: string | null
          phone?: string | null
          photo_url?: string | null
          place_of_birth?: string | null
          position?: string | null
          religion?: string | null
          university?: string | null
          updated_at?: string
        }
        Update: {
          address?: string | null
          created_at?: string
          date_of_birth?: string | null
          education?: string | null
          email?: string | null
          employment_status?: string | null
          full_name?: string
          gender?: string | null
          id?: string
          major?: string | null
          nik?: string | null
          nip?: string | null
          nuptk?: string | null
          phone?: string | null
          photo_url?: string | null
          place_of_birth?: string | null
          position?: string | null
          religion?: string | null
          university?: string | null
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
