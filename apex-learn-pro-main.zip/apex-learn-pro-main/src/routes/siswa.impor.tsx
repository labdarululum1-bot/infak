import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQueryClient, useQuery } from "@tanstack/react-query";
import { useState } from "react";
import * as XLSX from "xlsx";
import { ChevronLeft, Download, Upload, CheckCircle2, AlertTriangle, Copy } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { fetchClasses, fetchAcademicYears } from "@/lib/db";
import { PageHeader } from "@/components/PageHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/siswa/impor")({
  head: () => ({ meta: [{ title: "Impor Siswa — Buku Induk" }] }),
  component: ImportStudents,
});

const TEMPLATE_COLUMNS = [
  "NIS", "NISN", "NIK", "Nama Lengkap", "Jenis Kelamin", "Tempat Lahir", "Tanggal Lahir",
  "Agama", "Kewarganegaraan", "Status Anak", "Anak ke", "Jumlah Saudara", "Pesantren",
  "Nama Ayah", "NIK Ayah", "Pekerjaan Ayah", "Pendidikan Ayah", "HP Ayah",
  "Nama Ibu", "NIK Ibu", "Pekerjaan Ibu", "Pendidikan Ibu", "HP Ibu",
  "Nama Wali", "Hubungan Wali", "Pekerjaan Wali", "HP Wali",
  "No KK", "Alamat", "RT", "RW", "Desa", "Kecamatan", "Kabupaten", "Provinsi", "Kode Pos",
  "Transportasi", "Jarak ke Sekolah",
  "Sekolah Asal", "Tahun Masuk", "Tanggal Masuk", "Jenis Pendaftaran", "Kelas Masuk", "Nama Kelas Saat Ini", "Tahun Ajaran",
];

type Result = { imported: number; failed: number; duplicate: number; errors: { row: number; reason: string; name?: string }[] };

function downloadTemplate() {
  const ws = XLSX.utils.aoa_to_sheet([TEMPLATE_COLUMNS, [
    "1001", "0012345678", "3201010101010001", "Contoh Siswa", "Laki-laki", "Bandung", "2010-05-01",
    "Islam", "WNI", "Anak Kandung", 1, 2, "Tidak",
    "Bapak A", "", "Wiraswasta", "SMA", "0812000000",
    "Ibu B", "", "Ibu Rumah Tangga", "SMA", "0812000001",
    "", "", "", "",
    "", "Jl. Contoh No. 1", "001", "002", "Cibiru", "Cibiru", "Bandung", "Jawa Barat", "40615",
    "Sepeda", "2 km",
    "SDN 1 Contoh", "2024", "2024-07-15", "Baru", "VII", "VII-A", "2024/2025",
  ]]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Siswa");
  XLSX.writeFile(wb, "template-impor-siswa.xlsx");
}

function ImportStudents() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { data: classes = [] } = useQuery({ queryKey: ["classes"], queryFn: fetchClasses });
  const { data: years = [] } = useQuery({ queryKey: ["academic-years"], queryFn: fetchAcademicYears });
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<Result | null>(null);

  function pick<T = any>(row: any, key: string): T | undefined {
    return row[key] ?? row[key.toLowerCase()] ?? row[key.toUpperCase()];
  }

  async function handleFile(file: File) {
    setBusy(true); setResult(null);
    try {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: "array" });
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const rows: any[] = XLSX.utils.sheet_to_json(sheet, { defval: "" });

      // Existing NIS/NISN for duplicate detection
      const { data: existing } = await supabase.from("students").select("nis,nisn,nik");
      const existingNis = new Set((existing ?? []).map((s) => s.nis).filter(Boolean));
      const existingNisn = new Set((existing ?? []).map((s) => s.nisn).filter(Boolean));
      const existingNik = new Set((existing ?? []).map((s) => s.nik).filter(Boolean));

      const out: Result = { imported: 0, failed: 0, duplicate: 0, errors: [] };
      const classByName = new Map(classes.map((c: any) => [String(c.name).toLowerCase(), c.id]));
      const yearByName = new Map(years.map((y) => [String(y.name).toLowerCase(), y.id]));

      for (let i = 0; i < rows.length; i++) {
        const r = rows[i]; const rowNum = i + 2; // header is row 1
        const fullName = String(pick(r, "Nama Lengkap") ?? "").trim();
        if (!fullName) { out.failed++; out.errors.push({ row: rowNum, reason: "Nama lengkap kosong" }); continue; }

        const nis = String(pick(r, "NIS") ?? "").trim() || null;
        const nisn = String(pick(r, "NISN") ?? "").trim() || null;
        const nik = String(pick(r, "NIK") ?? "").trim() || null;

        if (nis && existingNis.has(nis)) { out.duplicate++; out.errors.push({ row: rowNum, name: fullName, reason: `NIS ${nis} sudah ada` }); continue; }
        if (nisn && existingNisn.has(nisn)) { out.duplicate++; out.errors.push({ row: rowNum, name: fullName, reason: `NISN ${nisn} sudah ada` }); continue; }
        if (nik && existingNik.has(nik)) { out.duplicate++; out.errors.push({ row: rowNum, name: fullName, reason: `NIK ${nik} sudah ada` }); continue; }
        if (nik && !/^[0-9]{16}$/.test(nik)) { out.failed++; out.errors.push({ row: rowNum, name: fullName, reason: "NIK harus 16 digit angka" }); continue; }

        const className = String(pick(r, "Nama Kelas Saat Ini") ?? "").trim().toLowerCase();
        const yearName = String(pick(r, "Tahun Ajaran") ?? "").trim().toLowerCase();
        const boarding = String(pick(r, "Pesantren") ?? "").trim().toLowerCase();

        const payload: any = {
          nis, nisn, nik, full_name: fullName,
          gender: pick(r, "Jenis Kelamin") || null,
          place_of_birth: pick(r, "Tempat Lahir") || null,
          date_of_birth: pick(r, "Tanggal Lahir") || null,
          religion: pick(r, "Agama") || null,
          nationality: pick(r, "Kewarganegaraan") || "WNI",
          child_status: pick(r, "Status Anak") || null,
          birth_order: Number(pick(r, "Anak ke")) || null,
          siblings_count: Number(pick(r, "Jumlah Saudara")) || null,
          is_boarding: ["ya", "y", "true", "1"].includes(boarding),
          father_name: pick(r, "Nama Ayah") || null, father_nik: pick(r, "NIK Ayah") || null,
          father_occupation: pick(r, "Pekerjaan Ayah") || null, father_education: pick(r, "Pendidikan Ayah") || null,
          father_phone: pick(r, "HP Ayah") || null,
          mother_name: pick(r, "Nama Ibu") || null, mother_nik: pick(r, "NIK Ibu") || null,
          mother_occupation: pick(r, "Pekerjaan Ibu") || null, mother_education: pick(r, "Pendidikan Ibu") || null,
          mother_phone: pick(r, "HP Ibu") || null,
          guardian_name: pick(r, "Nama Wali") || null, guardian_relationship: pick(r, "Hubungan Wali") || null,
          guardian_occupation: pick(r, "Pekerjaan Wali") || null, guardian_phone: pick(r, "HP Wali") || null,
          family_card_number: pick(r, "No KK") || null,
          address: pick(r, "Alamat") || null,
          rt: String(pick(r, "RT") ?? "") || null, rw: String(pick(r, "RW") ?? "") || null,
          village: pick(r, "Desa") || null, district: pick(r, "Kecamatan") || null,
          regency: pick(r, "Kabupaten") || null, province: pick(r, "Provinsi") || null,
          postal_code: String(pick(r, "Kode Pos") ?? "") || null,
          transportation: pick(r, "Transportasi") || null, distance_from_school: pick(r, "Jarak ke Sekolah") || null,
          previous_school: pick(r, "Sekolah Asal") || null,
          entry_date: pick(r, "Tanggal Masuk") || null,
          admission_type: pick(r, "Jenis Pendaftaran") || null,
          current_class_id: className ? classByName.get(className) ?? null : null,
          status: "Aktif",
        };
        const yearId = yearName ? yearByName.get(yearName) ?? null : null;

        const { data: ins, error } = await supabase.from("students").insert(payload).select("id").single();
        if (error) {
          out.failed++; out.errors.push({ row: rowNum, name: fullName, reason: error.message });
        } else {
          out.imported++;
          if (nis) existingNis.add(nis);
          if (nisn) existingNisn.add(nisn);
          if (nik) existingNik.add(nik);
          // Create class history if class + year resolved
          if (ins?.id && payload.current_class_id && yearId) {
            await supabase.from("student_class_histories").insert({
              student_id: ins.id, class_id: payload.current_class_id,
              academic_year_id: yearId, is_active: true,
            });
          }
        }
      }

      setResult(out);
      toast.success(`Impor selesai: ${out.imported} berhasil, ${out.duplicate} duplikat, ${out.failed} gagal`);
      qc.invalidateQueries({ queryKey: ["students"] });
    } catch (e: any) {
      toast.error("Gagal membaca file: " + e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-4xl">
      <Button variant="ghost" size="sm" onClick={() => navigate({ to: "/siswa" })} className="mb-2">
        <ChevronLeft className="mr-1 h-4 w-4" /> Kembali
      </Button>
      <PageHeader
        title="Impor Data Siswa"
        description="Unggah file Excel berisi data siswa. Sistem akan melewatkan baris dengan NIS atau NISN duplikat."
        actions={<Button variant="outline" onClick={downloadTemplate}><Download className="mr-2 h-4 w-4" />Unduh Template</Button>}
      />

      <Card className="rounded-2xl border border-dashed border-border p-10 text-center shadow-soft">
        <div className="mx-auto mb-3 grid h-14 w-14 place-items-center rounded-2xl bg-primary-soft text-primary"><Upload className="h-6 w-6" /></div>
        <div className="font-display text-lg font-semibold">Unggah File Excel</div>
        <p className="mx-auto mt-1 max-w-md text-sm text-muted-foreground">
          Format .xlsx. Pastikan menggunakan template agar nama kolom konsisten. Kolom <b>Nama Lengkap</b> wajib diisi.
        </p>
        <label className="mt-5 inline-flex cursor-pointer">
          <input type="file" accept=".xlsx,.xls" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }} />
          <Button asChild disabled={busy}><span>{busy ? "Memproses…" : "Pilih File Excel"}</span></Button>
        </label>
      </Card>

      {result && (
        <Card className="mt-4 rounded-2xl border border-border p-5 shadow-soft">
          <h3 className="mb-4 font-display text-base font-semibold">Hasil Impor</h3>
          <div className="grid grid-cols-3 gap-3">
            <div className="rounded-xl border border-border bg-success/5 p-4">
              <div className="flex items-center gap-2 text-success"><CheckCircle2 className="h-4 w-4" /> <span className="text-xs font-medium uppercase tracking-wide">Berhasil</span></div>
              <div className="stat-number mt-2 text-2xl font-semibold">{result.imported}</div>
            </div>
            <div className="rounded-xl border border-border bg-warning/10 p-4">
              <div className="flex items-center gap-2 text-warning-foreground"><Copy className="h-4 w-4" /> <span className="text-xs font-medium uppercase tracking-wide">Duplikat</span></div>
              <div className="stat-number mt-2 text-2xl font-semibold">{result.duplicate}</div>
            </div>
            <div className="rounded-xl border border-border bg-destructive/5 p-4">
              <div className="flex items-center gap-2 text-destructive"><AlertTriangle className="h-4 w-4" /> <span className="text-xs font-medium uppercase tracking-wide">Gagal</span></div>
              <div className="stat-number mt-2 text-2xl font-semibold">{result.failed}</div>
            </div>
          </div>
          {result.errors.length > 0 && (
            <div className="mt-4">
              <div className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">Detail Kesalahan</div>
              <div className="max-h-64 overflow-y-auto rounded-xl border border-border">
                <table className="w-full text-sm">
                  <thead className="bg-muted/50"><tr><th className="px-3 py-2 text-left">Baris</th><th className="px-3 py-2 text-left">Nama</th><th className="px-3 py-2 text-left">Alasan</th></tr></thead>
                  <tbody>{result.errors.map((e, i) => (
                    <tr key={i} className="border-t border-border"><td className="px-3 py-2 tabular-nums">{e.row}</td><td className="px-3 py-2">{e.name ?? "—"}</td><td className="px-3 py-2 text-muted-foreground">{e.reason}</td></tr>
                  ))}</tbody>
                </table>
              </div>
            </div>
          )}
        </Card>
      )}
    </div>
  );
}
