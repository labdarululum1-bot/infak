import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Plus, Pencil, Trash2, GraduationCap, Sparkles, ArrowUpRight } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { fetchClasses, fetchAcademicYears, graduateClass, promoteClass } from "@/lib/db";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export const Route = createFileRoute("/kelas")({
  head: () => ({ meta: [{ title: "Kelas — Buku Induk Siswa" }] }),
  component: ClassesPage,
});

function ClassesPage() {
  const qc = useQueryClient();
  const { data: classes = [] } = useQuery({ queryKey: ["classes"], queryFn: fetchClasses });
  const { data: years = [] } = useQuery({ queryKey: ["academic-years"], queryFn: fetchAcademicYears });
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState({ name: "", grade_level: "", homeroom_teacher: "", academic_year_id: "" });

  // Graduate dialog state
  const [gradOpen, setGradOpen] = useState(false);
  const [gradClassId, setGradClassId] = useState("");
  const [gradYearId, setGradYearId] = useState("");
  const [gradDate, setGradDate] = useState(new Date().toISOString().slice(0, 10));

  // Promote dialog state
  const [promOpen, setPromOpen] = useState(false);
  const [promFrom, setPromFrom] = useState("");
  const [promTo, setPromTo] = useState("");
  const [promYearId, setPromYearId] = useState("");

  // Count of active students per class
  const { data: counts = {} } = useQuery({
    queryKey: ["class-active-counts"],
    queryFn: async () => {
      const { data } = await supabase.from("students").select("current_class_id").eq("status", "Aktif");
      const map: Record<string, number> = {};
      (data ?? []).forEach((s) => { if (s.current_class_id) map[s.current_class_id] = (map[s.current_class_id] ?? 0) + 1; });
      return map;
    },
  });

  function startEdit(c: any) {
    setEditing(c);
    setForm({ name: c.name, grade_level: c.grade_level ?? "", homeroom_teacher: c.homeroom_teacher ?? "", academic_year_id: c.academic_year_id ?? "" });
    setOpen(true);
  }

  async function save() {
    if (!form.name.trim()) return toast.error("Nama kelas wajib");
    const payload = { ...form, academic_year_id: form.academic_year_id || null };
    if (editing) {
      const { error } = await supabase.from("classes").update(payload).eq("id", editing.id);
      if (error) return toast.error(error.message);
    } else {
      const { error } = await supabase.from("classes").insert(payload);
      if (error) return toast.error(error.message);
    }
    toast.success("Kelas tersimpan");
    setOpen(false); setEditing(null); setForm({ name: "", grade_level: "", homeroom_teacher: "", academic_year_id: "" });
    qc.invalidateQueries({ queryKey: ["classes"] });
  }

  async function del(id: string) {
    const { error } = await supabase.from("classes").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Kelas dihapus"); qc.invalidateQueries({ queryKey: ["classes"] });
  }

  async function doGraduate() {
    if (!gradClassId || !gradYearId) return toast.error("Pilih kelas dan tahun ajaran kelulusan");
    try {
      const n = await graduateClass({ classId: gradClassId, graduationDate: gradDate });
      toast.success(`${n} siswa berhasil diluluskan dan dipindahkan ke menu Alumni`);
      setGradOpen(false); setGradClassId(""); setGradYearId("");
      qc.invalidateQueries({ queryKey: ["students"] });
      qc.invalidateQueries({ queryKey: ["dashboard-stats"] });
      qc.invalidateQueries({ queryKey: ["class-active-counts"] });
    } catch (e: any) {
      toast.error("Gagal meluluskan: " + e.message);
    }
  }

  async function doPromote() {
    if (!promFrom || !promTo || !promYearId) return toast.error("Lengkapi pilihan");
    if (promFrom === promTo) return toast.error("Kelas tujuan harus berbeda");
    try {
      const n = await promoteClass({ fromClassId: promFrom, toClassId: promTo, academicYearId: promYearId });
      toast.success(`${n} siswa dinaikkan ke kelas baru`);
      setPromOpen(false); setPromFrom(""); setPromTo(""); setPromYearId("");
      qc.invalidateQueries({ queryKey: ["students"] });
      qc.invalidateQueries({ queryKey: ["class-active-counts"] });
    } catch (e: any) { toast.error("Gagal: " + e.message); }
  }

  return (
    <div>
      <PageHeader
        title="Kelas"
        description="Atur kelas, wali kelas, tahun ajaran, dan luluskan satu kelas sekaligus."
        actions={
          <>
            <Dialog open={promOpen} onOpenChange={setPromOpen}>
              <DialogTrigger asChild>
                <Button variant="outline"><ArrowUpRight className="mr-2 h-4 w-4" />Naikkan Kelas</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Naikkan Seluruh Siswa</DialogTitle>
                  <DialogDescription>
                    Semua siswa aktif di <b>Kelas Asal</b> akan dipindah ke <b>Kelas Tujuan</b>. Riwayat kelas sebelumnya tetap tersimpan.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-3">
                  <div>
                    <Label className="text-xs">Tahun Ajaran Baru</Label>
                    <Select value={promYearId} onValueChange={setPromYearId}>
                      <SelectTrigger><SelectValue placeholder="Pilih tahun ajaran" /></SelectTrigger>
                      <SelectContent>{years.map((y) => <SelectItem key={y.id} value={y.id}>{y.name}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs">Kelas Asal</Label>
                    <Select value={promFrom} onValueChange={setPromFrom}>
                      <SelectTrigger><SelectValue placeholder="Pilih kelas asal" /></SelectTrigger>
                      <SelectContent>
                        {classes.map((c: any) => <SelectItem key={c.id} value={c.id}>{c.name} ({counts[c.id] ?? 0} siswa)</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs">Kelas Tujuan</Label>
                    <Select value={promTo} onValueChange={setPromTo}>
                      <SelectTrigger><SelectValue placeholder="Pilih kelas tujuan" /></SelectTrigger>
                      <SelectContent>
                        {classes.filter((c: any) => c.id !== promFrom).map((c: any) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button disabled={!promFrom || !promTo || !promYearId}><ArrowUpRight className="mr-2 h-4 w-4" />Naikkan Siswa</Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Konfirmasi Kenaikan Kelas</AlertDialogTitle>
                        <AlertDialogDescription>
                          {counts[promFrom] ?? 0} siswa akan dinaikkan. Riwayat kelas sebelumnya akan ditutup dan dicatat. Lanjutkan?
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Batal</AlertDialogCancel>
                        <AlertDialogAction onClick={doPromote}>Ya, Naikkan</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </DialogFooter>
              </DialogContent>
            </Dialog>
            <Dialog open={gradOpen} onOpenChange={setGradOpen}>
              <DialogTrigger asChild>
                <Button variant="outline"><Sparkles className="mr-2 h-4 w-4" /> Luluskan Kelas</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Luluskan Seluruh Kelas</DialogTitle>
                  <DialogDescription>
                    Semua siswa aktif di kelas terpilih akan diubah statusnya menjadi <b>Lulus</b> dan otomatis pindah ke menu Alumni. Seluruh data siswa, dokumen, dan riwayat tetap tersimpan.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-3">
                  <div>
                    <Label className="text-xs">Tahun Ajaran Kelulusan</Label>
                    <Select value={gradYearId} onValueChange={setGradYearId}>
                      <SelectTrigger><SelectValue placeholder="Pilih tahun ajaran" /></SelectTrigger>
                      <SelectContent>{years.map((y) => <SelectItem key={y.id} value={y.id}>{y.name}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs">Kelas</Label>
                    <Select value={gradClassId} onValueChange={setGradClassId}>
                      <SelectTrigger><SelectValue placeholder="Pilih kelas" /></SelectTrigger>
                      <SelectContent>
                        {classes.map((c: any) => (
                          <SelectItem key={c.id} value={c.id}>{c.name} ({counts[c.id] ?? 0} siswa aktif)</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs">Tanggal Kelulusan</Label>
                    <Input type="date" value={gradDate} onChange={(e) => setGradDate(e.target.value)} />
                  </div>
                </div>
                <DialogFooter>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button disabled={!gradClassId || !gradYearId}><Sparkles className="mr-2 h-4 w-4" />Luluskan Semua Siswa</Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Konfirmasi Kelulusan</AlertDialogTitle>
                        <AlertDialogDescription>
                          {counts[gradClassId] ?? 0} siswa aktif akan diluluskan. Tindakan ini akan langsung memindahkan mereka ke menu Alumni. Lanjutkan?
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Batal</AlertDialogCancel>
                        <AlertDialogAction onClick={doGraduate}>Ya, Luluskan</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </DialogFooter>
              </DialogContent>
            </Dialog>
            <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) setEditing(null); }}>
              <DialogTrigger asChild><Button onClick={() => setForm({ name: "", grade_level: "", homeroom_teacher: "", academic_year_id: "" })}><Plus className="mr-2 h-4 w-4" /> Tambah Kelas</Button></DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>{editing ? "Ubah Kelas" : "Tambah Kelas"}</DialogTitle></DialogHeader>
                <div className="space-y-3">
                  <div><Label className="text-xs">Nama Kelas</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="VII-A" /></div>
                  <div><Label className="text-xs">Tingkat</Label><Input value={form.grade_level} onChange={(e) => setForm({ ...form, grade_level: e.target.value })} placeholder="VII / VIII / IX" /></div>
                  <div><Label className="text-xs">Wali Kelas</Label><Input value={form.homeroom_teacher} onChange={(e) => setForm({ ...form, homeroom_teacher: e.target.value })} /></div>
                  <div>
                    <Label className="text-xs">Tahun Ajaran</Label>
                    <Select value={form.academic_year_id} onValueChange={(v) => setForm({ ...form, academic_year_id: v })}>
                      <SelectTrigger><SelectValue placeholder="Pilih" /></SelectTrigger>
                      <SelectContent>{years.map(y => <SelectItem key={y.id} value={y.id}>{y.name}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter><Button onClick={save}>Simpan</Button></DialogFooter>
              </DialogContent>
            </Dialog>
          </>
        }
      />
      <Card className="overflow-hidden rounded-2xl border border-border shadow-soft">
        {classes.length === 0 ? (
          <div className="p-6"><EmptyState icon={<GraduationCap className="h-6 w-6" />} title="Belum ada kelas" description="Tambahkan kelas baru untuk mulai mengelompokkan siswa." /></div>
        ) : (
          <Table>
            <TableHeader><TableRow className="bg-muted/40"><TableHead>Nama Kelas</TableHead><TableHead>Tingkat</TableHead><TableHead>Wali Kelas</TableHead><TableHead>Tahun Ajaran</TableHead><TableHead>Siswa Aktif</TableHead><TableHead className="text-right">Aksi</TableHead></TableRow></TableHeader>
            <TableBody>
              {classes.map((c: any) => (
                <TableRow key={c.id}>
                  <TableCell className="font-medium">{c.name}</TableCell>
                  <TableCell>{c.grade_level ?? "—"}</TableCell>
                  <TableCell>{c.homeroom_teacher ?? "—"}</TableCell>
                  <TableCell>{c.academic_year?.name ?? "—"}</TableCell>
                  <TableCell className="tabular-nums">{counts[c.id] ?? 0}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => startEdit(c)}><Pencil className="h-4 w-4" /></Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="icon" className="text-destructive"><Trash2 className="h-4 w-4" /></Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Hapus kelas?</AlertDialogTitle>
                          <AlertDialogDescription>Siswa di kelas ini akan kehilangan referensi kelas (tetap tersimpan). Lanjutkan?</AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Batal</AlertDialogCancel>
                          <AlertDialogAction onClick={() => del(c.id)} className="bg-destructive text-destructive-foreground">Ya, hapus</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Card>
    </div>
  );
}
