import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { Plus, Pencil, Trash2, GraduationCap as TeacherIcon, Download, FileText, Search, Upload, Eye, X, User } from "lucide-react";

import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { exportToExcel, exportToPDF } from "@/lib/export";
import { uploadStudentFile, signedUrl } from "@/lib/db";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { EDUCATION_OPTIONS, RELIGION_OPTIONS } from "@/lib/constants";

export const Route = createFileRoute("/guru")({
  head: () => ({ meta: [{ title: "Guru — Buku Induk" }] }),
  component: TeachersPage,
});

const POSITION_OPTIONS = ["Guru", "Kepala Sekolah", "Wakil Kepala Sekolah", "Operator", "Staf"];

const EMPTY = {
  nip: "", nuptk: "", nik: "", full_name: "", gender: "", place_of_birth: "", date_of_birth: "",
  religion: "", phone: "", email: "", address: "", position: "", employment_status: "",
  education: "", university: "", major: "",
};

function TeachersPage() {
  const qc = useQueryClient();
  const { data: teachers = [] } = useQuery({
    queryKey: ["teachers"],
    queryFn: async () => (await supabase.from("teachers").select("*").order("full_name")).data ?? [],
  });
  const { data: subjects = [] } = useQuery({
    queryKey: ["subjects"],
    queryFn: async () => (await supabase.from("subjects").select("*").eq("is_active", true).order("name")).data ?? [],
  });
  const { data: teacherSubjects = [] } = useQuery({
    queryKey: ["teacher-subjects"],
    queryFn: async () => (await supabase.from("teacher_subjects").select("*")).data ?? [],
  });

  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({ ...EMPTY });
  const [subjectIds, setSubjectIds] = useState<string[]>([]);
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const perPage = 15;

  const filtered = useMemo(() => {
    const ql = q.toLowerCase();
    return (teachers as any[]).filter((t) =>
      !ql || `${t.full_name} ${t.nip ?? ""} ${t.nuptk ?? ""} ${t.nik ?? ""} ${t.email ?? ""} ${t.phone ?? ""}`.toLowerCase().includes(ql)
    );
  }, [teachers, q]);
  const paginated = filtered.slice((page - 1) * perPage, page * perPage);
  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));

  const subjectsByTeacher = useMemo(() => {
    const m = new Map<string, string[]>();
    (teacherSubjects as any[]).forEach((ts) => {
      const arr = m.get(ts.teacher_id) ?? [];
      arr.push(ts.subject_id); m.set(ts.teacher_id, arr);
    });
    return m;
  }, [teacherSubjects]);

  function startNew() { setEditing(null); setForm({ ...EMPTY }); setSubjectIds([]); setOpen(true); }
  function startEdit(t: any) {
    setEditing(t);
    setForm(Object.fromEntries(Object.entries(EMPTY).map(([k]) => [k, t[k] ?? ""])));
    setSubjectIds(subjectsByTeacher.get(t.id) ?? []);
    setOpen(true);
  }
  async function save() {
    if (!form.full_name.trim()) return toast.error("Nama wajib diisi");
    const payload: any = { ...form, date_of_birth: form.date_of_birth || null };
    Object.keys(payload).forEach((k) => { if (payload[k] === "") payload[k] = null; });
    let teacherId = editing?.id as string | undefined;
    if (editing) {
      const { error } = await supabase.from("teachers").update(payload).eq("id", editing.id);
      if (error) return toast.error(error.message);
    } else {
      const { data: ins, error } = await supabase.from("teachers").insert(payload).select("id").single();
      if (error) return toast.error(error.message);
      teacherId = ins.id;
    }
    // Sync teacher_subjects
    if (teacherId) {
      await supabase.from("teacher_subjects").delete().eq("teacher_id", teacherId);
      if (subjectIds.length) {
        await supabase.from("teacher_subjects").insert(subjectIds.map((subject_id) => ({ teacher_id: teacherId!, subject_id })));
      }
    }
    toast.success("Data guru tersimpan");
    setOpen(false);
    qc.invalidateQueries({ queryKey: ["teachers"] });
    qc.invalidateQueries({ queryKey: ["teacher-subjects"] });
  }
  async function del(id: string) {
    const { error } = await supabase.from("teachers").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Guru dihapus"); qc.invalidateQueries({ queryKey: ["teachers"] });
  }

  function subjectNames(id: string) {
    return (subjectsByTeacher.get(id) ?? []).map((sid) => (subjects as any[]).find((s) => s.id === sid)?.name).filter(Boolean);
  }

  function exportRows() {
    return filtered.map((t: any) => ({
      NIP: t.nip ?? "", NUPTK: t.nuptk ?? "", NIK: t.nik ?? "", "Nama": t.full_name,
      "Gender": t.gender ?? "", Jabatan: t.position ?? "",
      "Status Kepegawaian": t.employment_status ?? "",
      "Pendidikan": t.education ?? "", "Universitas": t.university ?? "", "Jurusan": t.major ?? "",
      "Mapel": subjectNames(t.id).join(", "),
      "No. HP": t.phone ?? "", Email: t.email ?? "",
    }));
  }

  return (
    <div>
      <PageHeader
        title="Guru"
        description="Daftar guru / tenaga pendidik."
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => exportToExcel(exportRows(), "daftar-guru")}><Download className="mr-2 h-4 w-4" />Excel</Button>
            <Button variant="outline" size="sm" onClick={() => exportToPDF({
              title: "Daftar Guru", columns: ["NIP", "Nama", "Jabatan", "Mapel", "HP"],
              rows: filtered.map((t: any) => [t.nip ?? "-", t.full_name, t.position ?? "-", subjectNames(t.id).join(", ") || "-", t.phone ?? "-"]),
              filename: "daftar-guru",
            })}><FileText className="mr-2 h-4 w-4" />PDF</Button>
            <Button onClick={startNew}><Plus className="mr-2 h-4 w-4" />Tambah Guru</Button>
          </>
        }
      />

      <Card className="mb-4 rounded-2xl border border-border p-4 shadow-soft">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input className="pl-9" placeholder="Cari nama, NIP, NUPTK, NIK, email…" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} />
        </div>
      </Card>

      <Card className="overflow-hidden rounded-2xl border border-border shadow-soft">
        {filtered.length === 0 ? (
          <div className="p-6"><EmptyState icon={<TeacherIcon className="h-6 w-6" />} title="Belum ada guru" description="Tambahkan data guru / tenaga pendidik." action={<Button onClick={startNew}><Plus className="mr-2 h-4 w-4" />Tambah Guru</Button>} /></div>
        ) : (
          <>
            <Table>
              <TableHeader><TableRow className="bg-muted/40"><TableHead>Nama</TableHead><TableHead>NIP / NUPTK</TableHead><TableHead>Jabatan</TableHead><TableHead>Mapel</TableHead><TableHead>Kontak</TableHead><TableHead className="text-right">Aksi</TableHead></TableRow></TableHeader>
              <TableBody>
                {paginated.map((t: any) => (
                  <TableRow key={t.id}>
                    <TableCell className="font-medium">{t.full_name}</TableCell>
                    <TableCell><div className="tabular-nums">{t.nip ?? "—"}</div><div className="text-xs text-muted-foreground tabular-nums">{t.nuptk ?? "—"}</div></TableCell>
                    <TableCell>{t.position ?? "—"}</TableCell>
                    <TableCell className="max-w-[220px]">
                      <div className="flex flex-wrap gap-1">
                        {subjectNames(t.id).slice(0, 3).map((n, i) => <Badge key={i} variant="outline" className="font-normal">{n}</Badge>)}
                        {subjectNames(t.id).length > 3 && <Badge variant="outline">+{subjectNames(t.id).length - 3}</Badge>}
                        {subjectNames(t.id).length === 0 && <span className="text-xs text-muted-foreground">—</span>}
                      </div>
                    </TableCell>
                    <TableCell><div>{t.phone ?? "—"}</div><div className="text-xs text-muted-foreground">{t.email ?? "—"}</div></TableCell>
                    <TableCell className="text-right">
                      <Button asChild variant="ghost" size="icon" title="Profil">
                        <Link to="/guru/$id/profil" params={{ id: t.id }}><User className="h-4 w-4" /></Link>
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => startEdit(t)} title="Ubah"><Pencil className="h-4 w-4" /></Button>

                      <AlertDialog>
                        <AlertDialogTrigger asChild><Button variant="ghost" size="icon" className="text-destructive"><Trash2 className="h-4 w-4" /></Button></AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Hapus guru?</AlertDialogTitle>
                            <AlertDialogDescription>Data <b>{t.full_name}</b> akan dihapus permanen.</AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Batal</AlertDialogCancel>
                            <AlertDialogAction onClick={() => del(t.id)} className="bg-destructive text-destructive-foreground">Ya, hapus</AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border px-4 py-3 text-sm text-muted-foreground">
              <div>Total: <span className="font-medium text-foreground">{filtered.length}</span></div>
              <div className="flex items-center gap-2">
                <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>Sebelumnya</Button>
                <span>Halaman {page} / {totalPages}</span>
                <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>Berikutnya</Button>
              </div>
            </div>
          </>
        )}
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader><DialogTitle>{editing ? "Ubah Guru" : "Tambah Guru"}</DialogTitle></DialogHeader>
          <div className="grid gap-3 md:grid-cols-2 max-h-[65vh] overflow-y-auto pr-1">
            <div className="md:col-span-2"><Label className="text-xs">Nama Lengkap *</Label><Input value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} /></div>
            <div><Label className="text-xs">NIK</Label><Input value={form.nik} onChange={(e) => setForm({ ...form, nik: e.target.value })} /></div>
            <div><Label className="text-xs">NIP</Label><Input value={form.nip} onChange={(e) => setForm({ ...form, nip: e.target.value })} /></div>
            <div><Label className="text-xs">NUPTK</Label><Input value={form.nuptk} onChange={(e) => setForm({ ...form, nuptk: e.target.value })} /></div>
            <div>
              <Label className="text-xs">Gender</Label>
              <Select value={form.gender} onValueChange={(v) => setForm({ ...form, gender: v })}>
                <SelectTrigger><SelectValue placeholder="Pilih" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Laki-laki">Laki-laki</SelectItem>
                  <SelectItem value="Perempuan">Perempuan</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Agama</Label>
              <Select value={form.religion} onValueChange={(v) => setForm({ ...form, religion: v })}>
                <SelectTrigger><SelectValue placeholder="Pilih" /></SelectTrigger>
                <SelectContent>{RELIGION_OPTIONS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label className="text-xs">Tempat Lahir</Label><Input value={form.place_of_birth} onChange={(e) => setForm({ ...form, place_of_birth: e.target.value })} /></div>
            <div><Label className="text-xs">Tanggal Lahir</Label><Input type="date" value={form.date_of_birth} onChange={(e) => setForm({ ...form, date_of_birth: e.target.value })} /></div>
            <div><Label className="text-xs">No. HP</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            <div><Label className="text-xs">Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            <div className="md:col-span-2"><Label className="text-xs">Alamat</Label><Textarea rows={2} value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
            <div>
              <Label className="text-xs">Jabatan</Label>
              <Select value={form.position} onValueChange={(v) => setForm({ ...form, position: v })}>
                <SelectTrigger><SelectValue placeholder="Pilih" /></SelectTrigger>
                <SelectContent>{POSITION_OPTIONS.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Status Kepegawaian</Label>
              <Select value={form.employment_status} onValueChange={(v) => setForm({ ...form, employment_status: v })}>
                <SelectTrigger><SelectValue placeholder="Pilih" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="PNS">PNS</SelectItem>
                  <SelectItem value="PPPK">PPPK</SelectItem>
                  <SelectItem value="GTY">GTY</SelectItem>
                  <SelectItem value="GTT">GTT</SelectItem>
                  <SelectItem value="Honorer">Honorer</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Pendidikan Terakhir</Label>
              <Select value={form.education} onValueChange={(v) => setForm({ ...form, education: v })}>
                <SelectTrigger><SelectValue placeholder="Pilih" /></SelectTrigger>
                <SelectContent>{EDUCATION_OPTIONS.map((e) => <SelectItem key={e} value={e}>{e}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label className="text-xs">Universitas</Label><Input value={form.university} onChange={(e) => setForm({ ...form, university: e.target.value })} /></div>
            <div className="md:col-span-2"><Label className="text-xs">Jurusan</Label><Input value={form.major} onChange={(e) => setForm({ ...form, major: e.target.value })} /></div>
            <div className="md:col-span-2">
              <Label className="text-xs">Mata Pelajaran Diampu</Label>
              {subjects.length === 0 ? (
                <p className="mt-2 text-xs text-muted-foreground">Belum ada mata pelajaran. Tambahkan di Master Data → Mata Pelajaran.</p>
              ) : (
                <div className="mt-1 grid grid-cols-2 gap-2 rounded-xl border border-border p-3 md:grid-cols-3 max-h-48 overflow-y-auto">
                  {(subjects as any[]).map((s) => {
                    const checked = subjectIds.includes(s.id);
                    return (
                      <label key={s.id} className={`flex cursor-pointer items-center gap-2 rounded-lg border p-2 text-sm ${checked ? "border-primary bg-primary-soft" : "border-border"}`}>
                        <Checkbox checked={checked} onCheckedChange={(v) => setSubjectIds((a) => v ? [...a, s.id] : a.filter((x) => x !== s.id))} />
                        <span>{s.name}</span>
                      </label>
                    );
                  })}
                </div>
              )}
            </div>
            {editing && <TeacherDocsSection teacherId={editing.id} />}
            {!editing && <p className="md:col-span-2 rounded-xl bg-warning/10 p-3 text-sm text-warning-foreground">Simpan data guru terlebih dahulu untuk mengunggah dokumen.</p>}
          </div>
          <DialogFooter><Button onClick={save}>Simpan</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

const TEACHER_DOC_TYPES = ["KTP", "Kartu Keluarga", "Ijazah", "Sertifikat Pendidik", "SK Pengangkatan", "Kontrak Kerja", "Lainnya"];

function TeacherDocsSection({ teacherId }: { teacherId: string }) {
  const qc = useQueryClient();
  const { data: docs = [] } = useQuery({
    queryKey: ["teacher-docs", teacherId],
    queryFn: async () => (await supabase.from("teacher_documents").select("*").eq("teacher_id", teacherId).order("created_at", { ascending: false })).data ?? [],
  });
  const [docType, setDocType] = useState(TEACHER_DOC_TYPES[0]);
  const [uploading, setUploading] = useState(false);

  async function upload(file: File) {
    setUploading(true);
    try {
      const path = await uploadStudentFile(`teachers/${teacherId}`, file, "doc");
      const { error } = await supabase.from("teacher_documents").insert({
        teacher_id: teacherId, doc_type: docType, file_url: path, file_name: file.name,
      });
      if (error) throw error;
      toast.success("Dokumen diunggah");
      qc.invalidateQueries({ queryKey: ["teacher-docs", teacherId] });
    } catch (e: any) {
      toast.error(e.message ?? "Gagal mengunggah");
    } finally { setUploading(false); }
  }

  async function del(id: string) {
    if (!confirm("Hapus dokumen ini?")) return;
    const { error } = await supabase.from("teacher_documents").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Dokumen dihapus");
    qc.invalidateQueries({ queryKey: ["teacher-docs", teacherId] });
  }

  return (
    <div className="md:col-span-2 rounded-xl border border-border p-4">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <div className="font-display text-sm font-semibold">Dokumen Guru</div>
          <div className="text-xs text-muted-foreground">Unggah KTP, KK, Ijazah, SK, dan dokumen lainnya.</div>
        </div>
      </div>
      <div className="mb-4 flex flex-wrap items-end gap-2">
        <div className="flex-1 min-w-[180px]">
          <Label className="text-xs">Jenis Dokumen</Label>
          <Select value={docType} onValueChange={setDocType}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{TEACHER_DOC_TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <label className={`inline-flex cursor-pointer items-center gap-2 rounded-md border border-input bg-primary px-3 py-2 text-sm font-medium text-primary-foreground ${uploading ? "opacity-60" : ""}`}>
          <Upload className="h-4 w-4" />{uploading ? "Mengunggah…" : "Unggah"}
          <input type="file" accept="image/*,application/pdf" className="hidden" disabled={uploading} onChange={(e) => { const f = e.target.files?.[0]; if (f) upload(f); (e.target as HTMLInputElement).value = ""; }} />
        </label>
      </div>
      {docs.length === 0 ? (
        <p className="text-xs text-muted-foreground">Belum ada dokumen.</p>
      ) : (
        <div className="space-y-2">
          {(docs as any[]).map((d) => <TeacherDocRow key={d.id} doc={d} onDelete={() => del(d.id)} />)}
        </div>
      )}
    </div>
  );
}

function TeacherDocRow({ doc, onDelete }: { doc: any; onDelete: () => void }) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => { if (doc.file_url) signedUrl(doc.file_url).then(setUrl).catch(() => setUrl(null)); }, [doc.file_url]);
  const isPreviewable = /\.(png|jpe?g|gif|webp|avif|pdf)$/i.test(doc.file_name ?? doc.file_url ?? "");
  return (
    <div className="flex flex-wrap items-center gap-3 rounded-lg border border-border p-3">
      <FileText className="h-4 w-4 shrink-0 text-primary" />
      <div className="min-w-0 flex-1">
        <div className="truncate text-sm font-medium">{doc.doc_type}</div>
        <div className="truncate text-xs text-muted-foreground">{doc.file_name} · {new Date(doc.created_at).toLocaleDateString("id-ID")}</div>
      </div>
      <div className="flex gap-1">
        {url && isPreviewable && (
          <Button asChild variant="ghost" size="icon" title="Preview"><a href={url} target="_blank" rel="noreferrer"><Eye className="h-4 w-4" /></a></Button>
        )}
        {url && (
          <Button asChild variant="ghost" size="icon" title="Unduh"><a href={url} download={doc.file_name ?? "dokumen"}><Download className="h-4 w-4" /></a></Button>
        )}
        <Button variant="ghost" size="icon" className="text-destructive" title="Hapus" onClick={onDelete}><X className="h-4 w-4" /></Button>
      </div>
    </div>
  );
}
