import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { Save, FileText, Upload, X, ChevronLeft, ChevronRight, BookOpen, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { fetchClasses, fetchActiveAcademicYear } from "@/lib/db";
import { upsertGrades, type GradeRow } from "@/lib/grades";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export const Route = createFileRoute("/nilai/")({
  head: () => ({ meta: [{ title: "Input Nilai — Buku Induk" }] }),
  component: NilaiEntry,
});

type Cell = { knowledge: string; skills: string; final: string };

function computeFinal(k: string, s: string) {
  const kn = parseFloat(k), sk = parseFloat(s);
  if (isNaN(kn) && isNaN(sk)) return "";
  if (isNaN(kn)) return sk.toFixed(2);
  if (isNaN(sk)) return kn.toFixed(2);
  return ((kn + sk) / 2).toFixed(2);
}

function NilaiEntry() {
  const qc = useQueryClient();
  const { data: activeYear } = useQuery({ queryKey: ["active-academic-year"], queryFn: fetchActiveAcademicYear });
  const { data: classes = [] } = useQuery({ queryKey: ["classes"], queryFn: fetchClasses });
  const { data: subjects = [] } = useQuery({
    queryKey: ["subjects", "active"],
    queryFn: async () => (await supabase.from("subjects").select("*").eq("is_active", true).order("name")).data ?? [],
  });

  const [semester, setSemester] = useState<string>("1");
  const [classId, setClassId] = useState<string>("");
  const [subjectId, setSubjectId] = useState<string>("");

  const yearId = (activeYear as any)?.id ?? "";
  const yearName = (activeYear as any)?.name ?? "—";
  const classInfo = useMemo(() => (classes as any[]).find((c) => c.id === classId), [classes, classId]);
  const subjectIndex = useMemo(() => (subjects as any[]).findIndex((s) => s.id === subjectId), [subjects, subjectId]);
  const subjectName = useMemo(() => (subjects as any[])[subjectIndex]?.name, [subjects, subjectIndex]);

  const canLoadStudents = !!classId && !!semester;
  const canLoadGrades = canLoadStudents && !!subjectId && !!yearId;

  const { data: studentsData } = useQuery({
    queryKey: ["class-students", classId],
    queryFn: async () => classId
      ? (await supabase.from("students")
          .select("id,nis,nisn,full_name,attendance_number")
          .eq("current_class_id", classId).eq("status", "Aktif")
          .order("attendance_number", { nullsFirst: false }).order("full_name")).data ?? []
      : [],
    enabled: !!classId,
  });
  const students = useMemo(() => studentsData ?? [], [studentsData]);

  const { data: gradeCountsData } = useQuery({
    queryKey: ["subject-grade-counts", classId, yearId, semester],
    queryFn: async () => canLoadStudents && yearId
      ? (await supabase.from("grades").select("subject_id")
          .eq("class_id", classId).eq("academic_year_id", yearId)
          .eq("semester", Number(semester))).data ?? []
      : [],
    enabled: canLoadStudents && !!yearId,
  });
  const subjectCounts = useMemo(() => {
    const map = new Map<string, number>();
    (gradeCountsData ?? []).forEach((g: any) => map.set(g.subject_id, (map.get(g.subject_id) ?? 0) + 1));
    return map;
  }, [gradeCountsData]);

  const { data: existingGradesData } = useQuery({
    queryKey: ["grades-entry", classId, yearId, semester, subjectId],
    queryFn: async () => canLoadGrades
      ? (await supabase.from("grades").select("*")
          .eq("class_id", classId).eq("academic_year_id", yearId)
          .eq("semester", Number(semester)).eq("subject_id", subjectId)).data ?? []
      : [],
    enabled: canLoadGrades,
  });
  const existingGrades = useMemo(() => existingGradesData ?? [], [existingGradesData]);

  const [cells, setCells] = useState<Record<string, Cell>>({});

  useEffect(() => {
    const map: Record<string, Cell> = {};
    (students as any[]).forEach((s) => {
      const g = (existingGrades as any[]).find((x) => x.student_id === s.id);
      map[s.id] = {
        knowledge: g?.knowledge_score == null ? "" : String(g.knowledge_score),
        skills: g?.skills_score == null ? "" : String(g.skills_score),
        final: g?.final_score == null ? "" : String(g.final_score),
      };
    });
    setCells(map);
  }, [students, existingGrades]);

  function update(sid: string, field: keyof Cell, v: string) {
    setCells((c) => ({ ...c, [sid]: { ...c[sid], [field]: v } }));
  }

  async function save(next: boolean) {
    if (!canLoadGrades) return toast.error("Pilih kelas, semester, dan mata pelajaran");
    const rows: GradeRow[] = [];
    for (const s of students as any[]) {
      const c = cells[s.id]; if (!c) continue;
      const kn = c.knowledge === "" ? null : Number(c.knowledge);
      const sk = c.skills === "" ? null : Number(c.skills);
      let fn = c.final === "" ? null : Number(c.final);
      if (fn == null && (kn != null || sk != null)) {
        const auto = computeFinal(c.knowledge, c.skills);
        fn = auto === "" ? null : Number(auto);
      }
      if (kn == null && sk == null && fn == null) continue;
      rows.push({
        student_id: s.id, academic_year_id: yearId, class_id: classId,
        semester: Number(semester), subject_id: subjectId,
        knowledge_score: kn, skills_score: sk, final_score: fn,
      });
    }
    try {
      await upsertGrades(rows);
      toast.success(`Tersimpan (${rows.length} siswa)`);
      qc.invalidateQueries({ queryKey: ["grades-entry", classId, yearId, semester, subjectId] });
      qc.invalidateQueries({ queryKey: ["subject-grade-counts", classId, yearId, semester] });
      if (next) {
        const nxt = (subjects as any[])[subjectIndex + 1];
        if (nxt) { setSubjectId(nxt.id); toast.message(`Lanjut ke ${nxt.name}`); }
        else toast.message("Sudah mapel terakhir");
      }
    } catch (e: any) { toast.error(e.message ?? "Gagal menyimpan"); }
  }

  function cancel() {
    const map: Record<string, Cell> = {};
    (students as any[]).forEach((s) => {
      const g = (existingGrades as any[]).find((x) => x.student_id === s.id);
      map[s.id] = {
        knowledge: g?.knowledge_score == null ? "" : String(g.knowledge_score),
        skills: g?.skills_score == null ? "" : String(g.skills_score),
        final: g?.final_score == null ? "" : String(g.final_score),
      };
    });
    setCells(map);
    toast.message("Perubahan dibatalkan");
  }

  const prevSubject = subjectIndex > 0 ? (subjects as any[])[subjectIndex - 1] : null;
  const nextSubject = subjectIndex >= 0 ? (subjects as any[])[subjectIndex + 1] : null;

  return (
    <div>
      <PageHeader
        title="Input Nilai"
        description={`Tahun Ajaran Aktif: ${yearName} · Alur: Kelas → Semester → Mapel → Input`}
        actions={
          <>
            <Button asChild variant="outline" size="sm"><Link to="/nilai/impor"><Upload className="mr-2 h-4 w-4" />Import</Link></Button>
            <Button asChild variant="outline" size="sm"><Link to="/nilai/legger"><FileText className="mr-2 h-4 w-4" />Legger Kelas</Link></Button>
          </>
        }
      />

      <Card className="mb-4 rounded-2xl border border-border p-4 shadow-soft">
        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <Label className="text-xs">1. Kelas</Label>
            <Select value={classId} onValueChange={(v) => { setClassId(v); setSubjectId(""); }}>
              <SelectTrigger><SelectValue placeholder="Pilih kelas" /></SelectTrigger>
              <SelectContent>{(classes as any[]).map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">2. Semester</Label>
            <Select value={semester} onValueChange={(v) => { setSemester(v); setSubjectId(""); }}>
              <SelectTrigger><SelectValue placeholder="Pilih semester" /></SelectTrigger>
              <SelectContent>{[1, 2, 3, 4, 5, 6].map((s) => <SelectItem key={s} value={String(s)}>Semester {s}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      {!canLoadStudents ? (
        <Card className="rounded-2xl border border-border p-6 text-sm text-muted-foreground shadow-soft">
          Pilih <b>Kelas</b> dan <b>Semester</b> untuk menampilkan daftar mata pelajaran.
        </Card>
      ) : !yearId ? (
        <EmptyState title="Tahun Ajaran Aktif belum diset" description="Aktifkan tahun ajaran di Pengaturan Sekolah." action={<Button asChild size="sm"><Link to="/pengaturan">Buka Pengaturan</Link></Button>} />
      ) : (subjects as any[]).length === 0 ? (
        <EmptyState title="Belum ada mata pelajaran" description="Tambahkan mata pelajaran di Master Data." action={<Button asChild size="sm"><Link to="/master">Buka Master Data</Link></Button>} />
      ) : !subjectId ? (
        <Card className="rounded-2xl border border-border p-4 shadow-soft">
          <div className="mb-3 text-sm">
            <b>{classInfo?.name}</b> · Semester {semester} · Klik mata pelajaran untuk input nilai
          </div>
          <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
            {(subjects as any[]).map((s) => {
              const count = subjectCounts.get(s.id) ?? 0;
              return (
                <button key={s.id} onClick={() => setSubjectId(s.id)}
                  className="group flex flex-col items-start gap-2 rounded-xl border border-border bg-card p-4 text-left transition-colors hover:border-primary hover:bg-primary-soft/40">
                  <div className="flex w-full items-center justify-between">
                    <div className="grid h-9 w-9 place-items-center rounded-lg bg-primary-soft text-primary"><BookOpen className="h-4 w-4" /></div>
                    {count > 0
                      ? <Badge className="bg-success/15 text-success border-transparent">{count} nilai</Badge>
                      : <Badge variant="outline" className="text-muted-foreground">Kosong</Badge>}
                  </div>
                  <div className="font-medium leading-tight group-hover:text-primary">{s.name}</div>
                </button>
              );
            })}
          </div>
        </Card>
      ) : (
        <Card className="overflow-hidden rounded-2xl border border-border shadow-soft">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border bg-muted/30 px-4 py-3">
            <div className="flex items-center gap-2 text-sm">
              <Button variant="ghost" size="sm" onClick={() => setSubjectId("")}><ArrowLeft className="mr-1 h-4 w-4" />Daftar Mapel</Button>
              <span className="text-muted-foreground">·</span>
              <span><b>{classInfo?.name}</b> · Semester {semester} · <b>{subjectName}</b></span>
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" disabled={!prevSubject} onClick={() => prevSubject && setSubjectId(prevSubject.id)}>
                <ChevronLeft className="mr-1 h-4 w-4" />Sebelumnya
              </Button>
              <Button size="sm" variant="outline" disabled={!nextSubject} onClick={() => nextSubject && setSubjectId(nextSubject.id)}>
                Berikutnya<ChevronRight className="ml-1 h-4 w-4" />
              </Button>
            </div>
          </div>

          {(students as any[]).length === 0 ? (
            <div className="p-6 text-sm text-muted-foreground">Belum ada siswa aktif pada kelas ini.</div>
          ) : (
            <>
              <Table>
                <TableHeader><TableRow className="bg-muted/40">
                  <TableHead className="w-12">No</TableHead>
                  <TableHead className="w-20">No. Absen</TableHead>
                  <TableHead className="w-32">NIS</TableHead>
                  <TableHead>Nama Siswa</TableHead>
                  <TableHead className="w-32">Pengetahuan</TableHead>
                  <TableHead className="w-32">Keterampilan</TableHead>
                  <TableHead className="w-32">Nilai Akhir</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {(students as any[]).map((s, i) => {
                    const c = cells[s.id] ?? { knowledge: "", skills: "", final: "" };
                    const auto = c.final || computeFinal(c.knowledge, c.skills);
                    return (
                      <TableRow key={s.id}>
                        <TableCell className="tabular-nums">{i + 1}</TableCell>
                        <TableCell className="tabular-nums">{s.attendance_number ?? "—"}</TableCell>
                        <TableCell className="tabular-nums">{s.nis ?? "—"}</TableCell>
                        <TableCell className="font-medium">{s.full_name}</TableCell>
                        <TableCell><Input type="number" step="0.01" min="0" max="100" value={c.knowledge} onChange={(e) => update(s.id, "knowledge", e.target.value)} /></TableCell>
                        <TableCell><Input type="number" step="0.01" min="0" max="100" value={c.skills} onChange={(e) => update(s.id, "skills", e.target.value)} /></TableCell>
                        <TableCell><Input type="number" step="0.01" min="0" max="100" value={c.final} placeholder={auto || "auto"} onChange={(e) => update(s.id, "final", e.target.value)} /></TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
              <div className="flex flex-wrap items-center justify-end gap-2 border-t border-border px-4 py-3">
                <Button size="sm" variant="ghost" onClick={cancel}><X className="mr-1 h-4 w-4" />Batal</Button>
                <Button size="sm" variant="outline" onClick={() => save(true)} disabled={!nextSubject}><Save className="mr-1 h-4 w-4" />Simpan & Mapel Berikutnya</Button>
                <Button size="sm" onClick={() => save(false)}><Save className="mr-1 h-4 w-4" />Simpan</Button>
              </div>
            </>
          )}
        </Card>
      )}
    </div>
  );
}
