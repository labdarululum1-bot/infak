import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Users, UserCheck, BookOpen, Home, GraduationCap, TrendingUp, ArrowUpRight, Activity } from "lucide-react";
import {
  PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/PageHeader";
import { Card } from "@/components/ui/card";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard — Buku Induk Siswa" },
      { name: "description", content: "Ringkasan dan statistik data siswa sekolah." },
    ],
  }),
  component: Dashboard,
});

type Stats = {
  active: number; male: number; female: number;
  boarding: number; nonBoarding: number; alumni: number;
  byClass: { name: string; total: number }[];
  byYear: { name: string; total: number }[];
  recent: { id: string; full_name: string; nis: string | null; status: string | null; class_name: string | null }[];
};

async function loadStats(): Promise<Stats> {
  const [{ data: students }, { data: histories }, { data: recent }] = await Promise.all([
    supabase.from("students").select("id, gender, is_boarding, status, current_class:classes(name)"),
    supabase.from("student_class_histories").select("student_id, is_active, academic_year:academic_years(name)"),
    supabase.from("students").select("id, full_name, nis, status, current_class:classes(name)").order("created_at", { ascending: false }).limit(6),
  ]);
  const rows = students ?? [];
  const active = rows.filter((s) => s.status === "Aktif");
  const activeIds = new Set(active.map((s) => s.id));

  const classMap = new Map<string, number>();
  active.forEach((s: any) => {
    const c = s.current_class?.name ?? "Belum ada kelas";
    classMap.set(c, (classMap.get(c) ?? 0) + 1);
  });

  const yearMap = new Map<string, number>();
  (histories ?? []).forEach((h: any) => {
    if (!h.is_active || !activeIds.has(h.student_id)) return;
    const n = h.academic_year?.name ?? "Tidak diketahui";
    yearMap.set(n, (yearMap.get(n) ?? 0) + 1);
  });

  return {
    active: active.length,
    male: active.filter((s) => s.gender === "Laki-laki").length,
    female: active.filter((s) => s.gender === "Perempuan").length,
    boarding: active.filter((s) => s.is_boarding).length,
    nonBoarding: active.filter((s) => !s.is_boarding).length,
    alumni: rows.filter((s) => s.status === "Lulus").length,
    byClass: Array.from(classMap.entries()).map(([name, total]) => ({ name, total })).sort((a, b) => a.name.localeCompare(b.name)),
    byYear: Array.from(yearMap.entries()).map(([name, total]) => ({ name, total })).sort((a, b) => a.name.localeCompare(b.name)),
    recent: (recent ?? []).map((r: any) => ({
      id: r.id, full_name: r.full_name, nis: r.nis, status: r.status,
      class_name: r.current_class?.name ?? null,
    })),
  };
}

const COLORS = ["oklch(0.545 0.213 262)", "oklch(0.70 0.14 200)", "oklch(0.66 0.16 155)", "oklch(0.78 0.15 75)", "oklch(0.65 0.20 320)"];

function KpiCard({ label, value, icon: Icon, accent = "primary", trend }: {
  label: string; value: number | string; icon: React.ElementType;
  accent?: "primary" | "success" | "info" | "warning" | "muted";
  trend?: string;
}) {
  const accentBg = {
    primary: "bg-primary",
    success: "bg-success",
    info: "bg-info",
    warning: "bg-warning",
    muted: "bg-muted-foreground/40",
  }[accent];
  const iconBg = {
    primary: "bg-primary/10 text-primary",
    success: "bg-success/10 text-success",
    info: "bg-info/10 text-info",
    warning: "bg-warning/15 text-warning-foreground",
    muted: "bg-muted text-muted-foreground",
  }[accent];
  return (
    <Card className="group relative overflow-hidden rounded-xl border border-border bg-card p-5 shadow-soft transition-all hover:-translate-y-0.5 hover:shadow-card">
      <span className={`absolute inset-y-0 left-0 w-1 ${accentBg}`} />
      <div className="flex items-start justify-between">
        <div>
          <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">{label}</div>
          <div className="stat-number mt-2 text-3xl font-bold text-foreground">{value}</div>
          {trend && (
            <div className="mt-1.5 inline-flex items-center gap-1 text-[11px] font-medium text-success">
              <TrendingUp className="h-3 w-3" />
              {trend}
            </div>
          )}
        </div>
        <div className={`grid h-10 w-10 place-items-center rounded-lg ${iconBg}`}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </Card>
  );
}

function Dashboard() {
  const { data, isLoading } = useQuery({ queryKey: ["dashboard-stats"], queryFn: loadStats });
  const stats = data ?? { active: 0, male: 0, female: 0, boarding: 0, nonBoarding: 0, alumni: 0, byClass: [], byYear: [], recent: [] };
  const total = stats.active + stats.alumni;

  const genderData = [
    { name: "Laki-laki", value: stats.male },
    { name: "Perempuan", value: stats.female },
  ];
  const boardingData = [
    { name: "Pesantren", value: stats.boarding },
    { name: "Non-Pesantren", value: stats.nonBoarding },
  ];

  return (
    <div>
      <PageHeader
        title="Dashboard"
        description="Ringkasan data induk siswa dan statistik sekolah secara real-time."
      />

      {/* KPI Grid */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
        <KpiCard label="Total Siswa" value={total} icon={Users} accent="primary" />
        <KpiCard label="Aktif" value={stats.active} icon={Activity} accent="success" />
        <KpiCard label="Laki-laki" value={stats.male} icon={Users} accent="info" />
        <KpiCard label="Perempuan" value={stats.female} icon={Users} accent="warning" />
        <KpiCard label="Pesantren" value={stats.boarding} icon={Home} accent="primary" />
        <KpiCard label="Alumni" value={stats.alumni} icon={UserCheck} accent="muted" />
      </div>

      {/* Charts row */}
      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card className="rounded-xl border border-border bg-card p-5 shadow-soft">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="font-display text-sm font-bold">Distribusi Gender</h3>
              <p className="text-xs text-muted-foreground">Siswa aktif</p>
            </div>
            <div className="grid h-8 w-8 place-items-center rounded-lg bg-primary/10 text-primary">
              <Users className="h-4 w-4" />
            </div>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={genderData} dataKey="value" nameKey="name" innerRadius={45} outerRadius={80} paddingAngle={3}>
                  {genderData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} /><Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="rounded-xl border border-border bg-card p-5 shadow-soft">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="font-display text-sm font-bold">Pesantren vs Non-Pesantren</h3>
              <p className="text-xs text-muted-foreground">Siswa aktif</p>
            </div>
            <div className="grid h-8 w-8 place-items-center rounded-lg bg-success/10 text-success">
              <Home className="h-4 w-4" />
            </div>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={boardingData} dataKey="value" nameKey="name" innerRadius={45} outerRadius={80} paddingAngle={3}>
                  {boardingData.map((_, i) => <Cell key={i} fill={COLORS[(i + 2) % COLORS.length]} />)}
                </Pie>
                <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} /><Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="rounded-xl border border-border bg-card p-5 shadow-soft">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="font-display text-sm font-bold">Per Tahun Ajaran</h3>
              <p className="text-xs text-muted-foreground">Siswa aktif</p>
            </div>
            <div className="grid h-8 w-8 place-items-center rounded-lg bg-info/10 text-info">
              <GraduationCap className="h-4 w-4" />
            </div>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.byYear}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.92 0.008 247)" />
                <XAxis dataKey="name" fontSize={11} />
                <YAxis fontSize={11} allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="total" fill="oklch(0.545 0.213 262)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      {/* Class distribution + Recent students */}
      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card className="rounded-xl border border-border bg-card p-5 shadow-soft lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="font-display text-sm font-bold">Distribusi per Kelas</h3>
              <p className="text-xs text-muted-foreground">Jumlah siswa aktif tiap kelas</p>
            </div>
            <div className="grid h-8 w-8 place-items-center rounded-lg bg-primary/10 text-primary">
              <BookOpen className="h-4 w-4" />
            </div>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.byClass}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.92 0.008 247)" />
                <XAxis dataKey="name" fontSize={11} />
                <YAxis fontSize={11} allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="total" fill="oklch(0.545 0.213 262)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="rounded-xl border border-border bg-card p-5 shadow-soft">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="font-display text-sm font-bold">Aktivitas Terbaru</h3>
              <p className="text-xs text-muted-foreground">Siswa baru terdaftar</p>
            </div>
            <a href="/siswa" className="inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline">
              Lihat <ArrowUpRight className="h-3 w-3" />
            </a>
          </div>
          <ul className="divide-y divide-border">
            {stats.recent.length === 0 && (
              <li className="py-8 text-center text-xs text-muted-foreground">Belum ada data</li>
            )}
            {stats.recent.map((s) => (
              <li key={s.id} className="flex items-center gap-3 py-2.5">
                <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-primary/10 text-xs font-bold text-primary">
                  {s.full_name.slice(0, 2).toUpperCase()}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-medium">{s.full_name}</div>
                  <div className="truncate text-[11px] text-muted-foreground tabular-nums">
                    NIS {s.nis ?? "—"} · {s.class_name ?? "Belum ada kelas"}
                  </div>
                </div>
                <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                  s.status === "Aktif" ? "bg-success/10 text-success" : "bg-muted text-muted-foreground"
                }`}>
                  {s.status ?? "—"}
                </span>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      {isLoading && <div className="mt-4 text-sm text-muted-foreground">Memuat data…</div>}
    </div>
  );
}
