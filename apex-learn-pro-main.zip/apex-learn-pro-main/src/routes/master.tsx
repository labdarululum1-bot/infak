import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Plus, Pencil, Trash2, Search, Check } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";

export const Route = createFileRoute("/master")({
  head: () => ({ meta: [{ title: "Master Data — Buku Induk" }] }),
  component: MasterPage,
});

type Field = { key: string; label: string; type?: "text" | "textarea" | "number" | "checkbox" };

function CrudSection({
  table, title, description, fields, listOrder = "name",
}: {
  table: string;
  title: string;
  description: string;
  fields: Field[];
  listOrder?: string;
}) {
  const qc = useQueryClient();
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const perPage = 10;
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const emptyForm = useMemo(
    () => Object.fromEntries(fields.map((f) => [f.key, f.type === "checkbox" ? false : ""])),
    [fields],
  );
  const [form, setForm] = useState<any>(emptyForm);

  const { data: rows = [] } = useQuery({
    queryKey: [`master-${table}`],
    queryFn: async () => {
      const { data, error } = await supabase.from(table as any).select("*").order(listOrder, { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  });

  const filtered = useMemo(() => {
    const ql = q.toLowerCase().trim();
    if (!ql) return rows;
    return (rows as any[]).filter((r) =>
      fields.some((f) => String(r[f.key] ?? "").toLowerCase().includes(ql)),
    );
  }, [rows, q, fields]);
  const paginated = filtered.slice((page - 1) * perPage, page * perPage);
  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));

  function startAdd() { setEditing(null); setForm(emptyForm); setOpen(true); }
  function startEdit(row: any) {
    setEditing(row);
    setForm(Object.fromEntries(fields.map((f) => [f.key, row[f.key] ?? (f.type === "checkbox" ? false : "")])));
    setOpen(true);
  }
  async function save() {
    const first = fields[0];
    if (!String(form[first.key] ?? "").trim()) return toast.error(`${first.label} wajib diisi`);
    const payload: any = { ...form };
    for (const f of fields) {
      if (f.type === "number") payload[f.key] = payload[f.key] === "" ? null : Number(payload[f.key]);
      if ((f.type === "text" || f.type === "textarea") && payload[f.key] === "") payload[f.key] = null;
    }
    const op = editing
      ? supabase.from(table as any).update(payload).eq("id", editing.id)
      : supabase.from(table as any).insert(payload);
    const { error } = await op;
    if (error) return toast.error(error.message);
    toast.success("Tersimpan");
    setOpen(false);
    qc.invalidateQueries({ queryKey: [`master-${table}`] });
    // Also invalidate common shared queries used elsewhere
    qc.invalidateQueries({ queryKey: ["academic-years"] });
    qc.invalidateQueries({ queryKey: ["classes"] });
    qc.invalidateQueries({ queryKey: ["extracurriculars"] });
  }
  async function del(id: string) {
    if (!confirm("Hapus data ini?")) return;
    const { error } = await supabase.from(table as any).delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Dihapus");
    qc.invalidateQueries({ queryKey: [`master-${table}`] });
  }

  return (
    <Card className="rounded-2xl border border-border p-5 shadow-soft">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="font-display text-base font-semibold">{title}</h3>
          <p className="text-xs text-muted-foreground">{description}</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Cari…" className="w-56 pl-9" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} />
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button size="sm" onClick={startAdd}><Plus className="mr-2 h-4 w-4" />Tambah</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>{editing ? "Ubah" : "Tambah"} {title}</DialogTitle></DialogHeader>
              <div className="space-y-3">
                {fields.map((f) => (
                  <div key={f.key}>
                    <Label className="text-xs">{f.label}</Label>
                    {f.type === "textarea" ? (
                      <Textarea rows={3} value={form[f.key] ?? ""} onChange={(e) => setForm({ ...form, [f.key]: e.target.value })} />
                    ) : f.type === "checkbox" ? (
                      <div className="mt-1 flex items-center gap-2">
                        <input type="checkbox" checked={!!form[f.key]} onChange={(e) => setForm({ ...form, [f.key]: e.target.checked })} />
                        <span className="text-sm text-muted-foreground">Aktif</span>
                      </div>
                    ) : (
                      <Input type={f.type === "number" ? "number" : "text"} value={form[f.key] ?? ""} onChange={(e) => setForm({ ...form, [f.key]: e.target.value })} />
                    )}
                  </div>
                ))}
              </div>
              <DialogFooter><Button onClick={save}>Simpan</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {filtered.length === 0 ? (
        <EmptyState title="Belum ada data" description="Tambahkan data pertama untuk memulai." />
      ) : (
        <>
          <div className="overflow-hidden rounded-xl border border-border">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/40">
                  {fields.map((f) => <TableHead key={f.key}>{f.label}</TableHead>)}
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginated.map((row: any) => (
                  <TableRow key={row.id} className="hover:bg-muted/30">
                    {fields.map((f) => (
                      <TableCell key={f.key} className="text-sm">
                        {f.type === "checkbox" ? (
                          row[f.key] ? <Badge className="bg-success/15 text-success border-transparent"><Check className="mr-1 h-3 w-3" />Aktif</Badge> : <span className="text-muted-foreground">—</span>
                        ) : (
                          <span>{row[f.key] ?? "—"}</span>
                        )}
                      </TableCell>
                    ))}
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" onClick={() => startEdit(row)}><Pencil className="h-4 w-4" /></Button>
                      <Button variant="ghost" size="icon" className="text-destructive" onClick={() => del(row.id)}><Trash2 className="h-4 w-4" /></Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <div className="mt-3 flex items-center justify-between text-sm text-muted-foreground">
            <div>{filtered.length} data</div>
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>Sebelumnya</Button>
              <span>Hal {page} / {totalPages}</span>
              <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>Berikutnya</Button>
            </div>
          </div>
        </>
      )}
    </Card>
  );
}

function MasterPage() {
  return (
    <div>
      <PageHeader
        title="Master Data"
        description="Kelola data referensi yang digunakan di seluruh aplikasi. Perubahan di sini tidak otomatis mengubah data operasional siswa."
      />
      <Tabs defaultValue="years" className="w-full">
        <TabsList className="mb-4 flex flex-wrap">
          <TabsTrigger value="years">Tahun Ajaran</TabsTrigger>
          <TabsTrigger value="classes">Kelas</TabsTrigger>
          <TabsTrigger value="eskul">Ekstrakurikuler</TabsTrigger>
          <TabsTrigger value="subjects">Mata Pelajaran</TabsTrigger>
          <TabsTrigger value="occupations">Pekerjaan Orang Tua</TabsTrigger>
        </TabsList>

        <TabsContent value="years">
          <CrudSection
            table="academic_years"
            title="Tahun Ajaran"
            description="Daftar tahun ajaran. Tahun ajaran aktif diatur di Pengaturan Sekolah."
            fields={[
              { key: "name", label: "Tahun Ajaran" },
              { key: "is_active", label: "Status", type: "checkbox" },
            ]}
          />
        </TabsContent>

        <TabsContent value="classes">
          <CrudSection
            table="classes"
            title="Kelas"
            description="Daftar kelas. Menambah kelas di sini tidak otomatis memindahkan siswa."
            fields={[
              { key: "name", label: "Nama Kelas" },
              { key: "grade_level", label: "Tingkat" },
              { key: "homeroom_teacher", label: "Wali Kelas" },
            ]}
          />
        </TabsContent>

        <TabsContent value="eskul">
          <CrudSection
            table="extracurriculars"
            title="Ekstrakurikuler"
            description="Daftar kegiatan ekstrakurikuler yang tersedia di form siswa."
            fields={[
              { key: "name", label: "Nama Kegiatan" },
              { key: "description", label: "Deskripsi", type: "textarea" },
            ]}
          />
        </TabsContent>

        <TabsContent value="subjects">
          <CrudSection
            table="subjects"
            title="Mata Pelajaran"
            description="Daftar mata pelajaran yang dapat dipilih pada data guru."
            fields={[
              { key: "name", label: "Nama Mata Pelajaran" },
              { key: "code", label: "Kode" },
            ]}
          />
        </TabsContent>

        <TabsContent value="occupations">
          <CrudSection
            table="occupations"
            title="Pekerjaan Orang Tua"
            description="Daftar pilihan pekerjaan yang muncul pada form data siswa."
            fields={[
              { key: "name", label: "Nama Pekerjaan" },
            ]}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}
