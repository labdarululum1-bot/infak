import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Fragment, useMemo } from "react";
import { ChevronLeft, FileText, Printer } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { fetchStudent, fetchClassHistories } from "@/lib/db";
import { fetchStudentGrades } from "@/lib/grades";
import { drawSchoolHeader } from "@/lib/export";
import { SchoolHeader } from "@/components/SchoolHeader";
import { PageHeader } from "@/components/PageHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/nilai/$studentId")({
  head: () => ({ meta: [{ title: "Legger Nilai Siswa — Buku Induk" }] }),
  component: StudentLegger,
});

const SEMESTERS = [1, 2, 3, 4, 5, 6];

function StudentLegger() {
  const { studentId } = Route.useParams();
  const navigate = useNavigate();
  const { data: student } = useQuery({ queryKey: ["student", studentId], queryFn: () => fetchStudent(studentId) });
  const { data: subjects = [] } = useQuery({
    queryKey: ["subjects", "active"],
    queryFn: async () => (await supabase.from("subjects").select("*").eq("is_active", true).order("name")).data ?? [],
  });
  const { data: grades = [] } = useQuery({ queryKey: ["grades", studentId], queryFn: () => fetchStudentGrades(studentId) });
  const { data: history = [] } = useQuery({ queryKey: ["class-history", studentId], queryFn: () => fetchClassHistories(studentId) });

  const bySem = useMemo(() => {
    const m = new Map<number, Map<string, any>>();
    (grades as any[]).forEach((g) => {
      if (!m.has(g.semester)) m.set(g.semester, new Map());
      m.get(g.semester)!.set(g.subject_id, g);
    });
    return m;
  }, [grades]);

  const semAverages = useMemo(() => {
    const out: Record<number, number | null> = {};
    SEMESTERS.forEach((sem) => {
      const rows = (subjects as any[]).map((s) => bySem.get(sem)?.get(s.id)?.final_score).filter((v) => v != null);
      out[sem] = rows.length ? rows.reduce((a, b) => a + Number(b), 0) / rows.length : null;
    });
    return out;
  }, [subjects, bySem]);

  const overallAverage = useMemo(() => {
    const vals = Object.values(semAverages).filter((v): v is number => v != null);
    return vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : null;
  }, [semAverages]);

  async function exportPdf() {
    const doc = new (await import("jspdf")).default({ orientation: "portrait", unit: "pt", format: "a4" });
    const autoTable = (await import("jspdf-autotable")).default;
    let y = await drawSchoolHeader(doc, "LEGGER NILAI SISWA");
    doc.setFontSize(10);
    doc.text(`Nama : ${(student as any)?.full_name ?? "-"}`, 40, y); y += 12;
    doc.text(`NIS   : ${(student as any)?.nis ?? "-"}     NISN : ${(student as any)?.nisn ?? "-"}`, 40, y); y += 12;
    doc.text(`Kelas Saat Ini: ${(student as any)?.current_class?.name ?? "-"}`, 40, y); y += 16;
    const head = ["Mata Pelajaran", ...SEMESTERS.map((s) => `S${s}`), "Rata"];
    const body = (subjects as any[]).map((sub) => {
      const semScores = SEMESTERS.map((sem) => bySem.get(sem)?.get(sub.id)?.final_score ?? "");
      const nums = semScores.filter((v) => v !== "" && v != null).map(Number);
      const avg = nums.length ? (nums.reduce((a, b) => a + b, 0) / nums.length).toFixed(2) : "";
      return [sub.name, ...semScores.map((v) => v === "" || v == null ? "" : String(v)), avg];
    });
    body.push([
      "Rata-Rata Semester",
      ...SEMESTERS.map((s) => semAverages[s] == null ? "" : semAverages[s]!.toFixed(2)),
      overallAverage == null ? "" : overallAverage.toFixed(2),
    ]);
    autoTable(doc, {
      head: [head], body, startY: y,
      styles: { fontSize: 8, cellPadding: 3 },
      headStyles: { fillColor: [59, 130, 246], textColor: 255 },
      foot: [], columnStyles: { 0: { cellWidth: 130 } },
    });
    doc.save(`legger-siswa-${(student as any)?.nis ?? studentId}.pdf`);
  }

  if (!student) return <div className="text-sm text-muted-foreground">Memuat…</div>;

  return (
    <div className="mx-auto max-w-6xl">
      <div className="mb-4 flex items-center justify-between print:hidden">
        <Button variant="ghost" size="sm" onClick={() => navigate({ to: "/siswa/$id/profil", params: { id: studentId } })}>
          <ChevronLeft className="mr-1 h-4 w-4" /> Kembali
        </Button>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={exportPdf}><FileText className="mr-2 h-4 w-4" />Export PDF</Button>
          <Button size="sm" onClick={() => window.print()}><Printer className="mr-2 h-4 w-4" />Cetak</Button>
        </div>
      </div>

      <div className="hidden print:block mb-3"><SchoolHeader subtitle="LEGGER NILAI SISWA (Semester 1–6)" /></div>

      <PageHeader
        title={(student as any).full_name}
        description={`NIS ${(student as any).nis ?? "-"} · NISN ${(student as any).nisn ?? "-"} · Kelas ${(student as any).current_class?.name ?? "-"}`}
      />

      <Card className="mb-4 rounded-2xl border border-border p-4 shadow-soft">
        <h3 className="mb-2 font-display text-sm font-semibold">Identitas Siswa</h3>
        <div className="grid gap-x-6 gap-y-1 text-sm md:grid-cols-2">
          <div><span className="text-muted-foreground">Nama:</span> <b>{(student as any).full_name}</b></div>
          <div><span className="text-muted-foreground">Jenis Kelamin:</span> {(student as any).gender ?? "—"}</div>
          <div><span className="text-muted-foreground">Tempat, Tgl Lahir:</span> {(student as any).place_of_birth ?? "—"}, {(student as any).date_of_birth ?? "—"}</div>
          <div><span className="text-muted-foreground">Agama:</span> {(student as any).religion ?? "—"}</div>
        </div>
      </Card>

      {history.length > 0 && (
        <Card className="mb-4 rounded-2xl border border-border p-4 shadow-soft">
          <h3 className="mb-2 font-display text-sm font-semibold">Riwayat Kelas</h3>
          <table className="w-full text-sm">
            <thead className="bg-muted/40"><tr><th className="px-2 py-1 text-left">Tahun Ajaran</th><th className="px-2 py-1 text-left">Kelas</th></tr></thead>
            <tbody>{(history as any[]).map((h) => (
              <tr key={h.id} className="border-t border-border"><td className="px-2 py-1">{h.academic_year?.name ?? "—"}</td><td className="px-2 py-1">{h.class?.name ?? "—"}</td></tr>
            ))}</tbody>
          </table>
        </Card>
      )}

      <Card className="overflow-auto rounded-2xl border border-border shadow-soft">
        {(subjects as any[]).length === 0 ? (
          <div className="p-6 text-sm text-muted-foreground">Belum ada mata pelajaran. Tambahkan di <Link to="/master" className="text-primary underline">Master Data</Link>.</div>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-muted/40">
              <tr>
                <th className="px-2 py-2 text-left">Mata Pelajaran</th>
                {SEMESTERS.map((s) => (
                  <th key={s} className="px-1 py-2 text-center" colSpan={3}>Semester {s}</th>
                ))}
                <th className="px-2 py-2 text-center">Rata</th>
              </tr>
              <tr className="bg-muted/20 text-xs">
                <th></th>
                {SEMESTERS.map((s) => (
                  <Fragment key={s}>
                    <th className="px-1 py-1 text-center font-medium">P</th>
                    <th className="px-1 py-1 text-center font-medium">K</th>
                    <th className="px-1 py-1 text-center font-medium">A</th>
                  </Fragment>
                ))}

                <th></th>
              </tr>
            </thead>
            <tbody>
              {(subjects as any[]).map((sub) => {
                const finals = SEMESTERS.map((sem) => bySem.get(sem)?.get(sub.id)?.final_score).filter((v) => v != null).map(Number);
                const avg = finals.length ? finals.reduce((a, b) => a + b, 0) / finals.length : null;
                return (
                  <tr key={sub.id} className="border-t border-border">
                    <td className="px-2 py-2 font-medium">{sub.name}</td>
                    {SEMESTERS.map((sem) => {
                      const g = bySem.get(sem)?.get(sub.id);
                      return (
                        <Fragment key={sem}>
                          <td className="px-1 py-2 text-center tabular-nums text-xs">{g?.knowledge_score ?? "—"}</td>
                          <td className="px-1 py-2 text-center tabular-nums text-xs">{g?.skills_score ?? "—"}</td>
                          <td className="px-1 py-2 text-center tabular-nums text-xs font-semibold">{g?.final_score ?? "—"}</td>
                        </Fragment>
                      );
                    })}

                    <td className="px-2 py-2 text-center font-semibold tabular-nums">{avg != null ? avg.toFixed(2) : "—"}</td>
                  </tr>
                );
              })}
              <tr className="border-t-2 border-foreground/40 bg-muted/30 font-semibold">
                <td className="px-2 py-2">Rata-Rata Semester</td>
                {SEMESTERS.map((s) => (
                  <td key={s} colSpan={3} className="px-1 py-2 text-center tabular-nums">
                    {semAverages[s] == null ? "—" : semAverages[s]!.toFixed(2)}
                  </td>
                ))}
                <td className="px-2 py-2 text-center tabular-nums">
                  {overallAverage == null ? "—" : overallAverage.toFixed(2)}
                </td>
              </tr>
            </tbody>
          </table>
        )}
        <div className="border-t border-border px-4 py-2 text-xs text-muted-foreground print:hidden">
          Keterangan: P = Pengetahuan · K = Keterampilan · A = Akhir
        </div>
      </Card>
    </div>
  );
}
