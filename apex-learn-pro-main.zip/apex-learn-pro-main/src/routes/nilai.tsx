import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/nilai")({
  head: () => ({ meta: [{ title: "Nilai — Buku Induk" }] }),
  component: () => <Outlet />,
});
