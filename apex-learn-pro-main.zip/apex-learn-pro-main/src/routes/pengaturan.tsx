import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { Save, Plus, Trash2, Check } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { fetchSchoolProfile, fetchAcademicYears, uploadStudentFile, signedUrl } from "@/lib/db";
import { PageHeader } from "@/components/PageHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const Route = createFileRoute("/pengaturan")({
  head: () => ({ meta: [{ title: "Pengaturan — Buku Induk Siswa" }] }),
  component: SettingsPage,
});

function SettingsPage() {
  const qc = useQueryClient();
  const { data: profile } = useQuery({ queryKey: ["school-profile"], queryFn: fetchSchoolProfile });
  const { data: years = [] } = useQuery({ queryKey: ["academic-years"], queryFn: fetchAcademicYears });

  const [form, setForm] = useState<any>({
    school_name: "", logo_url: "", principal_name: "", address: "",
    phone: "", email: "", website: "", npsn: "", nss: "",
    active_academic_year_id: "", current_academic_year: "",
  });
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [newYear, setNewYear] = useState("");

  useEffect(() => {
    if (profile) setForm({
      school_name: profile.school_name ?? "", logo_url: profile.logo_url ?? "",
      principal_name: profile.principal_name ?? "",
      address: profile.address ?? "",
      phone: (profile as any).phone ?? "", email: (profile as any).email ?? "",
      website: (profile as any).website ?? "",
      npsn: (profile as any).npsn ?? "", nss: (profile as any).nss ?? "",
      active_academic_year_id: (profile as any).active_academic_year_id ?? "",
      current_academic_year: profile.current_academic_year ?? "",
    });
  }, [profile]);

  useEffect(() => {
    if (form.logo_url) signedUrl(form.logo_url).then(setLogoPreview).catch(() => setLogoPreview(null));
    else setLogoPreview(null);
  }, [form.logo_url]);

  async function save() {
    // Mirror the selected active year name into current_academic_year for legacy usage
    const activeYear = (years as any[]).find((y) => y.id === form.active_academic_year_id);
    const payload: any = { ...form, current_academic_year: activeYear?.name ?? form.current_academic_year ?? null };
    if (!payload.active_academic_year_id) payload.active_academic_year_id = null;
    const { error } = await supabase.from("school_profile").upsert({ id: 1, ...payload });
    if (error) return toast.error(error.message);
    // Sync is_active flag on academic_years for backward compat
    if (form.active_academic_year_id) {
      await supabase.from("academic_years").update({ is_active: false }).neq("id", "00000000-0000-0000-0000-000000000000");
      await supabase.from("academic_years").update({ is_active: true }).eq("id", form.active_academic_year_id);
    }
    toast.success("Profil sekolah tersimpan");
    qc.invalidateQueries({ queryKey: ["school-profile"] });
    qc.invalidateQueries({ queryKey: ["academic-years"] });
    qc.invalidateQueries({ queryKey: ["active-academic-year"] });
  }

  async function uploadLogo(file: File) {
    const path = await uploadStudentFile("school", file, "logo");
    setForm((f: any) => ({ ...f, logo_url: path }));
    toast.success("Logo diunggah");
  }

  async function addYear() {
    if (!newYear.trim()) return;
    const { error } = await supabase.from("academic_years").insert({ name: newYear.trim() });
    if (error) return toast.error(error.message);
    setNewYear(""); qc.invalidateQueries({ queryKey: ["academic-years"] });
  }

  async function delYear(id: string) {
    if (!confirm("Hapus tahun ajaran ini?")) return;
    const { error } = await supabase.from("academic_years").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["academic-years"] });
  }

  return (
    <div>
      <PageHeader title="Pengaturan" description="Profil sekolah dan tahun ajaran aktif." />
      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="rounded-2xl border border-border p-5 shadow-soft">
          <h3 className="mb-4 font-display text-base font-semibold">Profil Sekolah</h3>
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="grid h-20 w-20 shrink-0 place-items-center overflow-hidden rounded-2xl bg-muted">
                {logoPreview ? <img src={logoPreview} alt="Logo" className="h-full w-full object-cover" /> : <span className="text-xs text-muted-foreground">Logo</span>}
              </div>
              <label className="cursor-pointer">
                <input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) uploadLogo(f); }} />
                <Button type="button" variant="outline" size="sm" asChild><span>Unggah Logo</span></Button>
              </label>
            </div>
            <div><Label className="text-xs">Nama Sekolah</Label><Input value={form.school_name} onChange={(e) => setForm({ ...form, school_name: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label className="text-xs">NPSN</Label><Input value={form.npsn} onChange={(e) => setForm({ ...form, npsn: e.target.value })} /></div>
              <div><Label className="text-xs">NSM / NSS</Label><Input value={form.nss} onChange={(e) => setForm({ ...form, nss: e.target.value })} /></div>
              <div><Label className="text-xs">Telepon</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
              <div><Label className="text-xs">Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
              <div className="col-span-2"><Label className="text-xs">Website</Label><Input value={form.website} onChange={(e) => setForm({ ...form, website: e.target.value })} /></div>
            </div>
            <div><Label className="text-xs">Nama Kepala Sekolah</Label><Input value={form.principal_name} onChange={(e) => setForm({ ...form, principal_name: e.target.value })} /></div>
            <div>
              <Label className="text-xs">Tahun Ajaran Aktif</Label>
              <Select value={form.active_academic_year_id} onValueChange={(v) => setForm({ ...form, active_academic_year_id: v })}>
                <SelectTrigger><SelectValue placeholder="Pilih tahun ajaran aktif" /></SelectTrigger>
                <SelectContent>
                  {(years as any[]).map((y) => <SelectItem key={y.id} value={y.id}>{y.name}</SelectItem>)}
                </SelectContent>
              </Select>
              <p className="mt-1 text-xs text-muted-foreground">Digunakan otomatis pada form siswa baru dan pencatatan kelas.</p>
            </div>
            <div><Label className="text-xs">Alamat Sekolah</Label><Textarea rows={2} value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
            <Button onClick={save}><Save className="mr-2 h-4 w-4" /> Simpan Profil</Button>
          </div>
        </Card>

        <Card className="rounded-2xl border border-border p-5 shadow-soft">
          <h3 className="mb-4 font-display text-base font-semibold">Tahun Ajaran</h3>
          <p className="mb-3 text-xs text-muted-foreground">Kelola daftar tahun ajaran. Pilih Tahun Ajaran Aktif di panel Profil Sekolah.</p>
          <div className="mb-4 flex gap-2">
            <Input placeholder="contoh: 2025/2026" value={newYear} onChange={(e) => setNewYear(e.target.value)} />
            <Button onClick={addYear}><Plus className="mr-2 h-4 w-4" />Tambah</Button>
          </div>
          <div className="space-y-2">
            {(years as any[]).map((y) => (
              <div key={y.id} className="flex items-center justify-between rounded-xl border border-border p-3">
                <div className="flex items-center gap-3">
                  <span className="font-medium">{y.name}</span>
                  {y.id === form.active_academic_year_id && <Badge className="bg-success/15 text-success border-transparent"><Check className="mr-1 h-3 w-3" />Aktif</Badge>}
                </div>
                <Button variant="ghost" size="icon" className="text-destructive" onClick={() => delYear(y.id)}><Trash2 className="h-4 w-4" /></Button>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
