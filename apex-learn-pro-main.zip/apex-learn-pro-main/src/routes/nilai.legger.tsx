import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { ChevronLeft, Download, FileText, Printer } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { fetchClasses, fetchActiveAcademicYear } from "@/lib/db";
import { fetchClassGrades } from "@/lib/grades";
import { exportToExcel, drawSchoolHeader } from "@/lib/export";
import { SchoolHeader } from "@/components/SchoolHeader";
import { PageHeader } from "@/components/PageHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const Route = createFileRoute("/nilai/legger")({
  head: () => ({ meta: [{ title: "Legger Nilai — Buku Induk" }] }),
  component: LeggerPage,
});

function LeggerPage() {
  const { data: classes = [] } = useQuery({ queryKey: ["classes"], queryFn: fetchClasses });
  const { data: activeYear } = useQuery({ queryKey: ["active-academic-year"], queryFn: fetchActiveAcademicYear });

  const [classId, setClassId] = useState<string>("");
  const [semester, setSemester] = useState<number>(1);

  const effectiveYear = (activeYear as any)?.id ?? "";
  const yearName = (activeYear as any)?.name ?? "—";

  const { data: subjects = [] } = useQuery({
    queryKey: ["subjects", "active"],
    queryFn: async () => (await supabase.from("subjects").select("*").eq("is_active", true).order("name")).data ?? [],
  });
  const { data: students = [] } = useQuery({
    queryKey: ["class-students", classId],
    queryFn: async () => classId ? (await supabase.from("students").select("id,nis,full_name").eq("current_class_id", classId).eq("status", "Aktif").order("full_name")).data ?? [] : [],
    enabled: !!classId,
  });
  const { data: grades = [] } = useQuery({
    queryKey: ["legger", classId, effectiveYear, semester],
    queryFn: () => fetchClassGrades({ classId, academicYearId: effectiveYear, semester }),
    enabled: !!classId,
  });

  const matrix = useMemo(() => {
    const byStudent = new Map<string, Map<string, number>>();
    (grades as any[]).forEach((g) => {
      if (!byStudent.has(g.student_id)) byStudent.set(g.student_id, new Map());
      byStudent.get(g.student_id)!.set(g.subject_id, Number(g.final_score ?? 0));
    });
    const rows = (students as any[]).map((s) => {
      const row: any = { student: s, scores: {} as Record<string, number | null>, avg: 0, rank: 0 };
      let sum = 0, count = 0;
      (subjects as any[]).forEach((sub) => {
        const v = byStudent.get(s.id)?.get(sub.id) ?? null;
        row.scores[sub.id] = v;
        if (v != null) { sum += v; count++; }
      });
      row.avg = count ? sum / count : 0;
      return row;
    });
    const sorted = [...rows].sort((a, b) => b.avg - a.avg);
    sorted.forEach((r, i) => { r.rank = r.avg > 0 ? i + 1 : 0; });
    return rows;
  }, [students, subjects, grades]);

  const subjectAverages = useMemo(() => {
    const out: Record<string, number | null> = {};
    (subjects as any[]).forEach((sub) => {
      const nums = matrix.map((r) => r.scores[sub.id]).filter((v): v is number => v != null && v > 0);
      out[sub.id] = nums.length ? nums.reduce((a, b) => a + b, 0) / nums.length : null;
    });
    return out;
  }, [subjects, matrix]);

  const classAverage = useMemo(() => {
    const nums = matrix.map((r) => r.avg).filter((v) => v > 0);
    return nums.length ? nums.reduce((a, b) => a + b, 0) / nums.length : 0;
  }, [matrix]);


  const classInfo = (classes as any[]).find((c) => c.id === classId);

  function exportExcel() {
    const rows = matrix.map((r, i) => {
      const base: any = { No: i + 1, NIS: r.student.nis ?? "", Nama: r.student.full_name };
      (subjects as any[]).forEach((s) => { base[s.name] = r.scores[s.id] ?? ""; });
      base["Rata-Rata"] = r.avg ? r.avg.toFixed(2) : "";
      base["Peringkat"] = r.rank || "";
      return base;
    });
    const avgRow: any = { No: "", NIS: "", Nama: "Rata-Rata Mapel" };
    (subjects as any[]).forEach((s) => { avgRow[s.name] = subjectAverages[s.id] != null ? subjectAverages[s.id]!.toFixed(2) : ""; });
    avgRow["Rata-Rata"] = classAverage ? classAverage.toFixed(2) : "";
    avgRow["Peringkat"] = "";
    rows.push(avgRow);
    exportToExcel(rows, `legger-${classInfo?.name ?? "kelas"}-sem${semester}`);
  }

  async function exportPdf() {
    const jsPDF = (await import("jspdf")).default;
    const autoTable = (await import("jspdf-autotable")).default;
    const doc = new jsPDF({ orientation: "landscape", unit: "pt", format: "a4" });
    let y = await drawSchoolHeader(doc, `LEGGER NILAI — Kelas ${classInfo?.name ?? "-"} · Semester ${semester}`);
    doc.setFontSize(9);
    doc.text(`Tahun Ajaran: ${yearName}`, 40, y); y += 10;
    const head = ["No", "NIS", "Nama", ...(subjects as any[]).map((s) => s.name), "Rata", "Rank"];
    const body = matrix.map((r, i) => [
      i + 1, r.student.nis ?? "", r.student.full_name,
      ...(subjects as any[]).map((s) => r.scores[s.id] ?? ""),
      r.avg ? r.avg.toFixed(2) : "",
      r.rank || "",
    ]);
    body.push([
      "", "", "Rata-Rata Mapel",
      ...(subjects as any[]).map((s) => subjectAverages[s.id] != null ? subjectAverages[s.id]!.toFixed(2) : ""),
      classAverage ? classAverage.toFixed(2) : "",
      "",
    ]);
    autoTable(doc, {
      head: [head], body, startY: y + 6,
      styles: { fontSize: 8, cellPadding: 3 },
      headStyles: { fillColor: [59, 130, 246], textColor: 255 },
    });
    doc.save(`legger-${classInfo?.name ?? "kelas"}-sem${semester}.pdf`);
  }


  return (
    <div className="mx-auto max-w-7xl">
      <div className="mb-4 flex items-center justify-between print:hidden">
        <Button asChild variant="ghost" size="sm"><Link to="/nilai"><ChevronLeft className="mr-1 h-4 w-4" />Kembali</Link></Button>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={exportExcel} disabled={!classId}><Download className="mr-2 h-4 w-4" />Excel</Button>
          <Button variant="outline" size="sm" onClick={exportPdf} disabled={!classId}><FileText className="mr-2 h-4 w-4" />PDF</Button>
          <Button size="sm" onClick={() => window.print()} disabled={!classId}><Printer className="mr-2 h-4 w-4" />Cetak</Button>
        </div>
      </div>

      <PageHeader title="Legger Nilai" description={`Tahun Ajaran Aktif: ${yearName} · Rekap nilai satu kelas per semester.`} />

      <Card className="mb-4 rounded-2xl border border-border p-4 shadow-soft print:hidden">
        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <Label className="text-xs">Kelas</Label>
            <Select value={classId} onValueChange={setClassId}>
              <SelectTrigger><SelectValue placeholder="Pilih kelas" /></SelectTrigger>
              <SelectContent>{(classes as any[]).map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Semester</Label>
            <Select value={String(semester)} onValueChange={(v) => setSemester(Number(v))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{[1, 2, 3, 4, 5, 6].map((s) => <SelectItem key={s} value={String(s)}>Semester {s}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      <div className="hidden print:block mb-3"><SchoolHeader subtitle={`LEGGER NILAI — Kelas ${classInfo?.name ?? "-"} · Semester ${semester}`} /></div>

      <Card className="overflow-auto rounded-2xl border border-border shadow-soft">
        {!classId ? (
          <div className="p-6 text-sm text-muted-foreground">Pilih kelas untuk melihat legger.</div>
        ) : matrix.length === 0 ? (
          <div className="p-6 text-sm text-muted-foreground">Belum ada siswa pada kelas ini.</div>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-muted/40">
              <tr>
                <th className="px-2 py-2 text-left">No</th>
                <th className="px-2 py-2 text-left">NIS</th>
                <th className="px-2 py-2 text-left">Nama</th>
                {(subjects as any[]).map((s) => <th key={s.id} className="px-2 py-2 text-center">{s.name}</th>)}
                <th className="px-2 py-2 text-center">Rata</th>
                <th className="px-2 py-2 text-center">Peringkat</th>
              </tr>
            </thead>
            <tbody>
              {matrix.map((r, i) => (
                <tr key={r.student.id} className="border-t border-border">
                  <td className="px-2 py-2 tabular-nums">{i + 1}</td>
                  <td className="px-2 py-2 tabular-nums">{r.student.nis ?? "—"}</td>
                  <td className="px-2 py-2">{r.student.full_name}</td>
                  {(subjects as any[]).map((s) => <td key={s.id} className="px-2 py-2 text-center tabular-nums">{r.scores[s.id] ?? "—"}</td>)}
                  <td className="px-2 py-2 text-center font-semibold tabular-nums">{r.avg ? r.avg.toFixed(2) : "—"}</td>
                  <td className="px-2 py-2 text-center font-semibold tabular-nums">{r.rank || "—"}</td>
                </tr>
              ))}
              <tr className="border-t-2 border-foreground/40 bg-muted/30 font-semibold">
                <td className="px-2 py-2" colSpan={3}>Rata-Rata Mapel</td>
                {(subjects as any[]).map((s) => (
                  <td key={s.id} className="px-2 py-2 text-center tabular-nums">
                    {subjectAverages[s.id] != null ? subjectAverages[s.id]!.toFixed(2) : "—"}
                  </td>
                ))}
                <td className="px-2 py-2 text-center tabular-nums">{classAverage ? classAverage.toFixed(2) : "—"}</td>
                <td></td>
              </tr>
            </tbody>
          </table>

        )}
      </Card>
    </div>
  );
}
