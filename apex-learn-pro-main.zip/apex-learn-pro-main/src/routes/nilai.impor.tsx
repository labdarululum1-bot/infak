import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { ChevronLeft, Download, Upload } from "lucide-react";
import { toast } from "sonner";
import * as XLSX from "xlsx";
import { supabase } from "@/integrations/supabase/client";
import { fetchClasses, fetchActiveAcademicYear } from "@/lib/db";
import { upsertGrades, type GradeRow } from "@/lib/grades";
import { PageHeader } from "@/components/PageHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const Route = createFileRoute("/nilai/impor")({
  head: () => ({ meta: [{ title: "Import Nilai — Buku Induk" }] }),
  component: NilaiImportPage,
});

type RowError = { row: number; reason: string };

function NilaiImportPage() {
  const { data: activeYear } = useQuery({ queryKey: ["active-academic-year"], queryFn: fetchActiveAcademicYear });
  const { data: classes = [] } = useQuery({ queryKey: ["classes"], queryFn: fetchClasses });
  const { data: subjects = [] } = useQuery({
    queryKey: ["subjects", "active"],
    queryFn: async () => (await supabase.from("subjects").select("*").eq("is_active", true).order("name")).data ?? [],
  });

  const [semester, setSemester] = useState<string>("");
  const [classId, setClassId] = useState<string>("");
  const [subjectId, setSubjectId] = useState<string>("");
  const [busy, setBusy] = useState(false);
  const [summary, setSummary] = useState<{ total: number; imported: number; failed: RowError[]; duplicated: number } | null>(null);

  const yearId = (activeYear as any)?.id ?? "";
  const yearName = (activeYear as any)?.name ?? "—";
  const canImport = !!yearId && !!semester && !!classId && !!subjectId;

  async function downloadTemplate() {
    if (!classId) return toast.error("Pilih kelas terlebih dahulu");
    const { data: students = [] } = await supabase.from("students")
      .select("nis,full_name").eq("current_class_id", classId).eq("status", "Aktif").order("full_name");
    const rows = (students as any[]).map((s) => ({
      NIS: s.nis ?? "", "Nama Siswa": s.full_name, Pengetahuan: "", Keterampilan: "", "Nilai Akhir": "",
    }));
    if (rows.length === 0) rows.push({ NIS: "", "Nama Siswa": "", Pengetahuan: "", Keterampilan: "", "Nilai Akhir": "" });
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Nilai");
    XLSX.writeFile(wb, "template-import-nilai.xlsx");
  }

  async function handleFile(file: File) {
    if (!canImport) return toast.error("Lengkapi filter di atas");
    setBusy(true); setSummary(null);
    try {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: "array" });
      const rows = XLSX.utils.sheet_to_json<any>(wb.Sheets[wb.SheetNames[0]]);
      const { data: students = [] } = await supabase.from("students")
        .select("id,nis,nisn").eq("current_class_id", classId).eq("status", "Aktif");
      const byNis = new Map<string, any>();
      (students as any[]).forEach((s) => { if (s.nis) byNis.set(String(s.nis), s); if (s.nisn) byNis.set(String(s.nisn), s); });

      const failed: RowError[] = [];
      const inserts: GradeRow[] = [];
      const seen = new Set<string>();
      let duplicated = 0;
      rows.forEach((r, idx) => {
        const rowNum = idx + 2;
        const nis = String(r.NIS ?? r.nis ?? r.NISN ?? "").trim();
        if (!nis) return failed.push({ row: rowNum, reason: "NIS kosong" });
        const stu = byNis.get(nis);
        if (!stu) return failed.push({ row: rowNum, reason: `Siswa NIS ${nis} tidak ada di kelas ini` });
        if (seen.has(stu.id)) { duplicated++; return; }
        seen.add(stu.id);
        const kn = r.Pengetahuan == null || r.Pengetahuan === "" ? null : Number(r.Pengetahuan);
        const sk = r.Keterampilan == null || r.Keterampilan === "" ? null : Number(r.Keterampilan);
        let fn = r["Nilai Akhir"] == null || r["Nilai Akhir"] === "" ? null : Number(r["Nilai Akhir"]);
        if (fn == null && (kn != null || sk != null)) {
          const parts = [kn, sk].filter((x): x is number => x != null);
          fn = parts.reduce((a, b) => a + b, 0) / parts.length;
        }
        if (kn == null && sk == null && fn == null) return failed.push({ row: rowNum, reason: "Semua nilai kosong" });
        inserts.push({
          student_id: stu.id, academic_year_id: yearId, class_id: classId,
          semester: Number(semester), subject_id: subjectId,
          knowledge_score: kn, skills_score: sk, final_score: fn,
        });
      });
      if (inserts.length) await upsertGrades(inserts);
      setSummary({ total: rows.length, imported: inserts.length, failed, duplicated });
      toast.success(`Import: ${inserts.length}/${rows.length} baris`);
    } catch (e: any) {
      toast.error(e.message ?? "Gagal memproses file");
    } finally { setBusy(false); }
  }

  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-4"><Button asChild variant="ghost" size="sm"><Link to="/nilai"><ChevronLeft className="mr-1 h-4 w-4" />Kembali</Link></Button></div>
      <PageHeader title="Import Nilai" description={`Tahun Ajaran Aktif: ${yearName} · Alur: Kelas → Semester → Mapel → Unggah Excel.`} />

      <Card className="mb-4 rounded-2xl border border-border p-4 shadow-soft">
        <div className="grid gap-3 md:grid-cols-3">
          <div>
            <Label className="text-xs">Kelas</Label>
            <Select value={classId} onValueChange={setClassId}>
              <SelectTrigger><SelectValue placeholder="Pilih" /></SelectTrigger>
              <SelectContent>{(classes as any[]).map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Semester</Label>
            <Select value={semester} onValueChange={setSemester} disabled={!classId}>
              <SelectTrigger><SelectValue placeholder="Pilih" /></SelectTrigger>
              <SelectContent>{[1, 2, 3, 4, 5, 6].map((s) => <SelectItem key={s} value={String(s)}>Semester {s}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Mata Pelajaran</Label>
            <Select value={subjectId} onValueChange={setSubjectId} disabled={!semester}>
              <SelectTrigger><SelectValue placeholder="Pilih" /></SelectTrigger>
              <SelectContent>{(subjects as any[]).map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      <Card className="mb-4 rounded-2xl border border-border p-5 shadow-soft">
        <div className="mb-4 flex flex-wrap items-center gap-3">
          <Button variant="outline" onClick={downloadTemplate} disabled={!classId}><Download className="mr-2 h-4 w-4" />Unduh Template</Button>
          <label className={`inline-flex cursor-pointer items-center gap-2 rounded-md border border-input bg-primary px-4 py-2 text-sm font-medium text-primary-foreground ${busy || !canImport ? "pointer-events-none opacity-60" : ""}`}>
            <Upload className="h-4 w-4" />{busy ? "Memproses…" : "Pilih File Excel"}
            <input type="file" accept=".xlsx,.xls" className="hidden" disabled={busy || !canImport} onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); (e.target as HTMLInputElement).value = ""; }} />
          </label>
        </div>
        <div className="text-sm text-muted-foreground">
          Kolom: <b>NIS</b>, Pengetahuan, Keterampilan, Nilai Akhir. Data hanya berlaku untuk kelas, semester, dan mapel yang dipilih.
        </div>
      </Card>

      {summary && (
        <Card className="rounded-2xl border border-border p-5 shadow-soft">
          <h3 className="mb-3 font-display text-base font-semibold">Ringkasan Import</h3>
          <div className="mb-4 flex flex-wrap gap-2">
            <Badge variant="outline">Total: {summary.total}</Badge>
            <Badge className="bg-success/15 text-success border-transparent">Berhasil: {summary.imported}</Badge>
            <Badge className="bg-warning/15 text-warning border-transparent">Duplikat: {summary.duplicated}</Badge>
            <Badge className="bg-destructive/15 text-destructive border-transparent">Gagal: {summary.failed.length}</Badge>
          </div>
          {summary.failed.length > 0 && (
            <div className="max-h-72 overflow-y-auto rounded-xl border border-border">
              <table className="w-full text-sm">
                <thead className="bg-muted/40"><tr><th className="px-3 py-2 text-left">Baris</th><th className="px-3 py-2 text-left">Alasan</th></tr></thead>
                <tbody>
                  {summary.failed.map((f, i) => (<tr key={i} className="border-t border-border"><td className="px-3 py-2 tabular-nums">{f.row}</td><td className="px-3 py-2">{f.reason}</td></tr>))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      )}
    </div>
  );
}
