import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { FileText, Download, BookOpen, Users, Home, GraduationCap, MapPin, UserCheck, Award } from "lucide-react";
import { fetchStudents } from "@/lib/db";
import { exportToExcel, exportToPDF } from "@/lib/export";
import { PageHeader } from "@/components/PageHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/laporan")({
  head: () => ({ meta: [{ title: "Laporan — Buku Induk Siswa" }] }),
  component: ReportsPage,
});

const gradYearOf = (s: any) => (s.exit_date ? String(s.exit_date).slice(0, 4) : "-");

function ReportsPage() {
  const { data: active = [] } = useQuery({ queryKey: ["students", "Aktif"], queryFn: () => fetchStudents("Aktif") });
  const { data: alumni = [] } = useQuery({ queryKey: ["students", "Lulus"], queryFn: () => fetchStudents("Lulus") });

  type R = { icon: any; title: string; desc: string; cols: string[]; rows: () => (string | number | null | undefined)[][]; file: string; orientation: "portrait" | "landscape" };

  const reports: R[] = [
    {
      icon: BookOpen, title: "Buku Induk Siswa", desc: "Daftar siswa aktif dengan data identitas utama.",
      cols: ["No. Induk", "NIS", "NISN", "NIK", "Nama", "L/P", "Tempat, Tgl Lahir", "Kelas", "Alamat"],
      rows: () => active.map((s: any) => [s.master_book_number ?? "-", s.nis ?? "-", s.nisn ?? "-", s.nik ?? "-", s.full_name, s.gender === "Laki-laki" ? "L" : "P", `${s.place_of_birth ?? "-"}, ${s.date_of_birth ?? "-"}`, s.current_class?.name ?? "-", s.address ?? "-"]),
      file: "buku-induk-siswa", orientation: "landscape",
    },
    {
      icon: Users, title: "Daftar Siswa Aktif", desc: "Daftar singkat seluruh siswa aktif.",
      cols: ["No.", "NIS", "Nama", "Kelas", "Gender"],
      rows: () => active.map((s: any, i: number) => [i + 1, s.nis ?? "-", s.full_name, s.current_class?.name ?? "-", s.gender ?? "-"]),
      file: "daftar-siswa-aktif", orientation: "portrait",
    },
    {
      icon: Home, title: "Siswa Pesantren", desc: "Siswa aktif yang tinggal di pesantren / asrama.",
      cols: ["NIS", "Nama", "Kelas", "Gender"],
      rows: () => active.filter((s: any) => s.is_boarding).map((s: any) => [s.nis ?? "-", s.full_name, s.current_class?.name ?? "-", s.gender ?? "-"]),
      file: "siswa-pesantren", orientation: "portrait",
    },
    {
      icon: Home, title: "Siswa Non-Pesantren", desc: "Siswa aktif yang tidak tinggal di pesantren.",
      cols: ["NIS", "Nama", "Kelas", "Alamat"],
      rows: () => active.filter((s: any) => !s.is_boarding).map((s: any) => [s.nis ?? "-", s.full_name, s.current_class?.name ?? "-", s.address ?? "-"]),
      file: "siswa-non-pesantren", orientation: "landscape",
    },
    {
      icon: GraduationCap, title: "Siswa per Kelas", desc: "Pengelompokan siswa aktif berdasarkan kelas.",
      cols: ["Kelas", "Nama", "Gender"],
      rows: () => active.slice().sort((a: any, b: any) => (a.current_class?.name ?? "zz").localeCompare(b.current_class?.name ?? "zz")).map((s: any) => [s.current_class?.name ?? "Belum ada kelas", s.full_name, s.gender ?? "-"]),
      file: "siswa-per-kelas", orientation: "portrait",
    },
    {
      icon: MapPin, title: "Siswa per Desa", desc: "Siswa aktif berdasarkan desa / kelurahan.",
      cols: ["Desa", "Nama", "Kelas"],
      rows: () => active.slice().sort((a: any, b: any) => (a.village ?? "zz").localeCompare(b.village ?? "zz")).map((s: any) => [s.village ?? "-", s.full_name, s.current_class?.name ?? "-"]),
      file: "siswa-per-desa", orientation: "portrait",
    },
    {
      icon: MapPin, title: "Siswa per Kecamatan", desc: "Siswa aktif berdasarkan kecamatan.",
      cols: ["Kecamatan", "Nama", "Kelas"],
      rows: () => active.slice().sort((a: any, b: any) => (a.district ?? "zz").localeCompare(b.district ?? "zz")).map((s: any) => [s.district ?? "-", s.full_name, s.current_class?.name ?? "-"]),
      file: "siswa-per-kecamatan", orientation: "portrait",
    },
    {
      icon: Users, title: "Statistik Gender", desc: "Ringkasan jumlah siswa aktif per jenis kelamin.",
      cols: ["Jenis Kelamin", "Jumlah"],
      rows: () => [
        ["Laki-laki", active.filter((s: any) => s.gender === "Laki-laki").length],
        ["Perempuan", active.filter((s: any) => s.gender === "Perempuan").length],
        ["Total", active.length],
      ],
      file: "statistik-gender", orientation: "portrait",
    },
    {
      icon: Home, title: "Statistik Pesantren", desc: "Pesantren vs non-pesantren (siswa aktif).",
      cols: ["Kategori", "Jumlah"],
      rows: () => [
        ["Pesantren", active.filter((s: any) => s.is_boarding).length],
        ["Non-Pesantren", active.filter((s: any) => !s.is_boarding).length],
      ],
      file: "statistik-pesantren", orientation: "portrait",
    },
    {
      icon: UserCheck, title: "Daftar Alumni", desc: "Seluruh siswa berstatus Lulus.",
      cols: ["Nama", "NIS", "Tahun Lulus", "Kelas Terakhir"],
      rows: () => alumni.map((s: any) => [s.full_name, s.nis ?? "-", gradYearOf(s), s.current_class?.name ?? "-"]),
      file: "daftar-alumni", orientation: "portrait",
    },
    {
      icon: Award, title: "Alumni per Tahun Ajaran Lulus", desc: "Daftar alumni dikelompokkan berdasarkan tahun kelulusan.",
      cols: ["Tahun Lulus", "Nama", "Kelas Terakhir"],
      rows: () => alumni.slice().sort((a: any, b: any) => gradYearOf(b).localeCompare(gradYearOf(a))).map((s: any) => [gradYearOf(s), s.full_name, s.current_class?.name ?? "-"]),
      file: "alumni-per-tahun", orientation: "portrait",
    },
    {
      icon: GraduationCap, title: "Lulusan per Kelas", desc: "Alumni dikelompokkan berdasarkan kelas terakhir.",
      cols: ["Kelas Terakhir", "Nama", "Tahun Lulus", "Gender"],
      rows: () => alumni.slice().sort((a: any, b: any) => (a.current_class?.name ?? "zz").localeCompare(b.current_class?.name ?? "zz")).map((s: any) => [s.current_class?.name ?? "-", s.full_name, gradYearOf(s), s.gender ?? "-"]),
      file: "lulusan-per-kelas", orientation: "portrait",
    },
    {
      icon: Award, title: "Ringkasan Kelulusan", desc: "Total alumni per tahun ajaran kelulusan.",
      cols: ["Tahun Lulus", "Total Alumni", "Laki-laki", "Perempuan"],
      rows: () => {
        const map = new Map<string, { total: number; m: number; f: number }>();
        alumni.forEach((s: any) => {
          const y = gradYearOf(s);
          const r = map.get(y) ?? { total: 0, m: 0, f: 0 };
          r.total++; if (s.gender === "Laki-laki") r.m++; if (s.gender === "Perempuan") r.f++;
          map.set(y, r);
        });
        return Array.from(map.entries()).sort((a, b) => b[0].localeCompare(a[0])).map(([y, r]) => [y, r.total, r.m, r.f]);
      },
      file: "ringkasan-kelulusan", orientation: "portrait",
    },
  ];

  return (
    <div>
      <PageHeader title="Laporan" description="Cetak laporan dan ekspor ke PDF atau Excel. Laporan siswa hanya menampilkan siswa aktif; laporan alumni hanya menampilkan siswa lulus." />
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {reports.map((r) => {
          const Icon = r.icon;
          return (
            <Card key={r.title} className="rounded-2xl border border-border p-5 shadow-soft transition hover:shadow-card">
              <div className="mb-4 flex items-start gap-3">
                <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary-soft text-primary"><Icon className="h-5 w-5" /></div>
                <div className="min-w-0">
                  <div className="font-display font-semibold">{r.title}</div>
                  <div className="mt-0.5 text-xs text-muted-foreground">{r.desc}</div>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1" onClick={() => {
                  const rowsArr = r.rows();
                  const data = rowsArr.map((row) => Object.fromEntries(r.cols.map((c, i) => [c, row[i]])));
                  exportToExcel(data, r.file);
                }}><Download className="mr-2 h-4 w-4" />Excel</Button>
                <Button size="sm" className="flex-1" onClick={() => exportToPDF({
                  title: r.title, subtitle: `Total: ${r.rows().length} baris`,
                  columns: r.cols, rows: r.rows(), filename: r.file, orientation: r.orientation,
                })}><FileText className="mr-2 h-4 w-4" />PDF</Button>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
