import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Database as DatabaseIcon, Download, Upload, AlertTriangle, History, CheckCircle2, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/PageHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Progress } from "@/components/ui/progress";

export const Route = createFileRoute("/database")({
  head: () => ({ meta: [{ title: "Database — Buku Induk Siswa" }] }),
  component: DatabasePage,
});

// Tables included in backups. Order matters on restore (parents before children).
const BACKUP_TABLES = [
  "academic_years", "extracurriculars", "school_profile", "classes",
  "students", "student_extracurriculars", "student_documents",
] as const;

function bytes(n: number) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(2)} MB`;
}

function DatabasePage() {
  const qc = useQueryClient();
  const [backingUp, setBackingUp] = useState(false);
  const [restoring, setRestoring] = useState(false);
  const [resetting, setResetting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [note, setNote] = useState("");

  async function runReset() {
    setResetting(true); setProgress(0);
    // Order matters: child tables first
    const ORDER = ["student_extracurriculars", "student_documents", "student_class_histories", "students"];
    try {
      for (let i = 0; i < ORDER.length; i++) {
        const t = ORDER[i];
        const { error } = await (supabase.from(t as any).delete() as any).not("id", "is", null);
        if (error) throw error;
        setProgress(Math.round(((i + 1) / ORDER.length) * 100));
      }
      toast.success("Reset selesai. Data master dan pengaturan tetap aman.");
      qc.invalidateQueries();
    } catch (e: any) {
      toast.error("Gagal reset: " + e.message);
    } finally { setResetting(false); }
  }

  const { data: history = [] } = useQuery({
    queryKey: ["backup-history"],
    queryFn: async () => {
      const { data } = await supabase.from("database_backups").select("*").order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  async function runBackup() {
    setBackingUp(true); setProgress(0);
    try {
      const payload: Record<string, any[]> = {};
      for (let i = 0; i < BACKUP_TABLES.length; i++) {
        const t = BACKUP_TABLES[i];
        const { data, error } = await supabase.from(t).select("*");
        if (error) throw error;
        payload[t] = data ?? [];
        setProgress(Math.round(((i + 1) / BACKUP_TABLES.length) * 100));
      }
      const json = JSON.stringify({ created_at: new Date().toISOString(), version: 1, tables: payload }, null, 2);
      const blob = new Blob([json], { type: "application/json" });
      const filename = `backup-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-")}.json`;

      // Trigger download
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a"); a.href = url; a.download = filename; a.click();
      URL.revokeObjectURL(url);

      // Record backup history
      await supabase.from("database_backups").insert({
        file_path: filename, file_size_bytes: blob.size, note: note || null,
      });
      setNote("");
      toast.success("Backup berhasil. File telah diunduh.");
      qc.invalidateQueries({ queryKey: ["backup-history"] });
    } catch (e: any) {
      toast.error("Gagal backup: " + e.message);
    } finally {
      setBackingUp(false);
    }
  }

  async function runRestore(file: File) {
    setRestoring(true); setProgress(0);
    try {
      const text = await file.text();
      let data: any;
      try { data = JSON.parse(text); } catch { throw new Error("File backup tidak valid (bukan JSON)"); }
      if (!data?.tables) throw new Error("Struktur backup tidak dikenali");

      // Validate every key exists in the schema list
      for (const t of Object.keys(data.tables)) {
        if (!BACKUP_TABLES.includes(t as any)) throw new Error(`Tabel tidak dikenal di backup: ${t}`);
      }

      // Restore via upsert (preserves IDs). Skip empty arrays.
      for (let i = 0; i < BACKUP_TABLES.length; i++) {
        const t = BACKUP_TABLES[i];
        const rows = data.tables[t];
        if (Array.isArray(rows) && rows.length) {
          // chunk by 500 to keep payloads small
          for (let c = 0; c < rows.length; c += 500) {
            const chunk = rows.slice(c, c + 500);
            const onConflict =
              t === "student_extracurriculars" ? "student_id,extracurricular_id"
              : t === "academic_years" ? "name"
              : t === "extracurriculars" ? "name"
              : "id";
            const { error } = await supabase.from(t).upsert(chunk, { onConflict });
            if (error) throw new Error(`${t}: ${error.message}`);
          }
        }
        setProgress(Math.round(((i + 1) / BACKUP_TABLES.length) * 100));
      }

      toast.success("Restore selesai. Data berhasil dipulihkan.");
      qc.invalidateQueries();
    } catch (e: any) {
      toast.error("Gagal restore: " + e.message);
    } finally {
      setRestoring(false);
    }
  }

  return (
    <div>
      <PageHeader title="Database" description="Backup dan restore seluruh data sistem. File backup dapat disimpan dan diunggah kembali untuk pemulihan." />

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="rounded-2xl border border-border p-5 shadow-soft">
          <div className="mb-4 flex items-center gap-2">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-primary-soft text-primary"><Download className="h-5 w-5" /></div>
            <div>
              <h3 className="font-display text-base font-semibold">Backup Database</h3>
              <p className="text-xs text-muted-foreground">Unduh seluruh data dalam satu file backup (.json).</p>
            </div>
          </div>
          <div className="space-y-3">
            <div>
              <Label className="text-xs">Catatan (opsional)</Label>
              <Input value={note} onChange={(e) => setNote(e.target.value)} placeholder="contoh: backup sebelum kenaikan kelas" />
            </div>
            {backingUp && <Progress value={progress} />}
            <Button onClick={runBackup} disabled={backingUp}>
              <Download className="mr-2 h-4 w-4" /> {backingUp ? "Membuat backup…" : "Backup Sekarang"}
            </Button>
          </div>
        </Card>

        <Card className="rounded-2xl border border-border p-5 shadow-soft">
          <div className="mb-4 flex items-center gap-2">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-primary-soft text-primary"><Upload className="h-5 w-5" /></div>
            <div>
              <h3 className="font-display text-base font-semibold">Restore Database</h3>
              <p className="text-xs text-muted-foreground">Pulihkan data dari file backup. Data dengan ID yang sama akan ditimpa.</p>
            </div>
          </div>
          <div className="space-y-3">
            <div className="rounded-xl border border-warning/30 bg-warning/10 p-3 text-sm">
              <div className="flex items-start gap-2">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-warning-foreground" />
                <div className="text-warning-foreground">Restore akan menimpa data dengan ID yang sama. Disarankan melakukan backup terlebih dahulu.</div>
              </div>
            </div>
            {restoring && <Progress value={progress} />}
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" disabled={restoring}><Upload className="mr-2 h-4 w-4" />{restoring ? "Memulihkan…" : "Pilih File Backup"}</Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Konfirmasi Restore</AlertDialogTitle>
                  <AlertDialogDescription>
                    Data dalam file backup akan dimasukkan ke database. Baris dengan ID yang sama akan diperbarui (overwrite). Lanjutkan memilih file?
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Batal</AlertDialogCancel>
                  <AlertDialogAction onClick={() => {
                    const input = document.createElement("input");
                    input.type = "file"; input.accept = ".json,application/json";
                    input.onchange = () => { const f = input.files?.[0]; if (f) runRestore(f); };
                    input.click();
                  }}>Pilih File</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </Card>
      </div>

      <Card className="mt-4 rounded-2xl border border-border p-5 shadow-soft">
        <div className="mb-4 flex items-center gap-2">
          <History className="h-5 w-5 text-primary" />
          <h3 className="font-display text-base font-semibold">Riwayat Backup</h3>
        </div>
        {history.length === 0 ? (
          <p className="text-sm text-muted-foreground">Belum ada riwayat backup.</p>
        ) : (
          <div className="overflow-hidden rounded-xl border border-border">
            <table className="w-full text-sm">
              <thead className="bg-muted/40"><tr><th className="px-3 py-2 text-left">Tanggal</th><th className="px-3 py-2 text-left">File</th><th className="px-3 py-2 text-left">Ukuran</th><th className="px-3 py-2 text-left">Catatan</th></tr></thead>
              <tbody>
                {history.map((b: any) => (
                  <tr key={b.id} className="border-t border-border">
                    <td className="px-3 py-2 tabular-nums">{new Date(b.created_at).toLocaleString("id-ID")}</td>
                    <td className="px-3 py-2 font-mono text-xs">{b.file_path}</td>
                    <td className="px-3 py-2 tabular-nums">{bytes(Number(b.file_size_bytes))}</td>
                    <td className="px-3 py-2 text-muted-foreground">{b.note ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Card className="mt-4 rounded-2xl border border-destructive/30 bg-destructive/[0.03] p-5 shadow-soft">
        <div className="mb-4 flex items-center gap-2">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-destructive/10 text-destructive"><Trash2 className="h-5 w-5" /></div>
          <div>
            <h3 className="font-display text-base font-semibold">Reset Database</h3>
            <p className="text-xs text-muted-foreground">Hapus semua data siswa, riwayat kelas, ekstrakurikuler siswa, dan dokumen. Data master (kelas, tahun ajaran, ekstrakurikuler, guru) serta pengaturan tetap dipertahankan.</p>
          </div>
        </div>
        {resetting && <div className="mb-3"><Progress value={progress} /></div>}
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="destructive" disabled={resetting}><Trash2 className="mr-2 h-4 w-4" />{resetting ? "Mereset…" : "Reset Database"}</Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Peringatan!</AlertDialogTitle>
              <AlertDialogDescription>
                Semua data siswa beserta dokumen, ekstrakurikuler, dan riwayat kelas akan dihapus permanen. Data master dan pengaturan akan tetap aman. Tindakan ini tidak dapat dibatalkan.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Batal</AlertDialogCancel>
              <AlertDialogAction onClick={runReset} className="bg-destructive text-destructive-foreground">Ya, Reset</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </Card>
    </div>
  );
}
