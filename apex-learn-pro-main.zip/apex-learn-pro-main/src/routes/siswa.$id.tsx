import { createFileRoute, Navigate, Outlet, useRouterState } from "@tanstack/react-router";

export const Route = createFileRoute("/siswa/$id")({
  component: StudentDetailLayout,
});

function StudentDetailLayout() {
  const { id } = Route.useParams();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  if (pathname === `/siswa/${id}`) {
    return <Navigate to="/siswa/$id/profil" params={{ id }} replace />;
  }

  return <Outlet />;
}
