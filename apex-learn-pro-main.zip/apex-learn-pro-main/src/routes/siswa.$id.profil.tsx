import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, Pencil, Printer, Download, Eye, FileText, ClipboardList } from "lucide-react";
import { Fragment, useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { fetchStudent, fetchClassHistories, fetchStudentExtracurriculars, signedUrl } from "@/lib/db";
import { fetchStudentGrades } from "@/lib/grades";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SchoolHeader } from "@/components/SchoolHeader";

export const Route = createFileRoute("/siswa/$id/profil")({
  head: () => ({ meta: [{ title: "Profil Siswa — Buku Induk" }] }),
  component: ProfilPage,
});

function Row({ label, value }: { label: string; value: any }) {
  const text = value === null || value === undefined || value === "" ? "—" : value;
  return (
    <div className="grid grid-cols-[150px_1fr] gap-2 border-b border-border/60 py-2 text-sm last:border-b-0 print:grid-cols-[42mm_1fr]">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium text-foreground">{text}</span>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <Card className="profile-card rounded-2xl border border-border p-5 shadow-soft print:rounded-none">
      <h3 className="mb-3 font-display text-base font-semibold">{title}</h3>
      <div className="grid gap-x-6 md:grid-cols-2">{children}</div>
    </Card>
  );
}

function formatDate(value?: string | null) {
  if (!value) return "—";
  const date = new Date(`${value}T00:00:00`);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("id-ID", { day: "2-digit", month: "long", year: "numeric" }).format(date);
}

function boolText(value?: boolean | null) {
  if (value === true) return "Ya";
  if (value === false) return "Tidak";
  return "—";
}

function ProfilPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const { data: s } = useQuery({ queryKey: ["student", id], queryFn: () => fetchStudent(id) });
  const { data: history = [] } = useQuery({ queryKey: ["class-history", id], queryFn: () => fetchClassHistories(id) });
  const { data: eskulIds = [] } = useQuery({ queryKey: ["student-eskul", id], queryFn: () => fetchStudentExtracurriculars(id) });
  const { data: eskuls = [] } = useQuery({
    queryKey: ["eskuls-all"],
    queryFn: async () => (await supabase.from("extracurriculars").select("id,name")).data ?? [],
  });
  const { data: docs = [] } = useQuery({
    queryKey: ["student-docs", id],
    queryFn: async () => (await supabase.from("student_documents").select("*").eq("student_id", id).order("created_at", { ascending: false })).data ?? [],
  });
  const { data: subjects = [] } = useQuery({
    queryKey: ["subjects", "active"],
    queryFn: async () => (await supabase.from("subjects").select("id,name").eq("is_active", true).order("name")).data ?? [],
  });
  const { data: grades = [] } = useQuery({
    queryKey: ["grades", id],
    queryFn: () => fetchStudentGrades(id),
  });

  const SEMESTERS = [1, 2, 3, 4, 5, 6];
  const bySem = useMemo(() => {
    const m = new Map<number, Map<string, any>>();
    (grades as any[]).forEach((g) => {
      if (!m.has(g.semester)) m.set(g.semester, new Map());
      m.get(g.semester)!.set(g.subject_id, g);
    });
    return m;
  }, [grades]);
  const semAverages = useMemo(() => {
    const out: Record<number, number | null> = {};
    SEMESTERS.forEach((sem) => {
      const rows = (subjects as any[])
        .map((s) => bySem.get(sem)?.get(s.id)?.final_score)
        .filter((v) => v != null)
        .map(Number);
      out[sem] = rows.length ? rows.reduce((a, b) => a + b, 0) / rows.length : null;
    });
    return out;
  }, [subjects, bySem]);
  const overallAverage = useMemo(() => {
    const vals = Object.values(semAverages).filter((v): v is number => v != null);
    return vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : null;
  }, [semAverages]);
  const totalSubjectsWithGrades = useMemo(() => {
    const ids = new Set<string>();
    (grades as any[]).forEach((g) => ids.add(g.subject_id));
    return ids.size;
  }, [grades]);

  const [photo, setPhoto] = useState<string | null>(null);
  useEffect(() => { if (s?.photo_url) signedUrl(s.photo_url).then(setPhoto).catch(() => setPhoto(null)); }, [s?.photo_url]);

  const printRef = useRef<HTMLDivElement>(null);

  function doPrint() { window.print(); }

  if (!s) return <div className="text-sm text-muted-foreground">Memuat…</div>;

  return (
    <div className="profile-print-page mx-auto max-w-5xl">
      <div className="mb-4 flex items-center justify-between print:hidden">
        <Button variant="ghost" size="sm" onClick={() => navigate({ to: "/siswa" })}>
          <ChevronLeft className="mr-1 h-4 w-4" /> Kembali
        </Button>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" asChild>
            <Link to="/nilai/$studentId" params={{ studentId: id }}><ClipboardList className="mr-2 h-4 w-4" />Legger Nilai</Link>
          </Button>
          <Button variant="outline" size="sm" asChild>
            <Link to="/siswa/$id/edit" params={{ id }}><Pencil className="mr-2 h-4 w-4" />Ubah Siswa</Link>
          </Button>
          <Button size="sm" onClick={doPrint}><Printer className="mr-2 h-4 w-4" />Cetak Profil</Button>
        </div>

      </div>

      <div ref={printRef} className="space-y-4">
        <SchoolHeader subtitle="PROFIL SISWA" />


        <Section title="Foto Siswa">
          <div className="md:col-span-2 flex flex-col gap-4 sm:flex-row sm:items-center">
            <div className="grid h-40 w-32 shrink-0 place-items-center overflow-hidden rounded-xl bg-muted print:rounded-none">
              {photo ? <img src={photo} alt={`Foto ${s.full_name}`} className="h-full w-full object-cover" /> : <span className="px-3 text-center text-xs text-muted-foreground">Tidak ada foto</span>}
            </div>
            <div className="min-w-0 flex-1 space-y-2">
              <h2 className="font-display text-xl font-semibold">{s.full_name}</h2>
              <div className="flex flex-wrap gap-2">
                <Badge className="bg-primary-soft text-primary border-transparent">{s.status}</Badge>
                {s.is_boarding && <Badge variant="outline">Pesantren</Badge>}
                {(s as any).current_class?.name && <Badge variant="outline">{(s as any).current_class.name}</Badge>}
              </div>
              <div className="grid gap-x-6 sm:grid-cols-2">
                <Row label="NIS" value={s.nis} />
                <Row label="NISN" value={s.nisn} />
              </div>
            </div>
          </div>
        </Section>

        <Section title="Identitas">
          <Row label="NIS" value={s.nis} />
          <Row label="NISN" value={s.nisn} />
          <Row label="Nama Lengkap" value={s.full_name} />
          <Row label="NIK" value={s.nik} />
          <Row label="Jenis Kelamin" value={s.gender} />
          <Row label="Tempat Lahir" value={s.place_of_birth} />
          <Row label="Tanggal Lahir" value={formatDate(s.date_of_birth)} />
          <Row label="Agama" value={s.religion} />
          <Row label="Kewarganegaraan" value={s.nationality} />
          <Row label="Status Anak" value={s.child_status} />
          <Row label="Anak ke-" value={s.birth_order} />
          <Row label="Jumlah Saudara" value={s.siblings_count} />
          <Row label="No. HP" value={s.mobile_phone} />
          <Row label="No. Kartu Keluarga" value={s.family_card_number} />
        </Section>

        <Section title="Keluarga">
          <Row label="NIK Ayah" value={s.father_nik} />
          <Row label="Nama Ayah" value={s.father_name} />
          <Row label="Pendidikan Ayah" value={s.father_education} />
          <Row label="Pekerjaan Ayah" value={s.father_occupation} />
          <Row label="Penghasilan Ayah" value={s.father_income} />
          <Row label="NIK Ibu" value={s.mother_nik} />
          <Row label="Nama Ibu" value={s.mother_name} />
          <Row label="Pendidikan Ibu" value={s.mother_education} />
          <Row label="Pekerjaan Ibu" value={s.mother_occupation} />
          <Row label="Penghasilan Ibu" value={s.mother_income} />
          <Row label="Nama Wali" value={s.guardian_name} />
          <Row label="Hubungan Wali" value={s.guardian_relationship} />
          <Row label="Pekerjaan Wali" value={s.guardian_occupation} />
          <Row label="Penghasilan Wali" value={s.guardian_income} />
          <Row label="No. HP Wali" value={s.guardian_phone} />
        </Section>

        <Section title="Alamat">
          <Row label="No. KK" value={s.family_card_number} />
          <Row label="Alamat" value={s.address} />
          <Row label="RT / RW" value={`${s.rt ?? "—"} / ${s.rw ?? "—"}`} />
          <Row label="Desa" value={s.village} />
          <Row label="Kecamatan" value={s.district} />
          <Row label="Kabupaten" value={s.regency} />
          <Row label="Provinsi" value={s.province} />
          <Row label="Kode Pos" value={s.postal_code} />
          <Row label="Transportasi" value={s.transportation} />
          <Row label="Jarak ke Sekolah" value={s.distance_from_school} />
        </Section>

        <Section title="Akademik">
          <Row label="Sekolah Asal" value={s.previous_school} />
          <Row label="Tanggal Masuk" value={formatDate(s.entry_date)} />
          <Row label="Jenis Pendaftaran" value={s.admission_type} />
          <Row label="Kelas Saat Ini" value={(s as any).current_class?.name} />
          <Row label="Pesantren" value={boolText(s.is_boarding)} />
          <Row label="Status" value={s.status} />
          {s.status === "Lulus" && <Row label="Tanggal Lulus" value={s.exit_date} />}
          {s.status === "Lulus" && <Row label="Alasan Keluar" value={s.exit_reason} />}
        </Section>

        <Card className="profile-card rounded-2xl border border-border p-5 shadow-soft print:rounded-none">
          <h3 className="mb-3 font-display text-base font-semibold">Riwayat Kelas</h3>
          {history.length === 0 ? (
            <p className="text-sm text-muted-foreground">Belum ada riwayat kelas.</p>
          ) : (
            <div className="overflow-hidden rounded-xl border border-border">
              <table className="w-full text-sm">
                <thead className="bg-muted/40"><tr><th className="px-3 py-2 text-left">Tahun Ajaran</th><th className="px-3 py-2 text-left">Kelas</th><th className="px-3 py-2 text-left">Mulai</th><th className="px-3 py-2 text-left">Selesai</th><th className="px-3 py-2">Status</th></tr></thead>
                <tbody>
                  {history.map((h: any) => (
                    <tr key={h.id} className="border-t border-border">
                      <td className="px-3 py-2">{h.academic_year?.name ?? "—"}</td>
                      <td className="px-3 py-2">{h.class?.name ?? "—"}</td>
                      <td className="px-3 py-2 tabular-nums">{formatDate(h.start_date)}</td>
                      <td className="px-3 py-2 tabular-nums">{formatDate(h.end_date)}</td>
                      <td className="px-3 py-2 text-center">{h.is_active ? <Badge className="bg-primary-soft text-primary border-transparent">Aktif</Badge> : <span className="text-muted-foreground">—</span>}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        <Card className="profile-card rounded-2xl border border-border p-5 shadow-soft print:rounded-none">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <h3 className="font-display text-base font-semibold">Rekam Jejak Akademik</h3>
            <div className="flex flex-wrap gap-2 print:hidden">
              <Button asChild variant="outline" size="sm">
                <Link to="/nilai/$studentId" params={{ studentId: id }}>
                  <Download className="mr-2 h-4 w-4" /> Legger Nilai
                </Link>
              </Button>
            </div>
          </div>

          {(subjects as any[]).length === 0 || (grades as any[]).length === 0 ? (
            <p className="text-sm text-muted-foreground">Belum ada data nilai untuk siswa ini.</p>
          ) : (
            <>
              <div className="grid gap-3 sm:grid-cols-3 print:grid-cols-3">
                <div className="rounded-xl border border-border bg-muted/30 p-3">
                  <div className="text-xs text-muted-foreground">Rata-Rata Keseluruhan</div>
                  <div className="stat-number text-2xl font-semibold text-primary">
                    {overallAverage != null ? overallAverage.toFixed(2) : "—"}
                  </div>
                </div>
                <div className="rounded-xl border border-border bg-muted/30 p-3">
                  <div className="text-xs text-muted-foreground">Total Mata Pelajaran</div>
                  <div className="stat-number text-2xl font-semibold">{totalSubjectsWithGrades}</div>
                </div>
                <div className="rounded-xl border border-border bg-muted/30 p-3">
                  <div className="text-xs text-muted-foreground">Semester Terisi</div>
                  <div className="stat-number text-2xl font-semibold">
                    {Object.values(semAverages).filter((v) => v != null).length} / 6
                  </div>
                </div>
              </div>

              <div className="mt-4 overflow-x-auto rounded-xl border border-border">
                <table className="w-full text-sm">
                  <thead className="bg-muted/40">
                    <tr>
                      <th className="px-2 py-2 text-left">Mata Pelajaran</th>
                      {SEMESTERS.map((s) => (
                        <th key={s} className="px-1 py-2 text-center" colSpan={3}>Semester {s}</th>
                      ))}
                      <th className="px-2 py-2 text-center">Rata</th>
                    </tr>
                    <tr className="bg-muted/20 text-xs">
                      <th></th>
                      {SEMESTERS.map((s) => (
                        <Fragment key={s}>
                          <th className="px-1 py-1 text-center font-medium">P</th>
                          <th className="px-1 py-1 text-center font-medium">K</th>
                          <th className="px-1 py-1 text-center font-medium">A</th>
                        </Fragment>
                      ))}
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {(subjects as any[]).map((sub) => {
                      const finals = SEMESTERS
                        .map((sem) => bySem.get(sem)?.get(sub.id)?.final_score)
                        .filter((v) => v != null)
                        .map(Number);
                      const avg = finals.length ? finals.reduce((a, b) => a + b, 0) / finals.length : null;
                      return (
                        <tr key={sub.id} className="border-t border-border">
                          <td className="px-2 py-2 font-medium">{sub.name}</td>
                          {SEMESTERS.map((sem) => {
                            const g = bySem.get(sem)?.get(sub.id);
                            return (
                              <Fragment key={sem}>
                                <td className="px-1 py-2 text-center tabular-nums text-xs">{g?.knowledge_score ?? "—"}</td>
                                <td className="px-1 py-2 text-center tabular-nums text-xs">{g?.skills_score ?? "—"}</td>
                                <td className="px-1 py-2 text-center text-xs font-semibold tabular-nums">{g?.final_score ?? "—"}</td>
                              </Fragment>
                            );
                          })}
                          <td className="px-2 py-2 text-center font-semibold tabular-nums">
                            {avg != null ? avg.toFixed(2) : "—"}
                          </td>
                        </tr>
                      );
                    })}
                    <tr className="border-t-2 border-foreground/40 bg-muted/30 font-semibold">
                      <td className="px-2 py-2">Rata-Rata Semester</td>
                      {SEMESTERS.map((s) => (
                        <td key={s} colSpan={3} className="px-1 py-2 text-center tabular-nums">
                          {semAverages[s] == null ? "—" : semAverages[s]!.toFixed(2)}
                        </td>
                      ))}
                      <td className="px-2 py-2 text-center tabular-nums">
                        {overallAverage == null ? "—" : overallAverage.toFixed(2)}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="mt-2 text-xs text-muted-foreground print:hidden">
                Keterangan: P = Pengetahuan · K = Keterampilan · A = Akhir
              </div>
            </>
          )}
        </Card>


        <Section title="Kesehatan">
          <Row label="Riwayat Penyakit" value={s.medical_history} />
          <Row label="Alergi" value={s.allergies} />
          <Row label="Disabilitas" value={s.disabilities} />
          <Row label="Imunisasi" value={s.immunization} />
          <Row label="Catatan" value={s.health_notes} />
        </Section>

        <Card className="profile-card rounded-2xl border border-border p-5 shadow-soft print:rounded-none">
          <h3 className="mb-3 font-display text-base font-semibold">Ekstrakurikuler</h3>
          <div className="flex flex-wrap gap-2">
            {eskulIds.length === 0 ? (
              <span className="text-sm text-muted-foreground">—</span>
            ) : (
              eskulIds.map((id) => {
                const e = eskuls.find((x) => x.id === id);
                return e ? <Badge key={id} className="bg-primary-soft text-primary border-transparent">{e.name}</Badge> : null;
              })
            )}
          </div>
        </Card>

        <Card className="profile-card rounded-2xl border border-border p-5 shadow-soft print:rounded-none">
          <h3 className="mb-3 font-display text-base font-semibold">Dokumen</h3>
          {docs.length === 0 ? <p className="text-sm text-muted-foreground">Belum ada dokumen.</p> : (
            <ul className="space-y-2">
              {docs.map((d: any) => <DocRow key={d.id} doc={d} />)}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}

function DocRow({ doc }: { doc: any }) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => { if (doc.file_url) signedUrl(doc.file_url).then(setUrl).catch(() => setUrl(null)); }, [doc.file_url]);
  const isImage = /\.(png|jpe?g|gif|webp|avif)$/i.test(doc.file_name ?? doc.file_url ?? "");
  const isPdf = /\.pdf$/i.test(doc.file_name ?? doc.file_url ?? "");
  return (
    <li className="flex flex-wrap items-center gap-3 rounded-xl border border-border p-3">
      <FileText className="h-5 w-5 shrink-0 text-primary" />
      <div className="min-w-0 flex-1">
        <div className="truncate text-sm font-medium">{doc.doc_type}</div>
        <div className="truncate text-xs text-muted-foreground">{doc.file_name ?? "—"}</div>
      </div>
      <div className="flex gap-2 print:hidden">
        {url && (isImage || isPdf) && (
          <Button asChild variant="outline" size="sm"><a href={url} target="_blank" rel="noreferrer"><Eye className="mr-1 h-4 w-4" />Preview</a></Button>
        )}
        {url && (
          <Button asChild variant="outline" size="sm"><a href={url} download={doc.file_name ?? "dokumen"}><Download className="mr-1 h-4 w-4" />Unduh</a></Button>
        )}
      </div>
    </li>
  );
}
