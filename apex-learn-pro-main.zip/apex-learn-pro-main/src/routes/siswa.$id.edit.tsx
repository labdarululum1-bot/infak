import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronLeft, Eye } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { assignActiveClass, fetchStudent, sanitizeStudent, setStudentExtracurriculars } from "@/lib/db";
import { PageHeader } from "@/components/PageHeader";
import { StudentForm } from "@/components/StudentForm";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/siswa/$id/edit")({
  head: () => ({ meta: [{ title: "Ubah Siswa — Buku Induk" }] }),
  component: EditStudent,
});

function EditStudent() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["student", id], queryFn: () => fetchStudent(id) });

  if (isLoading) return <div className="text-sm text-muted-foreground">Memuat…</div>;
  if (!data) return <div className="text-sm text-destructive">Siswa tidak ditemukan</div>;

  return (
    <div className="mx-auto max-w-5xl">
      <div className="mb-2 flex items-center justify-between">
        <Button variant="ghost" size="sm" onClick={() => navigate({ to: "/siswa" })}>
          <ChevronLeft className="mr-1 h-4 w-4" /> Kembali
        </Button>
        <Button variant="outline" size="sm" asChild>
          <Link to="/siswa/$id/profil" params={{ id }}><Eye className="mr-2 h-4 w-4" />Lihat Profil</Link>
        </Button>
      </div>
      <PageHeader title={data.full_name} description={`NIS: ${data.nis ?? "—"} · NISN: ${data.nisn ?? "—"} · NIK: ${data.nik ?? "—"}`} />
      <StudentForm
        initial={data}
        studentId={id}
        onCancel={() => navigate({ to: "/siswa" })}
        onSubmit={async ({ data: form, eskuls, classAssignment }) => {
          const payload = sanitizeStudent({
            ...form,
            current_class_id: classAssignment?.classId ?? form.current_class_id ?? null,
          });
          const { error } = await supabase.from("students").update(payload as any).eq("id", id);
          if (error) throw error;
          await setStudentExtracurriculars(id, eskuls);
          if (classAssignment) {
            await assignActiveClass({
              studentId: id,
              classId: classAssignment.classId,
              academicYearId: classAssignment.academicYearId,
            });
          }
          qc.invalidateQueries({ queryKey: ["students"] });
          qc.invalidateQueries({ queryKey: ["student", id] });
          toast.success("Perubahan disimpan");
        }}
      />
    </div>
  );
}