import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Download, FileText, Search, UserCheck } from "lucide-react";
import { fetchStudents } from "@/lib/db";
import { exportToExcel, exportToPDF } from "@/lib/export";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { StudentActionsMenu } from "@/components/StudentActionsMenu";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export const Route = createFileRoute("/alumni")({
  head: () => ({ meta: [{ title: "Alumni — Buku Induk Siswa" }] }),
  component: AlumniPage,
});

function gradYearOf(s: any): string {
  return s.exit_date ? String(s.exit_date).slice(0, 4) : "—";
}

function AlumniPage() {
  const { data: alumniAll = [] } = useQuery({ queryKey: ["students", "Lulus"], queryFn: () => fetchStudents("Lulus") });

  const [q, setQ] = useState("");
  const [year, setYear] = useState("all");

  const gradYears = useMemo(
    () => Array.from(new Set(alumniAll.map(gradYearOf).filter((y) => y !== "—"))).sort().reverse(),
    [alumniAll]
  );

  const alumni = useMemo(() => alumniAll.filter((s: any) => {
    if (q && !`${s.full_name} ${s.nis ?? ""} ${s.nisn ?? ""} ${s.master_book_number ?? ""}`.toLowerCase().includes(q.toLowerCase())) return false;
    if (year !== "all" && gradYearOf(s) !== year) return false;
    return true;
  }), [alumniAll, q, year]);

  function rows() {
    return alumni.map((s: any) => ({
      "Nama": s.full_name, "NIS": s.nis ?? "", "NISN": s.nisn ?? "",
      "Tahun Ajaran Lulus": gradYearOf(s),
      "Kelas Terakhir": s.current_class?.name ?? "", "Gender": s.gender ?? "",
      "Pesantren": s.is_boarding ? "Ya" : "Tidak", "Tanggal Kelulusan": s.exit_date ?? "",
    }));
  }

  return (
    <div>
      <PageHeader
        title="Alumni"
        description="Siswa dengan status Lulus. Otomatis tampil setelah diluluskan dari menu Kelas."
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => exportToExcel(rows(), "alumni")}><Download className="mr-2 h-4 w-4" />Excel</Button>
            <Button variant="outline" size="sm" onClick={() => exportToPDF({
              title: "Daftar Alumni", subtitle: `Total: ${alumni.length}`,
              columns: ["Nama", "NIS", "Tahun Lulus", "Kelas Terakhir", "L/P"],
              rows: alumni.map((s: any) => [s.full_name, s.nis ?? "-", gradYearOf(s), s.current_class?.name ?? "-", s.gender === "Laki-laki" ? "L" : "P"]),
              filename: "alumni",
            })}><FileText className="mr-2 h-4 w-4" />PDF</Button>
          </>
        }
      />
      <Card className="mb-4 rounded-2xl border border-border p-4 shadow-soft">
        <div className="grid gap-3 lg:grid-cols-[1fr_auto]">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari nama, NIS, NISN, no. induk…" className="pl-9" />
          </div>
          <Select value={year} onValueChange={setYear}>
            <SelectTrigger className="w-48"><SelectValue placeholder="Tahun Ajaran Lulus" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua Tahun</SelectItem>
              {gradYears.map((y) => <SelectItem key={y} value={y}>{y}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </Card>
      <Card className="overflow-hidden rounded-2xl border border-border shadow-soft">
        {alumni.length === 0 ? (
          <div className="p-6"><EmptyState icon={<UserCheck className="h-6 w-6" />} title="Belum ada alumni" description="Alumni muncul saat seluruh kelas diluluskan dari menu Kelas." /></div>
        ) : (
          <Table>
            <TableHeader><TableRow className="bg-muted/40"><TableHead>Nama</TableHead><TableHead>NIS / NISN</TableHead><TableHead>Tahun Lulus</TableHead><TableHead>Kelas Terakhir</TableHead><TableHead>Gender</TableHead><TableHead className="text-right">Aksi</TableHead></TableRow></TableHeader>
            <TableBody>
              {alumni.map((s: any) => (
                <TableRow key={s.id}>
                  <TableCell className="font-medium">{s.full_name}</TableCell>
                  <TableCell><div className="tabular-nums">{s.nis ?? "—"}</div><div className="text-xs text-muted-foreground tabular-nums">{s.nisn ?? "—"}</div></TableCell>
                  <TableCell>{gradYearOf(s)}</TableCell>
                  <TableCell>{s.current_class?.name ?? "—"}</TableCell>
                  <TableCell><Badge variant="outline" className="font-normal">{s.gender ?? "—"}</Badge></TableCell>
                  <TableCell className="text-right"><StudentActionsMenu student={s} /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Card>
    </div>
  );
}
