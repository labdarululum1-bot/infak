import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { ChevronLeft, Pencil, Printer, Eye, Download, FileText } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { signedUrl } from "@/lib/db";
import { SchoolHeader } from "@/components/SchoolHeader";
import { PageHeader } from "@/components/PageHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/guru/$id/profil")({
  head: () => ({ meta: [{ title: "Profil Guru — Buku Induk" }] }),
  component: TeacherProfile,
});

function Row({ label, value }: { label: string; value: any }) {
  const text = value === null || value === undefined || value === "" ? "—" : value;
  return (
    <div className="grid grid-cols-[150px_1fr] gap-2 border-b border-border/60 py-2 text-sm last:border-b-0 print:grid-cols-[42mm_1fr]">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium text-foreground">{text}</span>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <Card className="rounded-2xl border border-border p-5 shadow-soft print:rounded-none">
      <h3 className="mb-3 font-display text-base font-semibold">{title}</h3>
      <div className="grid gap-x-6 md:grid-cols-2">{children}</div>
    </Card>
  );
}

function formatDate(value?: string | null) {
  if (!value) return "—";
  const date = new Date(`${value}T00:00:00`);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("id-ID", { day: "2-digit", month: "long", year: "numeric" }).format(date);
}

function TeacherProfile() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const { data: t } = useQuery({
    queryKey: ["teacher", id],
    queryFn: async () => (await supabase.from("teachers").select("*").eq("id", id).maybeSingle()).data,
  });
  const { data: teacherSubjects = [] } = useQuery({
    queryKey: ["teacher-subjects", id],
    queryFn: async () => (await supabase.from("teacher_subjects").select("subject_id").eq("teacher_id", id)).data ?? [],
  });
  const { data: subjects = [] } = useQuery({
    queryKey: ["subjects"],
    queryFn: async () => (await supabase.from("subjects").select("id,name")).data ?? [],
  });
  const { data: docs = [] } = useQuery({
    queryKey: ["teacher-docs", id],
    queryFn: async () => (await supabase.from("teacher_documents").select("*").eq("teacher_id", id).order("created_at", { ascending: false })).data ?? [],
  });

  const [photo, setPhoto] = useState<string | null>(null);
  useEffect(() => {
    const p = (t as any)?.photo_url;
    if (p) signedUrl(p).then(setPhoto).catch(() => setPhoto(null));
    else setPhoto(null);
  }, [t]);

  if (!t) return <div className="text-sm text-muted-foreground">Memuat…</div>;

  const subjectNames = (teacherSubjects as any[])
    .map((ts) => (subjects as any[]).find((s) => s.id === ts.subject_id)?.name)
    .filter(Boolean);

  return (
    <div className="mx-auto max-w-5xl">
      <div className="mb-4 flex items-center justify-between print:hidden">
        <Button variant="ghost" size="sm" onClick={() => navigate({ to: "/guru" })}>
          <ChevronLeft className="mr-1 h-4 w-4" /> Kembali
        </Button>
        <div className="flex gap-2">
          <Button asChild variant="outline" size="sm">
            <Link to="/guru"><Pencil className="mr-2 h-4 w-4" />Ubah Guru</Link>
          </Button>

          <Button size="sm" onClick={() => window.print()}><Printer className="mr-2 h-4 w-4" />Cetak Profil</Button>
        </div>
      </div>

      <div className="space-y-4">
        <SchoolHeader subtitle="PROFIL GURU / TENAGA PENDIDIK" />

        <Section title="Foto & Ringkasan">
          <div className="md:col-span-2 flex flex-col gap-4 sm:flex-row sm:items-center">
            <div className="grid h-40 w-32 shrink-0 place-items-center overflow-hidden rounded-xl bg-muted print:rounded-none">
              {photo ? <img src={photo} alt={`Foto ${(t as any).full_name}`} className="h-full w-full object-cover" /> : <span className="px-3 text-center text-xs text-muted-foreground">Tidak ada foto</span>}
            </div>
            <div className="min-w-0 flex-1 space-y-2">
              <h2 className="font-display text-xl font-semibold">{(t as any).full_name}</h2>
              <div className="flex flex-wrap gap-2">
                {(t as any).position && <Badge className="bg-primary-soft text-primary border-transparent">{(t as any).position}</Badge>}
                {(t as any).employment_status && <Badge variant="outline">{(t as any).employment_status}</Badge>}
              </div>
              <div className="grid gap-x-6 sm:grid-cols-2 text-sm">
                <Row label="NIP" value={(t as any).nip} />
                <Row label="NUPTK" value={(t as any).nuptk} />
              </div>
            </div>
          </div>
        </Section>

        <Section title="Identitas">
          <Row label="Nama Lengkap" value={(t as any).full_name} />
          <Row label="NIK" value={(t as any).nik} />
          <Row label="NIP" value={(t as any).nip} />
          <Row label="NUPTK" value={(t as any).nuptk} />
          <Row label="Jenis Kelamin" value={(t as any).gender} />
          <Row label="Tempat Lahir" value={(t as any).place_of_birth} />
          <Row label="Tanggal Lahir" value={formatDate((t as any).date_of_birth)} />
          <Row label="Agama" value={(t as any).religion} />
        </Section>

        <Section title="Kontak & Alamat">
          <Row label="No. HP" value={(t as any).phone} />
          <Row label="Email" value={(t as any).email} />
          <Row label="Alamat" value={(t as any).address} />
        </Section>

        <Section title="Kepegawaian & Pendidikan">
          <Row label="Jabatan" value={(t as any).position} />
          <Row label="Status Kepegawaian" value={(t as any).employment_status} />
          <Row label="Pendidikan Terakhir" value={(t as any).education} />
          <Row label="Universitas" value={(t as any).university} />
          <Row label="Jurusan" value={(t as any).major} />
        </Section>

        <Card className="rounded-2xl border border-border p-5 shadow-soft print:rounded-none">
          <h3 className="mb-3 font-display text-base font-semibold">Mata Pelajaran Diampu</h3>
          <div className="flex flex-wrap gap-2">
            {subjectNames.length === 0 ? (
              <span className="text-sm text-muted-foreground">—</span>
            ) : (
              subjectNames.map((n, i) => <Badge key={i} className="bg-primary-soft text-primary border-transparent">{n}</Badge>)
            )}
          </div>
        </Card>

        <Card className="rounded-2xl border border-border p-5 shadow-soft print:rounded-none">
          <h3 className="mb-3 font-display text-base font-semibold">Dokumen</h3>
          {docs.length === 0 ? (
            <p className="text-sm text-muted-foreground">Belum ada dokumen.</p>
          ) : (
            <ul className="space-y-2">
              {(docs as any[]).map((d) => <DocRow key={d.id} doc={d} />)}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}

function DocRow({ doc }: { doc: any }) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => { if (doc.file_url) signedUrl(doc.file_url).then(setUrl).catch(() => setUrl(null)); }, [doc.file_url]);
  const isPreviewable = /\.(png|jpe?g|gif|webp|avif|pdf)$/i.test(doc.file_name ?? doc.file_url ?? "");
  return (
    <li className="flex flex-wrap items-center gap-3 rounded-xl border border-border p-3">
      <FileText className="h-5 w-5 shrink-0 text-primary" />
      <div className="min-w-0 flex-1">
        <div className="truncate text-sm font-medium">{doc.doc_type}</div>
        <div className="truncate text-xs text-muted-foreground">{doc.file_name ?? "—"}</div>
      </div>
      <div className="flex gap-2 print:hidden">
        {url && isPreviewable && (
          <Button asChild variant="outline" size="sm"><a href={url} target="_blank" rel="noreferrer"><Eye className="mr-1 h-4 w-4" />Preview</a></Button>
        )}
        {url && (
          <Button asChild variant="outline" size="sm"><a href={url} download={doc.file_name ?? "dokumen"}><Download className="mr-1 h-4 w-4" />Unduh</a></Button>
        )}
      </div>
    </li>
  );
}
