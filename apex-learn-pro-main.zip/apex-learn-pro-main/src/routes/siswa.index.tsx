import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Plus, Search, Download, FileText, Users, FileUp } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { fetchStudents, fetchClasses, fetchExtracurriculars } from "@/lib/db";
import { exportToExcel, exportToPDF } from "@/lib/export";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { StudentActionsMenu } from "@/components/StudentActionsMenu";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export const Route = createFileRoute("/siswa/")({
  head: () => ({
    meta: [
      { title: "Data Siswa — Buku Induk Siswa" },
      { name: "description", content: "Daftar siswa aktif: cari, tambah, ubah, hapus, dan impor dari Excel." },
    ],
  }),
  component: StudentList,
});

function StudentList() {
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [gender, setGender] = useState("all");
  const [boarding, setBoarding] = useState("all");
  const [classId, setClassId] = useState("all");
  const [eskulId, setEskulId] = useState("all");
  const [page, setPage] = useState(1);
  const perPage = 15;

  const { data: students = [] } = useQuery({ queryKey: ["students", "Aktif"], queryFn: () => fetchStudents("Aktif") });
  const { data: classes = [] } = useQuery({ queryKey: ["classes"], queryFn: fetchClasses });
  const { data: eskuls = [] } = useQuery({ queryKey: ["extracurriculars"], queryFn: fetchExtracurriculars });

  const { data: eskulLinks = [] } = useQuery({
    queryKey: ["all-student-eskuls"],
    queryFn: async () => {
      const { data } = await supabase.from("student_extracurriculars").select("student_id, extracurricular_id");
      return data ?? [];
    },
  });

  const studentsWithEskul = useMemo(() => {
    const map = new Map<string, string[]>();
    eskulLinks.forEach((l) => {
      const arr = map.get(l.student_id) ?? [];
      arr.push(l.extracurricular_id);
      map.set(l.student_id, arr);
    });
    return students.map((s: any) => ({ ...s, eskul_ids: map.get(s.id) ?? [] }));
  }, [students, eskulLinks]);

  const filtered = useMemo(() => {
    const ql = q.toLowerCase().trim();
    return studentsWithEskul.filter((s: any) => {
      if (ql && !`${s.full_name} ${s.nis ?? ""} ${s.nisn ?? ""} ${s.nik ?? ""} ${s.family_card_number ?? ""} ${s.mobile_phone ?? ""}`.toLowerCase().includes(ql)) return false;
      if (gender !== "all" && s.gender !== gender) return false;
      if (boarding !== "all" && s.is_boarding !== (boarding === "yes")) return false;
      if (classId !== "all" && s.current_class_id !== classId) return false;
      if (eskulId !== "all" && !s.eskul_ids.includes(eskulId)) return false;
      return true;
    });
  }, [studentsWithEskul, q, gender, boarding, classId, eskulId]);

  const paginated = filtered.slice((page - 1) * perPage, page * perPage);
  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));

  function exportRows() {
    return filtered.map((s: any, i: number) => ({
      No: i + 1,
      NIS: s.nis ?? "", NISN: s.nisn ?? "", NIK: s.nik ?? "",
      "Nama Lengkap": s.full_name, "Jenis Kelamin": s.gender ?? "",
      Kelas: s.current_class?.name ?? "",
      Pesantren: s.is_boarding ? "Ya" : "Tidak",
      "Tempat Lahir": s.place_of_birth ?? "", "Tanggal Lahir": s.date_of_birth ?? "",
      Agama: s.religion ?? "",
      "No. HP": s.mobile_phone ?? "",
      "No. KK": s.family_card_number ?? "",
      Alamat: s.address ?? "", Desa: s.village ?? "", Kecamatan: s.district ?? "",
      "Kabupaten/Kota": s.regency ?? "", Provinsi: s.province ?? "",
      "Nama Ayah": s.father_name ?? "", "NIK Ayah": s.father_nik ?? "",
      "Nama Ibu": s.mother_name ?? "", "NIK Ibu": s.mother_nik ?? "",
    }));
  }

  return (
    <div>
      <PageHeader
        title="Data Siswa"
        description="Daftar siswa aktif. Siswa yang telah lulus otomatis pindah ke menu Alumni."
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => navigate({ to: "/siswa/impor" })}>
              <FileUp className="mr-2 h-4 w-4" /> Impor Excel
            </Button>
            <Button variant="outline" size="sm" onClick={() => exportToExcel(exportRows(), "data-siswa")}>
              <Download className="mr-2 h-4 w-4" /> Excel
            </Button>
            <Button variant="outline" size="sm" onClick={() => exportToPDF({
              title: "Data Siswa Aktif",
              subtitle: `Total: ${filtered.length} siswa`,
              columns: ["No. Induk", "NIS", "Nama", "L/P", "Kelas", "Pesantren"],
              rows: filtered.map((s: any) => [
                s.master_book_number ?? "-",
                s.nis ?? "-", s.full_name, s.gender === "Laki-laki" ? "L" : "P",
                s.current_class?.name ?? "-",
                s.is_boarding ? "Ya" : "Tidak",
              ]),
              filename: "data-siswa",
            })}>
              <FileText className="mr-2 h-4 w-4" /> PDF
            </Button>
            <Button onClick={() => navigate({ to: "/siswa/baru" })}>
              <Plus className="mr-2 h-4 w-4" /> Tambah Siswa
            </Button>
          </>
        }
      />

      <Card className="rounded-2xl border border-border p-4 shadow-soft">
        <div className="grid gap-3 lg:grid-cols-[1fr_auto_auto_auto_auto]">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Cari nama, NIS, NISN, NIK…" className="pl-9" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <Select value={gender} onValueChange={setGender}>
            <SelectTrigger className="w-36"><SelectValue placeholder="Gender" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua Gender</SelectItem>
              <SelectItem value="Laki-laki">Laki-laki</SelectItem>
              <SelectItem value="Perempuan">Perempuan</SelectItem>
            </SelectContent>
          </Select>
          <Select value={boarding} onValueChange={setBoarding}>
            <SelectTrigger className="w-36"><SelectValue placeholder="Pesantren" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua</SelectItem>
              <SelectItem value="yes">Pesantren</SelectItem>
              <SelectItem value="no">Non-Pesantren</SelectItem>
            </SelectContent>
          </Select>
          <Select value={classId} onValueChange={setClassId}>
            <SelectTrigger className="w-36"><SelectValue placeholder="Kelas" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua Kelas</SelectItem>
              {classes.map((c: any) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={eskulId} onValueChange={setEskulId}>
            <SelectTrigger className="w-40"><SelectValue placeholder="Ekstrakurikuler" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua Eskul</SelectItem>
              {eskuls.map((e) => <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </Card>

      <Card className="mt-4 overflow-hidden rounded-2xl border border-border shadow-soft">
        {filtered.length === 0 ? (
          <div className="p-6">
            <EmptyState
              icon={<Users className="h-6 w-6" />}
              title="Belum ada siswa aktif"
              description="Mulai dengan menambah atau mengimpor data siswa."
              action={<Button onClick={() => navigate({ to: "/siswa/baru" })}><Plus className="mr-2 h-4 w-4" />Tambah Siswa</Button>}
            />
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="sticky top-0 z-10 bg-muted/60 backdrop-blur">
                  <TableRow>
                    <TableHead className="w-12 text-center">No</TableHead>
                    <TableHead>Siswa</TableHead>
                    <TableHead>NIS / NISN</TableHead>
                    <TableHead>Kelas</TableHead>
                    <TableHead>Gender</TableHead>
                    <TableHead>Pesantren</TableHead>
                    <TableHead className="text-right">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paginated.map((s: any, idx: number) => (
                    <TableRow key={s.id} className="hover:bg-muted/30">
                      <TableCell className="text-center text-sm text-muted-foreground tabular-nums">
                        {(page - 1) * perPage + idx + 1}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-primary-soft font-display text-sm font-semibold text-primary">
                            {s.full_name.charAt(0).toUpperCase()}
                          </div>
                          <div className="min-w-0">
                            <Link to="/siswa/$id/profil" params={{ id: s.id }} className="block truncate font-medium hover:text-primary">
                              {s.full_name}
                            </Link>
                            <div className="truncate text-xs text-muted-foreground tabular-nums">NIK: {s.nik ?? "—"}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm">
                        <div className="tabular-nums">{s.nis ?? "—"}</div>
                        <div className="text-xs text-muted-foreground tabular-nums">{s.nisn ?? "—"}</div>
                      </TableCell>
                      <TableCell>{s.current_class?.name ?? <span className="text-muted-foreground">—</span>}</TableCell>
                      <TableCell><Badge variant="outline" className="font-normal">{s.gender ?? "—"}</Badge></TableCell>
                      <TableCell>
                        {s.is_boarding ? (
                          <Badge className="bg-primary-soft text-primary border-transparent hover:bg-primary-soft">Ya</Badge>
                        ) : (
                          <Badge variant="outline" className="font-normal">Tidak</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <StudentActionsMenu student={s} />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border px-4 py-3 text-sm text-muted-foreground">
              <div>
                Menampilkan <span className="font-medium text-foreground">{(page - 1) * perPage + 1}–{Math.min(page * perPage, filtered.length)}</span> dari <span className="font-medium text-foreground">{filtered.length}</span>
              </div>
              <div className="flex items-center gap-2">
                <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>Sebelumnya</Button>
                <span>Halaman {page} / {totalPages}</span>
                <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>Berikutnya</Button>
              </div>
            </div>
          </>
        )}
      </Card>
    </div>
  );
}
