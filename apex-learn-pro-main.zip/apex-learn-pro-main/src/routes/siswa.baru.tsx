import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { ChevronLeft } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { assignActiveClass, sanitizeStudent, setStudentExtracurriculars } from "@/lib/db";
import { PageHeader } from "@/components/PageHeader";
import { StudentForm } from "@/components/StudentForm";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/siswa/baru")({
  head: () => ({ meta: [{ title: "Tambah Siswa — Buku Induk" }] }),
  component: NewStudent,
});

function NewStudent() {
  const navigate = useNavigate();
  const qc = useQueryClient();

  return (
    <div className="mx-auto max-w-5xl">
      <Button variant="ghost" size="sm" onClick={() => navigate({ to: "/siswa" })} className="mb-2">
        <ChevronLeft className="mr-1 h-4 w-4" /> Kembali
      </Button>
      <PageHeader title="Tambah Siswa Baru" description="Lengkapi data identitas, keluarga, akademik, kesehatan, dan ekstrakurikuler." />
      <StudentForm
        onCancel={() => navigate({ to: "/siswa" })}
        onSubmit={async ({ data, eskuls, classAssignment }) => {
          const payload = sanitizeStudent({
            ...data,
            current_class_id: classAssignment?.classId ?? data.current_class_id ?? null,
          });
          const { data: ins, error } = await supabase.from("students").insert(payload as any).select().single();
          if (error) throw error;
          if (eskuls.length) await setStudentExtracurriculars(ins.id, eskuls);
          if (classAssignment) {
            await assignActiveClass({
              studentId: ins.id,
              classId: classAssignment.classId,
              academicYearId: classAssignment.academicYearId,
            });
          }
          qc.invalidateQueries({ queryKey: ["students"] });
          toast.success("Siswa berhasil ditambahkan");
          navigate({ to: "/siswa/$id", params: { id: ins.id } });
          return ins.id;
        }}
      />
    </div>
  );
}
