import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { STUDENT_NON_COLUMN_KEYS } from "@/lib/constants";

export type Student = Database["public"]["Tables"]["students"]["Row"];
export type StudentInsert = Database["public"]["Tables"]["students"]["Insert"];
export type StudentUpdate = Database["public"]["Tables"]["students"]["Update"];
export type ClassRow = Database["public"]["Tables"]["classes"]["Row"];
export type AcademicYear = Database["public"]["Tables"]["academic_years"]["Row"];
export type Extracurricular = Database["public"]["Tables"]["extracurriculars"]["Row"];
export type StudentDocument = Database["public"]["Tables"]["student_documents"]["Row"];
export type SchoolProfile = Database["public"]["Tables"]["school_profile"]["Row"];
export type Teacher = Database["public"]["Tables"]["teachers"]["Row"];
export type ClassHistory = Database["public"]["Tables"]["student_class_histories"]["Row"];

export type StudentStatus = "Aktif" | "Lulus";

/** Remove join-only fields before insert/update so PostgREST does not see unknown columns. */
export function sanitizeStudent<T extends Record<string, any>>(input: T): T {
  const out: Record<string, any> = {};
  for (const [k, v] of Object.entries(input)) {
    if (STUDENT_NON_COLUMN_KEYS.includes(k)) continue;
    out[k] = v;
  }
  return out as T;
}

const STUDENT_BASE_SELECT = "*, current_class:classes(id,name,grade_level)";

export async function fetchStudents(status?: StudentStatus) {
  let q = supabase.from("students").select(STUDENT_BASE_SELECT).order("full_name");
  if (status) q = q.eq("status", status);
  const { data, error } = await q;
  if (error) throw error;
  return data ?? [];
}

export async function fetchStudent(id: string) {
  const { data, error } = await supabase
    .from("students")
    .select(STUDENT_BASE_SELECT)
    .eq("id", id)
    .single();
  if (error) throw error;
  return data;
}

export async function fetchStudentExtracurriculars(studentId: string) {
  const { data, error } = await supabase
    .from("student_extracurriculars")
    .select("extracurricular_id")
    .eq("student_id", studentId);
  if (error) throw error;
  return (data ?? []).map((r) => r.extracurricular_id);
}

export async function setStudentExtracurriculars(studentId: string, ids: string[]) {
  await supabase.from("student_extracurriculars").delete().eq("student_id", studentId);
  if (ids.length === 0) return;
  const { error } = await supabase
    .from("student_extracurriculars")
    .insert(ids.map((extracurricular_id) => ({ student_id: studentId, extracurricular_id })));
  if (error) throw error;
}

export async function fetchClasses() {
  const { data, error } = await supabase
    .from("classes")
    .select("*, academic_year:academic_years(id,name)")
    .order("name");
  if (error) throw error;
  return data ?? [];
}

export async function fetchAcademicYears() {
  const { data, error } = await supabase.from("academic_years").select("*").order("name", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function fetchExtracurriculars() {
  const { data, error } = await supabase.from("extracurriculars").select("*").order("name");
  if (error) throw error;
  return data ?? [];
}

export async function fetchSchoolProfile() {
  const { data, error } = await supabase.from("school_profile").select("*").eq("id", 1).maybeSingle();
  if (error) throw error;
  return data;
}

/** Returns the currently active academic year (per school profile, or is_active flag as fallback). */
export async function fetchActiveAcademicYear() {
  const p = await fetchSchoolProfile();
  const activeId = (p as any)?.active_academic_year_id ?? null;
  if (activeId) {
    const { data } = await supabase.from("academic_years").select("*").eq("id", activeId).maybeSingle();
    if (data) return data;
  }
  const { data } = await supabase.from("academic_years").select("*").eq("is_active", true).maybeSingle();
  return data ?? null;
}

export async function uploadStudentFile(studentId: string, file: File, prefix = "doc") {
  const ext = file.name.split(".").pop() ?? "bin";
  const path = `${studentId}/${prefix}-${Date.now()}.${ext}`;
  const { error } = await supabase.storage.from("student-files").upload(path, file, { upsert: true });
  if (error) throw error;
  return path;
}

export async function signedUrl(path: string, expiresIn = 60 * 60 * 24 * 365) {
  const { data, error } = await supabase.storage.from("student-files").createSignedUrl(path, expiresIn);
  if (error) throw error;
  return data.signedUrl;
}

/* ============ Class History ============ */

export async function fetchClassHistories(studentId: string) {
  const { data, error } = await supabase
    .from("student_class_histories")
    .select("*, class:classes(id,name,grade_level), academic_year:academic_years(id,name)")
    .eq("student_id", studentId)
    .order("start_date", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

/**
 * Set the active class assignment for a student.
 * Closes any existing active record, opens a new one, and updates the
 * denormalized `current_class_id` cache so existing reports keep working.
 */
export async function assignActiveClass(opts: {
  studentId: string;
  classId: string;
  academicYearId: string;
  startDate?: string;
}) {
  const startDate = opts.startDate ?? new Date().toISOString().slice(0, 10);
  // Close existing active records
  await supabase
    .from("student_class_histories")
    .update({ is_active: false, end_date: startDate })
    .eq("student_id", opts.studentId)
    .eq("is_active", true);
  // Insert new active record
  const { error } = await supabase.from("student_class_histories").insert({
    student_id: opts.studentId,
    class_id: opts.classId,
    academic_year_id: opts.academicYearId,
    start_date: startDate,
    is_active: true,
  });
  if (error) throw error;
  // Sync cached column
  await supabase.from("students").update({ current_class_id: opts.classId }).eq("id", opts.studentId);
}

/** Promote all active students in one class into a destination class for a new academic year. */
export async function promoteClass(opts: {
  fromClassId: string;
  toClassId: string;
  academicYearId: string;
  startDate?: string;
}) {
  const startDate = opts.startDate ?? new Date().toISOString().slice(0, 10);
  const { data: students, error: e1 } = await supabase
    .from("students")
    .select("id")
    .eq("current_class_id", opts.fromClassId)
    .eq("status", "Aktif");
  if (e1) throw e1;
  const ids = (students ?? []).map((s) => s.id);
  if (ids.length === 0) return 0;

  // Close active histories
  await supabase
    .from("student_class_histories")
    .update({ is_active: false, end_date: startDate })
    .in("student_id", ids)
    .eq("is_active", true);

  // Insert new histories
  const inserts = ids.map((student_id) => ({
    student_id,
    class_id: opts.toClassId,
    academic_year_id: opts.academicYearId,
    start_date: startDate,
    is_active: true,
  }));
  const { error: e2 } = await supabase.from("student_class_histories").insert(inserts);
  if (e2) throw e2;

  // Sync cache
  await supabase.from("students").update({ current_class_id: opts.toClassId }).in("id", ids);
  return ids.length;
}

/** Graduate every active student currently assigned to a class. Keeps history records intact. */
export async function graduateClass(opts: { classId: string; graduationDate: string }) {
  // Close active history records (do not delete; they preserve graduation academic year)
  const { data: students, error: e0 } = await supabase
    .from("students")
    .select("id")
    .eq("current_class_id", opts.classId)
    .eq("status", "Aktif");
  if (e0) throw e0;
  const ids = (students ?? []).map((s) => s.id);
  if (ids.length === 0) return 0;

  await supabase
    .from("student_class_histories")
    .update({ is_active: false, end_date: opts.graduationDate })
    .in("student_id", ids)
    .eq("is_active", true);

  const { error } = await supabase
    .from("students")
    .update({ status: "Lulus", exit_date: opts.graduationDate, exit_reason: "Lulus" })
    .in("id", ids);
  if (error) throw error;
  return ids.length;
}
