import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { supabase } from "@/integrations/supabase/client";
import { fetchSchoolProfile, signedUrl } from "@/lib/db";

export function exportToExcel<T extends Record<string, unknown>>(rows: T[], filename: string, sheetName = "Data") {
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheetName);
  XLSX.writeFile(wb, `${filename}.xlsx`);
}

export function exportToPDF(opts: {
  title: string;
  subtitle?: string;
  columns: string[];
  rows: (string | number | null | undefined)[][];
  filename: string;
  orientation?: "portrait" | "landscape";
}) {
  const doc = new jsPDF({ orientation: opts.orientation ?? "landscape", unit: "pt", format: "a4" });
  doc.setFontSize(16);
  doc.text(opts.title, 40, 40);
  if (opts.subtitle) {
    doc.setFontSize(10);
    doc.setTextColor(120);
    doc.text(opts.subtitle, 40, 58);
    doc.setTextColor(0);
  }
  autoTable(doc, {
    head: [opts.columns],
    body: opts.rows.map((r) => r.map((c) => (c == null ? "" : String(c)))),
    startY: 75,
    styles: { fontSize: 9, cellPadding: 4 },
    headStyles: { fillColor: [59, 130, 246], textColor: 255 },
    alternateRowStyles: { fillColor: [245, 247, 250] },
  });
  doc.save(`${opts.filename}.pdf`);
}

async function loadLogoDataUrl(): Promise<string | null> {
  try {
    const profile = await fetchSchoolProfile();
    const path = (profile as any)?.logo_url;
    if (!path) return null;
    const url = await signedUrl(path);
    const res = await fetch(url);
    const blob = await res.blob();
    return await new Promise((resolve) => {
      const r = new FileReader();
      r.onloadend = () => resolve(typeof r.result === "string" ? r.result : null);
      r.readAsDataURL(blob);
    });
  } catch {
    return null;
  }
}

/** Draws the official school header at the top of a jsPDF doc; returns Y position after header. */
export async function drawSchoolHeader(doc: jsPDF, title?: string): Promise<number> {
  const profile: any = await fetchSchoolProfile();
  const logo = await loadLogoDataUrl();
  const pageWidth = doc.internal.pageSize.getWidth();
  const leftPad = 40;
  const topPad = 30;
  let x = leftPad;
  if (logo) {
    try {
      doc.addImage(logo, "PNG", x, topPad, 55, 55);
    } catch {
      /* ignore invalid image */
    }
  }
  const centerX = pageWidth / 2;
  let y = topPad + 4;
  if (profile?.foundation_name) {
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text(String(profile.foundation_name).toUpperCase(), centerX, y, { align: "center" });
    y += 12;
  }
  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.text(String(profile?.school_name ?? "NAMA SEKOLAH").toUpperCase(), centerX, y, { align: "center" });
  y += 14;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  const contact = [profile?.address, profile?.phone ? `Telp. ${profile.phone}` : null, profile?.email, profile?.website]
    .filter(Boolean).join(" · ");
  if (contact) { doc.text(contact, centerX, y, { align: "center", maxWidth: pageWidth - 200 }); y += 11; }
  const ids = [profile?.npsn ? `NPSN: ${profile.npsn}` : null, profile?.nss ? `NSM/NSS: ${profile.nss}` : null]
    .filter(Boolean).join(" · ");
  if (ids) { doc.text(ids, centerX, y, { align: "center" }); y += 11; }
  // horizontal rule
  y += 3;
  doc.setLineWidth(1.2);
  doc.line(leftPad, y, pageWidth - leftPad, y);
  y += 14;
  if (title) {
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text(title, centerX, y, { align: "center" });
    y += 16;
    doc.setFont("helvetica", "normal");
  }
  return y;
}

export async function exportToPDFWithHeader(opts: {
  title: string;
  subtitle?: string;
  columns: string[];
  rows: (string | number | null | undefined)[][];
  filename: string;
  orientation?: "portrait" | "landscape";
}) {
  const doc = new jsPDF({ orientation: opts.orientation ?? "landscape", unit: "pt", format: "a4" });
  const startY = await drawSchoolHeader(doc, opts.title);
  if (opts.subtitle) {
    doc.setFontSize(10);
    doc.setTextColor(120);
    doc.text(opts.subtitle, doc.internal.pageSize.getWidth() / 2, startY, { align: "center" });
    doc.setTextColor(0);
  }
  autoTable(doc, {
    head: [opts.columns],
    body: opts.rows.map((r) => r.map((c) => (c == null ? "" : String(c)))),
    startY: opts.subtitle ? startY + 12 : startY,
    styles: { fontSize: 9, cellPadding: 4 },
    headStyles: { fillColor: [59, 130, 246], textColor: 255 },
    alternateRowStyles: { fillColor: [245, 247, 250] },
  });
  doc.save(`${opts.filename}.pdf`);
}

// keep supabase import used (avoid tree-shaking removing types file import)
void supabase;
