// Centralized dropdown options used across forms and master data screens.

export const INCOME_OPTIONS = [
  "Di bawah Rp 1.000.000",
  "Rp 1.000.000 – Rp 2.000.000",
  "Rp 2.000.000 – Rp 3.000.000",
  "Rp 3.000.000 – Rp 4.000.000",
  "Rp 4.000.000 – Rp 5.000.000",
  "Di atas Rp 5.000.000",
] as const;

export const EDUCATION_OPTIONS = [
  "Tidak Sekolah",
  "SD",
  "SMP",
  "SMA",
  "D1",
  "D2",
  "D3",
  "D4/S1",
  "S2",
  "S3",
] as const;

export const ADMISSION_TYPE_OPTIONS = ["Siswa Baru", "Pindahan"] as const;

export const NATIONALITY_OPTIONS = ["WNI", "WNA"] as const;

export const RELIGION_OPTIONS = ["Islam", "Kristen", "Katolik", "Hindu", "Buddha", "Konghucu"] as const;

export const CHILD_STATUS_OPTIONS = ["Anak Kandung", "Anak Tiri", "Anak Angkat"] as const;

// Fields that come from Postgres joins and must be stripped before INSERT/UPDATE.
export const STUDENT_NON_COLUMN_KEYS = [
  "current_class",
  "academic_year",
  "eskul_ids",
  "class_histories",
];
