import { supabase } from "@/integrations/supabase/client";

export type GradeRow = {
  id?: string;
  student_id: string;
  academic_year_id: string | null;
  class_id: string | null;
  semester: number;
  subject_id: string;
  knowledge_score: number | null;
  skills_score: number | null;
  final_score: number | null;
};

export async function fetchStudentGrades(studentId: string) {
  const { data, error } = await supabase
    .from("grades")
    .select("*, subject:subjects(id,name), academic_year:academic_years(id,name), class:classes(id,name)")
    .eq("student_id", studentId);
  if (error) throw error;
  return data ?? [];
}

export async function fetchClassGrades(opts: { classId: string; academicYearId?: string | null; semester: number }) {
  let q = supabase
    .from("grades")
    .select("*, student:students(id,full_name,nis), subject:subjects(id,name)")
    .eq("class_id", opts.classId)
    .eq("semester", opts.semester);
  if (opts.academicYearId) q = q.eq("academic_year_id", opts.academicYearId);
  const { data, error } = await q;
  if (error) throw error;
  return data ?? [];
}

/** Upsert (student, year, semester, subject) grade rows. */
export async function upsertGrades(rows: GradeRow[]) {
  if (rows.length === 0) return;
  const { error } = await supabase
    .from("grades")
    .upsert(rows, { onConflict: "student_id,academic_year_id,semester,subject_id" });
  if (error) throw error;
}

export async function deleteGrade(id: string) {
  const { error } = await supabase.from("grades").delete().eq("id", id);
  if (error) throw error;
}
